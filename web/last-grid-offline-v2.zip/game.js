// =============================================================================
// Tower Defense: Last Grid — Ultimate Tactical Cyber-Engine v3.0
// 10 Maps | 5 Towers (3 Tiers + 2 Branching Specializations) | 8 Enemies + 3 Bosses
// NEW: Controllable Field Hero Mech | Roguelike Augment Draft | Post-Match DPS Analytics
// =============================================================================

(function() {
  'use strict';

  // --- MULTILINGUAL LOCALIZATION (EN, UZ, RU) ---
  const I18N = {
    en: {
      title: "TOWER DEFENSE: LAST GRID",
      sub: "CYBERNETIC DEFENSE • 10 MAPS • 5 TOWERS • 8 ENEMIES • 3 BOSSES",
      campaign: "CAMPAIGN MISSIONS (10 MAPS)",
      sectorSelect: "SELECT SPECIFIC SECTOR",
      endless: "ENDLESS SURVIVAL MODE (∞ WAVES)",
      bossRush: "BOSS RUSH DUEL",
      mapEditor: "MAP EDITOR",
      leaderboard: "GLOBAL LEADERBOARD",
      fieldManual: "ENCYCLOPEDIA",
      downloadOffline: "OFFLINE ZIP (19MB)",
      core: "CORE HEALTH",
      wave: "WAVE",
      start: "START",
      inBattle: "IN BATTLE",
      upgrade: "UPGRADE",
      sell: "SELL",
      maxTier: "MAX TIER",
      notEnoughGold: "NOT ENOUGH GOLD!",
      waveCleared: "WAVE CLEARED!",
      sectorDefended: "SECTOR DEFENDED!",
      missionSuccess: "★★★ MISSION SUCCESS ★★★",
      gridOverrun: "GRID OVERRUN!",
      playAgain: "PLAY AGAIN",
      retry: "RETRY SECTOR",
      mainMenu: "MAIN MENU",
      emp: "EMP STORM",
      orbital: "ORBITAL BEAM",
      overclock: "OVERCLOCK",
      drone: "SUPPLY DRONE",
      heroUlt: "CYBER-SLASH (ULT)",
      analyticsTitle: "TACTICAL COMBAT ANALYTICS",
      draftTitle: "TACTICAL AUGMENT DRAFT",
      draftSub: "SELECT 1 PROTOCOL PERK TO ACTIVATE"
    },
    uz: {
      title: "TOWER DEFENSE: LAST GRID",
      sub: "KIBERNETIK HIMOYА • 10 XARITA • 5 MINORA • 8 DUSHMAN • 3 BOSS",
      campaign: "KAMPANIYA MISSIYALARI (10 XARITA)",
      sectorSelect: "XARITANI TANLASH",
      endless: "CHEKSIZ REJIM (∞ TO'LQIN)",
      bossRush: "BOSS RUSH DUEL",
      mapEditor: "XARITALAR MUHARRIRI",
      leaderboard: "GLOBAL REYTING",
      fieldManual: "ENSIKLOPEDIYA",
      downloadOffline: "OFLAYN ZIP (19MB)",
      core: "BAZA HOLATI",
      wave: "TO'LQIN",
      start: "BOSHLASH",
      inBattle: "JANG KETMOQDA",
      upgrade: "KUCHAYTIRISH",
      sell: "SOTISH",
      maxTier: "MAKSIMAL",
      notEnoughGold: "OLTIN YETARLI EMAS!",
      waveCleared: "TO'LQIN TOZALANDI!",
      sectorDefended: "SEKTOR HIMOYA QILINDI!",
      missionSuccess: "★★★ G'ALABA QOZONILDI ★★★",
      gridOverrun: "BAZA EGALLAB OLINDI!",
      playAgain: "QAYTA O'YNASH",
      retry: "QAYTA URINISH",
      mainMenu: "ASOSIY MENYU",
      emp: "EMP ZARBA",
      orbital: "ORBITAL LAZER",
      overclock: "OVERCLOCK",
      drone: "OLTIN DRONI",
      heroUlt: "QAHRAMON ZARBASI (ULT)",
      analyticsTitle: "JANG TAHLILI VA DPS GRAFIKLARI",
      draftTitle: "TAKTIK KARTA TANLOVI",
      draftSub: "FAOL QILISH UCHUN 1 TA PROTOKOLNI TANLANG"
    },
    ru: {
      title: "TOWER DEFENSE: LAST GRID",
      sub: "КИБЕР-ОБОРОНА • 10 КАРТ • 5 БАШЕН • 8 ВРАГОВ • 3 БОССА",
      campaign: "КАМПАНИЯ (10 КАРТ)",
      sectorSelect: "ВЫБОР СЕКТОРА",
      endless: "БЕСКОНЕЧНЫЙ РЕЖИМ (∞ ВОЛН)",
      bossRush: "БОСС РАШ ДУЭЛЬ",
      mapEditor: "РЕДАКТОР КАРТ",
      leaderboard: "ТАБЛИЦА ЛИДЕРОВ",
      fieldManual: "СПРАВОЧНИК",
      downloadOffline: "ОФЛАЙН ZIP (19MB)",
      core: "ПРОЧНОСТЬ ЯДРА",
      wave: "ВОЛНА",
      start: "СТАРТ",
      inBattle: "В БОЮ",
      upgrade: "УЛУЧШИТЬ",
      sell: "ПРОДАТЬ",
      maxTier: "МАКС ТИР",
      notEnoughGold: "НЕДОСТАТОЧНО ЗОЛОТА!",
      waveCleared: "ВОЛНА ЗАЧИЩЕНА!",
      sectorDefended: "СЕКТОР ЗАЩИЩЁН!",
      missionSuccess: "★★★ ПОБЕДА ★★★",
      gridOverrun: "БАЗА ПАЛА!",
      playAgain: "ИГРАТЬ СНОВА",
      retry: "ПОВТОРИТЬ",
      mainMenu: "ГЛАВНОЕ МЕНЮ",
      emp: "ЭМИ БУРЯ",
      orbital: "ОРБИТАЛЬНЫЙ ЛУЧ",
      overclock: "РАЗГОН",
      drone: "ДРОН СНАБЖЕНИЯ",
      heroUlt: "СУПЕР УДАР ГЕРОЯ",
      analyticsTitle: "БОЕВАЯ АНАЛИТИКА И ГРАФИКИ DPS",
      draftTitle: "ВЫБОР ТАКТИЧЕСКИХ КАРТ",
      draftSub: "ВЫБЕРИТЕ 1 ПРОТОКОЛ ДЛЯ АКТИВАЦИИ"
    }
  };

  // --- AUDIO SYNTHESIZER ---
  class SoundSynth {
    constructor() {
      this.ctx = null;
      this.sfxMuted = false;
      this.bgmMuted = false;
      this.bgmPlaying = false;
      this.bgmTimer = null;
      this.step = 0;
      this.scale = [146.83, 164.81, 174.61, 196.00, 220.00, 261.63, 293.66, 329.63];
      this.bassNotes = [73.42, 73.42, 87.31, 98.00, 73.42, 73.42, 110.00, 98.00];
      this.samplesLoaded = false;
      this.sampleBuffers = {};
    }
    loadSamples() {
      if (this.samplesLoaded) return;
      this.samplesLoaded = true;
      const sfxList = {
        click: 'assets/audio/sfx/click.mp3',
        laser: 'assets/audio/sfx/laser.mp3',
        explosion: 'assets/audio/sfx/artillery_blast.wav',
        zap: 'assets/audio/sfx/plasma_burn.wav',
        wave_clear: 'assets/audio/voice/hq_wave_cleared.wav',
        cannon: 'assets/audio/sfx/gatling_heavy.wav',
        modal: 'assets/audio/sfx/modal.mp3',
        build: 'assets/audio/sfx/build.mp3',
        stomp: 'assets/audio/sfx/titan_stomp.wav',
        siren: 'assets/audio/sfx/emergency_siren.wav',
        hq_online: 'assets/audio/voice/hq_grid_online.wav',
        hq_boss: 'assets/audio/voice/hq_boss_detected.wav',
        hq_airdrop: 'assets/audio/voice/hq_airdrop_inbound.wav',
        hq_core: 'assets/audio/voice/hq_core_critical.wav',
        hero_dash: 'assets/audio/voice/hero_dash.wav',
        hero_ult: 'assets/audio/voice/hero_ult.wav',
        hero_kill: 'assets/audio/voice/hero_kill.wav'
      };
      for (const [key, path] of Object.entries(sfxList)) {
        try {
          if (typeof fetch === 'function' && this.ctx) {
            fetch(path)
              .then(res => { if (!res.ok) throw new Error(); return res.arrayBuffer(); })
              .then(buf => this.ctx ? this.ctx.decodeAudioData(buf) : null)
              .then(decoded => { if (decoded) this.sampleBuffers[key] = decoded; })
              .catch(() => {
                try {
                  const a = new Audio(path);
                  a.preload = 'auto';
                  this.sampleBuffers[key] = a;
                } catch(e) {}
              });
          } else {
            const a = new Audio(path);
            a.preload = 'auto';
            this.sampleBuffers[key] = a;
          }
        } catch(e) {}
      }
    }
    playSample(key, vol = 0.5) {
      if (this.sfxMuted) return false;
      const sfxVol = (window.lastGridEngine && window.lastGridEngine.settings) ? window.lastGridEngine.settings.sfxVol : 1.0;
      if (sfxVol <= 0) return true;
      const finalVol = Math.max(0, Math.min(1, vol * sfxVol));

      const s = this.sampleBuffers && this.sampleBuffers[key];
      if (!s) return false;
      try {
        if (s instanceof AudioBuffer && this.ctx) {
          const src = this.ctx.createBufferSource();
          src.buffer = s;
          const gain = this.ctx.createGain();
          gain.gain.value = finalVol;
          src.connect(gain);
          gain.connect(this.ctx.destination);
          src.start(0);
          return true;
        } else if (s instanceof Audio) {
          const clone = s.cloneNode();
          clone.volume = finalVol;
          clone.play().catch(() => {});
          return true;
        }
      } catch(e) {}
      return false;
    }
    init() {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
      this.loadSamples();
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
      if (!this.bgmPlaying && !this.bgmMuted) this.startBGM();
    }
    toggleSFX() { this.sfxMuted = !this.sfxMuted; return !this.sfxMuted; }
    toggleBGM() {
      this.bgmMuted = !this.bgmMuted;
      if (this.bgmMuted) this.stopBGM();
      else this.startBGM();
      return !this.bgmMuted;
    }
    setBGMVolume(vol) {
      if (this.bgmAudio) {
        try {
          this.bgmAudio.volume = Math.max(0, Math.min(1, vol));
          if (vol <= 0) this.bgmAudio.pause();
          else if (this.bgmAudio.paused && !this.bgmMuted) this.bgmAudio.play().catch(() => {});
        } catch(e) {}
      }
    }
    playBGMTrack(trackName) {
      const bgmVol = (window.lastGridEngine && window.lastGridEngine.settings) ? window.lastGridEngine.settings.bgmVol : 0.7;
      if (this.bgmMuted || bgmVol <= 0) {
        this.stopBGM();
        this.currentBgmName = trackName;
        return;
      }

      if (this.currentBgmName === trackName && ((this.bgmAudio && !this.bgmAudio.paused) || this.bgmTimer)) {
        return;
      }

      this.stopBGM();
      this.currentBgmName = trackName;
      this.bgmTheme = trackName;

      // Unlock AudioContext if present
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      const trackPaths = {
        menu: 'assets/audio/bgm/bgm_menu.wav',
        cyber: 'assets/audio/bgm/bgm_battle_cyber.wav',
        lava: 'assets/audio/bgm/bgm_battle_lava.wav',
        cryo: 'assets/audio/bgm/bgm_battle_cryo.wav',
        boss: 'assets/audio/bgm/bgm_boss_titan.wav',
        victory: 'assets/audio/bgm/bgm_victory.wav'
      };
      const path = trackPaths[trackName] || trackPaths.cyber;

      if (!this.bgmAudioCache) this.bgmAudioCache = {};
      let audioEl = this.bgmAudioCache[trackName];
      if (!audioEl) {
        try {
          audioEl = new Audio(path);
          audioEl.loop = (trackName !== 'victory');
          this.bgmAudioCache[trackName] = audioEl;
        } catch(e) {}
      }

      let audioSucceeded = false;
      if (audioEl) {
        try {
          audioEl.volume = bgmVol;
          audioEl.currentTime = 0;
          const p = audioEl.play();
          if (p && typeof p.then === 'function') {
            p.then(() => {
              this.bgmAudio = audioEl;
              this.bgmPlaying = true;
              this.stopProceduralBGM();
            }).catch(() => {
              // Seamless Web Audio procedural fallback - zero silence guaranteed!
              this.startProceduralBGM(trackName);
            });
            audioSucceeded = true;
          } else {
            this.bgmAudio = audioEl;
            this.bgmPlaying = true;
            audioSucceeded = true;
          }
        } catch(e) {
          audioSucceeded = false;
        }
      }

      if (!audioSucceeded) {
        this.startProceduralBGM(trackName);
      }
    }
    startBGM() {
      const mode = (window.lastGridEngine && window.lastGridEngine.state === 'MENU') ? 'menu' : 'cyber';
      this.playBGMTrack(mode);
    }
    startProceduralBGM(trackName = 'menu') {
      if (this.bgmMuted) return;
      this.bgmTheme = trackName;
      if (this.bgmTimer) return;
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      this.step = 0;
      this.bgmPlaying = true;
      const bpm = (trackName === 'menu') ? 112 : (trackName === 'boss' ? 134 : 124);
      const intervalMs = Math.round((60000 / bpm) / 4); // 16th notes
      this.bgmTimer = setInterval(() => this.bgmTick(this.bgmTheme), intervalMs);
    }
    stopProceduralBGM() {
      if (this.bgmTimer) {
        clearInterval(this.bgmTimer);
        this.bgmTimer = null;
      }
    }
    stopBGM() {
      if (this.bgmAudio) {
        try { this.bgmAudio.pause(); this.bgmAudio.currentTime = 0; } catch(e) {}
        this.bgmAudio = null;
      }
      this.stopProceduralBGM();
      this.bgmPlaying = false;
    }
    bgmTick(theme = 'menu') {
      if (this.bgmMuted || !this.ctx) return;
      const bgmVol = (window.lastGridEngine && window.lastGridEngine.settings) ? window.lastGridEngine.settings.bgmVol : 0.7;
      if (bgmVol <= 0) return;

      const beat16 = this.step % 16;
      const gainScale = bgmVol * 0.45;

      if (theme === 'menu') {
        // Futuristic Cyber Hangar Ambient Music
        if (beat16 === 0 || beat16 === 8) {
          this.playDrum(85, 0.005, 0.18, 0.22 * gainScale, 28);
        }
        if (beat16 % 4 === 2) {
          this.playHiHat(0.025, 0.04 * gainScale);
        }
        const menuMelody = [146.83, 174.61, 220.00, 261.63, 293.66, 349.23, 329.63, 220.00];
        if (beat16 % 2 === 0) {
          const mIdx = Math.floor(this.step / 2) % menuMelody.length;
          this.playSynthNote(menuMelody[mIdx], 0.12, 0.07 * gainScale);
        }
        if (beat16 === 0) {
          const bassNotes = [73.42, 87.31, 98.00, 110.00];
          const bIdx = Math.floor(this.step / 16) % bassNotes.length;
          this.playSynthBass(bassNotes[bIdx], 0.35, 0.08 * gainScale);
        }
      } else if (theme === 'boss') {
        if (beat16 % 4 === 0) this.playDrum(180, 0.001, 0.16, 0.35 * gainScale, 25);
        if (beat16 === 4 || beat16 === 12) this.playSnare(0.12, 0.18 * gainScale);
        if (beat16 % 2 === 1) this.playHiHat(0.04, 0.08 * gainScale);
        const bossBass = [55.00, 58.27, 55.00, 61.74];
        const bIdx = Math.floor(this.step / 4) % bossBass.length;
        this.playSynthBass(bossBass[bIdx], 0.12, 0.14 * gainScale);
      } else {
        if (beat16 % 4 === 0) this.playDrum(150, 0.001, 0.12, 0.25 * gainScale, 30);
        if (beat16 === 4 || beat16 === 12) this.playSnare(0.08, 0.12 * gainScale);
        if (beat16 % 2 === 1) this.playHiHat(0.03, 0.06 * gainScale);
        const bassIndex = Math.floor(this.step / 8) % this.bassNotes.length;
        const baseFreq = this.bassNotes[bassIndex];
        const oct = (beat16 % 4 === 2) ? 2 : 1;
        this.playSynthBass(baseFreq * oct, 0.09, 0.09 * gainScale);
        if (beat16 % 4 === 0 || beat16 % 4 === 3) {
          const sIdx = Math.floor(this.step / 4) % this.scale.length;
          this.playSynthNote(this.scale[sIdx] * 2, 0.08, 0.05 * gainScale);
        }
      }
      this.step++;
    }
    playSynthNote(freq, duration, gainVal) {
      if (!this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1600, this.ctx.currentTime);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch(e) {}
    }
    playDrum(freq, attack, duration, gainVal, slideTo) {
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(slideTo, this.ctx.currentTime + duration);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {}
    }
    playSnare(duration, gainVal) {
      try {
        const bufferSize = this.ctx.sampleRate * duration;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 1000;
        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        noise.start();
      } catch (e) {}
    }
    playHiHat(duration, gainVal) {
      try {
        const bufferSize = this.ctx.sampleRate * duration;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 8000;
        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        noise.start();
      } catch (e) {}
    }
    playSynthBass(freq, duration, gainVal) {
      try {
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(800, this.ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(200, this.ctx.currentTime + duration);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {}
    }
    playTone(freq, type, duration, gainVal = 0.1, slideTo = null) {
      if (this.sfxMuted || !this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(10, slideTo), this.ctx.currentTime + duration);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {}
    }
    click() {
      if (!this.playSample('click', 0.5)) this.playTone(900, 'triangle', 0.04, 0.06, 600);
    }
    modal() {
      if (!this.playSample('modal', 0.55)) this.playTone(520, 'sine', 0.12, 0.09, 780);
    }
    waveClear() {
      if (!this.playSample('wave_clear', 0.7)) this.victory();
    }
    build() {
      if (!this.playSample('build', 0.6)) this.upgrade();
    }
    shootPulse() {
      if (!this.playSample('laser', 0.35)) this.playTone(850, 'sawtooth', 0.08, 0.06, 200);
    }
    shootMortar() {
      if (!this.playSample('cannon', 0.55)) this.playTone(180, 'triangle', 0.35, 0.15, 35);
    }
    shootCryo() {
      if (!this.playSample('zap', 0.45)) this.playTone(650, 'sine', 0.22, 0.08, 1100);
    }
    shootRailgun() {
      if (!this.playSample('laser', 0.65)) {
        this.playTone(120, 'sawtooth', 0.3, 0.18, 40);
        this.playTone(1200, 'square', 0.15, 0.08, 300);
      }
    }
    upgrade() {
      if (!this.playSample('build', 0.55)) {
        this.playTone(440, 'triangle', 0.1, 0.1, 660);
        setTimeout(() => this.playTone(660, 'triangle', 0.15, 0.1, 880), 80);
      }
    }
    sell() {
      this.playTone(700, 'sine', 0.08, 0.1, 950);
      setTimeout(() => this.playTone(950, 'sine', 0.12, 0.1, 1200), 70);
    }
    hit() { this.playTone(140, 'square', 0.05, 0.04, 60); }
    leak() { this.playTone(220, 'sawtooth', 0.3, 0.2, 90); }
    heroSlash() {
      this.playTone(400, 'sawtooth', 0.2, 0.15, 80);
      this.playTone(900, 'triangle', 0.25, 0.12, 200);
    }
    emp() {
      this.playTone(1200, 'sawtooth', 0.4, 0.2, 80);
      this.playTone(300, 'square', 0.5, 0.15, 60);
    }
    orbital() {
      this.playTone(80, 'sawtooth', 0.6, 0.25, 40);
      this.playTone(1500, 'sawtooth', 0.5, 0.2, 200);
    }
    victory() {
      if (!this.playSample('wave_clear', 0.75)) {
        [440, 554, 659, 880].forEach((f, i) => setTimeout(() => this.playTone(f, 'triangle', 0.25, 0.15), i * 120));
      }
    }
    airdropFlyby() {
      this.playTone(90, 'triangle', 0.8, 0.12, 160);
      setTimeout(() => this.playTone(160, 'triangle', 0.8, 0.1, 80), 300);
    }
    airdropLoot() {
      [523, 659, 783, 1046].forEach((f, i) => setTimeout(() => this.playTone(f, 'square', 0.18, 0.12), i * 70));
    }
    bossSiren() {
      // 2-tone cycling high-urgency emergency tactical alert siren
      [580, 880, 580, 880, 520, 780].forEach((f, i) => {
        setTimeout(() => this.playTone(f, 'sawtooth', 0.28, 0.25, f * 0.8), i * 250);
      });
    }
    redZoneSiren() {
      this.playTone(600, 'sawtooth', 0.35, 0.18, 300);
      setTimeout(() => this.playTone(750, 'sawtooth', 0.35, 0.18, 400), 200);
    }
    artilleryBlast() {
      if (!this.playSample('explosion', 0.7)) {
        this.playTone(70, 'sawtooth', 0.45, 0.25, 30);
        this.playTone(140, 'triangle', 0.3, 0.2, 40);
      }
    }
    barricadeHit() {
      this.playTone(110, 'square', 0.08, 0.12, 50);
    }
    barricadeBreak() {
      this.playTone(180, 'sawtooth', 0.4, 0.25, 45);
      this.playTone(90, 'square', 0.5, 0.2, 30);
    }
    radioBeep() {
      this.playTone(880, 'sine', 0.05, 0.08);
      setTimeout(() => this.playTone(1174, 'sine', 0.07, 0.08), 60);
    }
    radioChirp() {
      this.playTone(1800, 'sine', 0.04, 0.1, 2400);
      setTimeout(() => this.playTone(2400, 'sine', 0.05, 0.08, 1200), 50);
      this.playNoise(0.06, 0.03);
    }
    voiceRadio(text, sampleKey) {
      if (this.sfxMuted) return;
      this.radioChirp();
      if (sampleKey && this.playSample(sampleKey, 0.95)) {
        return;
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
          const cleanText = (text || "").replace(/[^\w\s.,!?:-]/gi, ' ').trim();
          if (cleanText) {
            const u = new SpeechSynthesisUtterance(cleanText);
            u.pitch = 0.85;
            u.rate = 1.08;
            u.volume = 0.85;
            const voices = window.speechSynthesis.getVoices();
            const v = voices.find(x => x.lang.startsWith('en') && (x.name.includes('Google') || x.name.includes('Natural') || x.name.includes('Robot')));
            if (v) u.voice = v;
            window.speechSynthesis.speak(u);
          }
        } catch(e) {}
      }
    }
    defeat() {
      [330, 293, 261, 196].forEach((f, i) => setTimeout(() => this.playTone(f, 'sawtooth', 0.35, 0.2, 80), i * 150));
    }
    mechTransform() {
      this.playTone(350, 'sawtooth', 0.18, 0.18, 120);
      setTimeout(() => this.playTone(180, 'square', 0.22, 0.20, 60), 80);
      setTimeout(() => this.playTone(550, 'triangle', 0.15, 0.15, 800), 180);
    }
    shootTesla() {
      this.playTone(1400, 'sawtooth', 0.12, 0.14, 250);
      this.playNoise(0.10, 0.08);
    }
    shootFlame() {
      this.playNoise(0.22, 0.12);
      this.playTone(120, 'sawtooth', 0.18, 0.08, 60);
    }
    missileLaunch() {
      this.playTone(280, 'sawtooth', 0.25, 0.15, 950);
      this.playNoise(0.18, 0.06);
    }
    shieldDome() {
      this.playTone(440, 'sine', 0.45, 0.18, 880);
      setTimeout(() => this.playTone(880, 'sine', 0.35, 0.12, 1320), 120);
    }
    kamikazeBeep() {
      this.playTone(1800, 'square', 0.05, 0.15);
    }
  }

  const audio = new SoundSynth();

  // --- MAP DEFINITIONS ---
  // --- 10 CAMPAIGN MAPS: TACTICAL DESTRUCTIBLE BARRICADES ---
  const MAP_BARRICADES = [
    // Map 0: Training Grid
    [ { x: 384, y: 320, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 896, y: 352, hp: 350, maxHp: 350, type: 'reinforced' } ],
    // Map 1: Crossroads
    [ { x: 448, y: 256, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 700, y: 384, hp: 350, maxHp: 350, type: 'reinforced' } ],
    // Map 2: Spiral Core
    [ { x: 550, y: 64, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 192, y: 380, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 640, y: 448, hp: 350, maxHp: 350, type: 'reinforced' } ],
    // Map 3: Misty Pass
    [ { x: 384, y: 320, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 640, y: 320, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 896, y: 320, hp: 350, maxHp: 350, type: 'reinforced' } ],
    // Map 4: Fast Track
    [ { x: 400, y: 256, hp: 400, maxHp: 400, type: 'reinforced' }, { x: 750, y: 256, hp: 400, maxHp: 400, type: 'reinforced' } ],
    // Map 5: Scrap Yard
    [ { x: 450, y: 128, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 480, y: 384, hp: 350, maxHp: 350, type: 'reinforced' }, { x: 700, y: 576, hp: 350, maxHp: 350, type: 'reinforced' } ],
    // Map 6: Iron Wall (Heavy Fortified)
    [ { x: 130, y: 320, hp: 550, maxHp: 550, type: 'fortified' }, { x: 576, y: 512, hp: 550, maxHp: 550, type: 'fortified' }, { x: 1056, y: 320, hp: 550, maxHp: 550, type: 'fortified' } ],
    // Map 7: Blackout City
    [ { x: 320, y: 288, hp: 380, maxHp: 380, type: 'reinforced' }, { x: 640, y: 320, hp: 380, maxHp: 380, type: 'reinforced' }, { x: 960, y: 352, hp: 380, maxHp: 380, type: 'reinforced' } ],
    // Map 8: Twin Gate (Dual Choke Points)
    [ { x: 350, y: 192, hp: 400, maxHp: 400, type: 'reinforced' }, { x: 350, y: 448, hp: 400, maxHp: 400, type: 'reinforced' }, { x: 850, y: 320, hp: 400, maxHp: 400, type: 'reinforced' } ],
    // Map 9: The Last Grid (Ultimate 4 Fortified Barricades)
    [ { x: 600, y: 64, hp: 500, maxHp: 500, type: 'fortified' }, { x: 600, y: 256, hp: 500, maxHp: 500, type: 'fortified' }, { x: 600, y: 448, hp: 500, maxHp: 500, type: 'fortified' }, { x: 850, y: 576, hp: 500, maxHp: 500, type: 'fortified' } ]
  ];

  const RADIO_BRIEFINGS = {
    uz: [
      "Operatsiya: Training Grid! Minora va to'siqlarni sinovdan o'tkazamiz.",
      "Operatsiya: Crossroads! Dushmanlar to'g'ri chiziqda, to'siqlarni mustahkamlang!",
      "Operatsiya: Spiral Core! Girdob markaziga Mortar va Cryo joylashtiring!",
      "Operatsiya: Misty Pass! Tumanli dovonda dushman ko'rinishi past, ehtiyot bo'ling!",
      "Operatsiya: Fast Track! Tezyurar yo'l! Dushmanlar +15% tezroq yuguradi!",
      "Operatsiya: Scrap Yard! Resurslar taqchil! Har bir o'qni hisoblab tejang!",
      "Operatsiya: Iron Wall! Og'ir himoyalangan devor! Railgun lazerlarini tayyorlang!",
      "Operatsiya: Blackout City! Kiber-shahar! Davriy EMP to'lqinlari kutilmoqda!",
      "Operatsiya: Twin Gate! Ikki tomondan parallel hujum! Kuchlarni teng taqsimlang!",
      "Operatsiya: The Last Grid! So'nggi istehkom! 3 ta Titan Boss kutmoqda. Baza himoyasi sizga omonat!"
    ],
    en: [
      "Operation: Training Grid! Calibrate all defense turrets and barricades.",
      "Operation: Crossroads! Enemies advancing along straight vectors. Hold the barriers!",
      "Operation: Spiral Core! Dense inward spiral. Optimal for Mortar and Cryo AoE.",
      "Operation: Misty Pass! Dense fog detected. Sensor range reduced by 15%.",
      "Operation: Fast Track! Magnetic highway. Enemy speed increased by 15%!",
      "Operation: Scrap Yard! Scarce resources. Conserve gold and fortify barricades.",
      "Operation: Iron Wall! Heavily fortified enemy zone. Deploy armor-piercing Railguns!",
      "Operation: Blackout City! Cyber-metropolis. Beware periodic EMP power surges!",
      "Operation: Twin Gate! Converging dual vector assault. Split defensive coverage!",
      "Operation: The Last Grid! Final endurance sector. 3 Titan Bosses incoming. Defend the Core!"
    ],
    ru: [
      "Операция: Training Grid! Калибровка башен и тактических баррикад.",
      "Операция: Crossroads! Враги наступают по прямым коридорам. Удерживайте заслоны!",
      "Операция: Spiral Core! Спиральный сектор. Оптимально для мортир и заморозки.",
      "Операция: Misty Pass! Электромагнитный туман снижает радиус огня на 15%.",
      "Операция: Fast Track! Магнитное шоссе. Враги двигаются на 15% быстрее!",
      "Операция: Scrap Yard! Дефицит ресурсов. Экономьте золото и чините баррикады.",
      "Операция: Iron Wall! Бронированная зона. Применяйте рельсотроны с пробитием!",
      "Операция: Blackout City! Кибер-мегаполис. Остерегайтесь периодических ЭМИ-вспышек!",
      "Операция: Twin Gate! Сходящиеся векторы атаки. Распределяйте турели равномерно!",
      "Операция: The Last Grid! Финальный сектор. 3 Титана. Защитите Ядро любой ценой!"
    ]
  };

  const MAPS = [
    {
      id: "training_grid", name: "Training Grid", desc: "Basic S-curve test field. Clean terrain with single lane.",
      wave_count: 10, gold: 250, hp: 20, modifier: "none", biome: "cyber",
      lanes: [ [ {x:64, y:192}, {x:384, y:192}, {x:384, y:448}, {x:896, y:448}, {x:896, y:256}, {x:1152, y:256} ] ]
    },
    {
      id: "crossroads", name: "Crossroads", desc: "Interconnected straight corridors with multiple defense pockets.",
      wave_count: 12, gold: 250, hp: 20, modifier: "none", biome: "cyber",
      lanes: [ [ {x:64, y:128}, {x:448, y:128}, {x:448, y:384}, {x:896, y:384}, {x:1152, y:384} ] ]
    },
    {
      id: "spiral_core", name: "Spiral Core", desc: "Concentric inward spiral. Optimal for Mortar and Cryo AoE setups.",
      wave_count: 15, gold: 250, hp: 20, modifier: "none", biome: "lava",
      lanes: [ [ {x:64, y:96}, {x:1152, y:96}, {x:1152, y:576}, {x:192, y:576}, {x:192, y:192}, {x:960, y:192}, {x:960, y:448}, {x:384, y:448}, {x:384, y:320}, {x:640, y:320} ] ]
    },
    {
      id: "misty_pass", name: "Misty Pass", desc: "Dense electromagnetic fog reduces all tower ranges by -15%.",
      wave_count: 15, gold: 250, hp: 20, modifier: "fog", biome: "cryo",
      lanes: [ [ {x:64, y:320}, {x:256, y:128}, {x:512, y:512}, {x:768, y:128}, {x:1024, y:512}, {x:1152, y:320} ] ]
    },
    {
      id: "fast_track", name: "Fast Track", desc: "High-speed magnetic highway. All enemies move +15% faster!",
      wave_count: 20, gold: 260, hp: 20, modifier: "fast_lane", biome: "cyber",
      lanes: [ [ {x:64, y:256}, {x:1152, y:256} ] ]
    },
    {
      id: "scrap_yard", name: "Scrap Yard", desc: "Resource-starved industrial ruins. Enemy bounties reduced by -20%.",
      wave_count: 20, gold: 240, hp: 20, modifier: "scarce", biome: "lava",
      lanes: [ [ {x:64, y:128}, {x:768, y:128}, {x:768, y:384}, {x:256, y:384}, {x:256, y:576}, {x:1152, y:576} ] ]
    },
    {
      id: "iron_wall", name: "Iron Wall", desc: "Fortified barrier zone. All enemy units gain +20% bonus armor.",
      wave_count: 25, gold: 280, hp: 20, modifier: "armored", biome: "cyber",
      lanes: [ [ {x:64, y:128}, {x:192, y:512}, {x:960, y:512}, {x:1152, y:128} ] ]
    },
    {
      id: "blackout_city", name: "Blackout City", desc: "Cybernetic metropolis with periodic EMP surges every 5 waves.",
      wave_count: 25, gold: 280, hp: 20, modifier: "blackout", biome: "cryo",
      lanes: [ [ {x:64, y:128}, {x:320, y:128}, {x:320, y:448}, {x:640, y:448}, {x:640, y:192}, {x:960, y:192}, {x:960, y:512}, {x:1152, y:512} ] ]
    },
    {
      id: "twin_gate", name: "Twin Gate", desc: "Dual converging vectors converging directly into the central core.",
      wave_count: 30, gold: 300, hp: 20, modifier: "double_lane", biome: "lava",
      lanes: [
        [ {x:64, y:192}, {x:512, y:192}, {x:640, y:320}, {x:1152, y:320} ],
        [ {x:64, y:448}, {x:512, y:448}, {x:640, y:320}, {x:1152, y:320} ]
      ]
    },
    {
      id: "last_grid", name: "The Last Grid", desc: "Final endurance sector: full 30 waves with 3 Boss encounters!",
      wave_count: 30, gold: 350, hp: 25, modifier: "last_grid", biome: "cyber",
      lanes: [ [ {x:64, y:96}, {x:1152, y:96}, {x:1152, y:256}, {x:128, y:256}, {x:128, y:448}, {x:1152, y:448}, {x:1152, y:576}, {x:640, y:576} ] ]
    }
  ];

  // --- TOWER BLUEPRINTS & BRANCHING SPECIALIZATIONS (TIER 3) ---
  // Calibrated with Cyberpunk 2077 & Valorant Weapon Statistics
  const TOWER_DEFS = {
    wall: {
      id: "wall", name: "Barricade Wall", type: "DEFENSE", color: "#78909c", cost: 40, desc: "Armored barricade wall that obstructs ground hostiles.",
      targetsAir: false, projSpeed: 0,
      tiers: [
        { hp: 400, range: 40, upCost: 28 },
        { hp: 600, range: 40, upCost: 40 },
        { hp: 900, range: 40, upCost: 56 }
      ],
      branches: {
        A: { name: "Spike Barrier", hp: 1200, reflect: 0.30, color: "#ff7043", perk: "thorns", cost: 80, desc: "Reflects 30% melee damage back to attackers." },
        B: { name: "Electrified Gate", hp: 1000, zapDmg: 40, color: "#ffd600", perk: "electrified", cost: 85, desc: "Zaps adjacent attackers every second." }
      }
    },
    pulse: {
      id: "pulse", name: "Pulse Tower", type: "KINETIC", color: "#00e5ff", cost: 100, desc: "Rapid-fire kinetic tracer gun.",
      tiers: [
        { dmg: 14, rate: 4.8, range: 145, upCost: 120 },
        { dmg: 22, rate: 6.2, range: 160, upCost: 200 },
        { dmg: 32, rate: 8.0, range: 175, upCost: 0 }
      ],
      branches: {
        A: { name: "Gatling Shredder", dmg: 24, rate: 12.0, range: 170, color: "#00e5ff", perk: "shred", cost: 260, desc: "Fires 12 rps (CP77 SMG archetype). Shreds 1 armor per hit." },
        B: { name: "Sniper Rail-Pulse", dmg: 340, rate: 1.15, range: 320, color: "#00b0ff", perk: "sniper", cost: 290, desc: "Extreme range (CP77 Tech Sniper archetype). 300% crit on bosses." }
      }
    },
    mortar: {
      id: "mortar", name: "Mortar Tower", type: "EXPLOSIVE", color: "#ff9100", cost: 150, desc: "Long-range explosive shell with area splash.",
      tiers: [
        { dmg: 55, rate: 0.85, range: 210, splash: 65, upCost: 150 },
        { dmg: 85, rate: 0.95, range: 225, splash: 80, upCost: 250 },
        { dmg: 130, rate: 1.05, range: 240, splash: 95, upCost: 0 }
      ],
      branches: {
        A: { name: "Cluster Bomb", dmg: 110, rate: 1.0, range: 235, splash: 85, color: "#ff9100", perk: "cluster", cost: 280, desc: "Detonates into 4 secondary cluster bomblets." },
        B: { name: "Napalm Cyber-Fire", dmg: 75, rate: 0.9, range: 225, splash: 100, color: "#ff3d00", perk: "napalm", cost: 290, desc: "Leaves cyber-fire pool on path (50 DoT)." }
      }
    },
    cryo: {
      id: "cryo", name: "Cryo Tower", type: "ENERGY", color: "#00f0ff", cost: 120, desc: "Cryogenic emitter that slows hostiles.",
      tiers: [
        { dmg: 6, rate: 1.8, range: 140, slow: 0.35, slowDur: 2.5, upCost: 140 },
        { dmg: 10, rate: 2.0, range: 155, slow: 0.45, slowDur: 3.0, upCost: 220 },
        { dmg: 16, rate: 2.2, range: 170, slow: 0.55, slowDur: 3.5, upCost: 0 }
      ],
      branches: {
        A: { name: "Blizzard Zero", dmg: 25, rate: 2.0, range: 175, slow: 1.0, slowDur: 2.0, color: "#00f0ff", perk: "freeze_solid", cost: 270, desc: "100% frozen solid stun + 50% shatter dmg." },
        B: { name: "Tesla Chain-Frost", dmg: 55, rate: 1.8, range: 185, slow: 0.5, slowDur: 3.0, color: "#76ff03", perk: "tesla_chain", cost: 300, desc: "Chains electric arc to 3 nearby targets with EMP zap." }
      }
    },
    railgun: {
      id: "railgun", name: "Railgun Tower", type: "PIERCE", color: "#ff007f", cost: 250, desc: "High-voltage magnetic beam piercing targets.",
      tiers: [
        { dmg: 160, rate: 0.65, range: 250, pierce: 1, upCost: 260 },
        { dmg: 260, rate: 0.75, range: 275, pierce: 2, upCost: 380 },
        { dmg: 400, rate: 0.85, range: 300, pierce: 3, upCost: 0 }
      ],
      branches: {
        A: { name: "Hyper Beam Laser", dmg: 650, rate: 1.2, range: 310, pierce: 5, color: "#ff007f", perk: "hyper_beam", cost: 420, desc: "Continuous sustained plasma beam laser." },
        B: { name: "Ion Disrupter", dmg: 460, rate: 0.8, range: 290, pierce: 99, color: "#d500f9", perk: "ion_strip", cost: 390, desc: "Instantly strips all enemy shields and pierces all." }
      }
    },
    beacon: {
      id: "beacon", name: "Beacon Tower", type: "SUPPORT", color: "#b388ff", cost: 180, desc: "Buff aura: +35% damage & +20% range to nearby towers.",
      tiers: [
        { dmgBuff: 0.35, rangeBuff: 0.20, range: 130, upCost: 200 },
        { dmgBuff: 0.45, rangeBuff: 0.25, range: 150, upCost: 320 },
        { dmgBuff: 0.55, rangeBuff: 0.30, range: 170, upCost: 0 }
      ],
      branches: {
        A: { name: "Overcharge Reactor", dmgBuff: 0.80, rangeBuff: 0.35, rateBuff: 0.20, range: 180, color: "#b388ff", perk: "overcharge", cost: 360, desc: "+80% dmg & +20% fire rate to nearby towers." },
        B: { name: "Tactical Radar", dmgBuff: 0.40, rangeBuff: 0.60, range: 220, color: "#e040fb", perk: "radar", cost: 340, desc: "+60% range and permanently reveals Phantoms." }
      }
    },
    tesla: {
      id: "tesla", name: "Tesla Coil", type: "ENERGY", color: "#ffd600", cost: 180, desc: "High-voltage coil arcing chain lightning across hostiles.",
      tiers: [
        { dmg: 45, rate: 1.2, range: 160, chainCount: 3, upCost: 180 },
        { dmg: 75, rate: 1.4, range: 180, chainCount: 4, upCost: 280 },
        { dmg: 115, rate: 1.6, range: 200, chainCount: 5, upCost: 0 }
      ],
      branches: {
        A: { name: "Overcharge Arc", dmg: 190, rate: 1.8, range: 220, chainCount: 6, color: "#ffd600", perk: "emp_shock", cost: 380, desc: "Fires lightning arcs that EMP-stun mechanical hostiles." },
        B: { name: "Tesla Storm Aura", dmg: 95, rate: 3.5, range: 210, chainCount: 8, color: "#76ff03", perk: "storm_aura", cost: 360, desc: "Discharges a continuous 360-degree storm field frying all hostiles." }
      }
    },
    flame: {
      id: "flame", name: "Flamethrower", type: "FIRE", color: "#ff3d00", cost: 160, desc: "Continuous conical plasma flame spray applying heavy burning DOT.",
      targetsAir: false,
      tiers: [
        { dmg: 18, rate: 8.0, range: 135, coneAngle: 0.65, dotDmg: 20, dotDur: 3.0, upCost: 160 },
        { dmg: 28, rate: 9.0, range: 150, coneAngle: 0.70, dotDmg: 35, dotDur: 3.5, upCost: 240 },
        { dmg: 42, rate: 10.0, range: 165, coneAngle: 0.75, dotDmg: 55, dotDur: 4.0, upCost: 0 }
      ],
      branches: {
        A: { name: "Napalm Inferno", dmg: 55, rate: 11.0, range: 180, coneAngle: 0.85, dotDmg: 90, dotDur: 5.0, color: "#ff3d00", perk: "ground_fire", cost: 350, desc: "Ignites ground, leaving persistent plasma fire puddles." },
        B: { name: "Plasma Blaze", dmg: 75, rate: 10.0, range: 175, coneAngle: 0.75, dotDmg: 70, dotDur: 4.0, color: "#00e5ff", perk: "armor_melt", cost: 370, desc: "Extreme heat melts 70% of hostile armor permanently." }
      }
    }
  };
  TOWER_DEFS.barricade = TOWER_DEFS.wall;

  // --- ROGUELIKE AUGMENT POOL (DRAFT 1 OF 3 EVERY 5 WAVES) ---
  const AUGMENT_POOL = [
    { id: "bounty_hunter", title: "BOUNTY HUNTER", desc: "+30% Gold bounty from all kills, but enemies move +10% faster.", icon: "🪙", color: "#ffd600" },
    { id: "shatter_frost", title: "SHATTER FROST", desc: "All towers deal +80% bonus damage to slowed/frozen hostiles.", icon: "❄️", color: "#00f0ff" },
    { id: "titan_slayer", title: "TITAN SLAYER", desc: "All towers deal +45% extra damage to Bosses and heavy Brutes.", icon: "⚔️", color: "#ff1744" },
    { id: "overclock_matrix", title: "OVERCLOCK MATRIX", desc: "Permanently increases all friendly towers' fire rate by +20%.", icon: "⚡", color: "#00e5ff" },
    { id: "superconductors", title: "SUPERCONDUCTORS", desc: "Railgun and Pulse attacks chain electric sparks to 2 nearby targets.", icon: "⚡", color: "#76ff03" },
    { id: "reactive_core", title: "REACTIVE CORE", desc: "Base Core reflects 50% leak damage back as an area EMP stun.", icon: "🛡️", color: "#ff007f" },
    { id: "nanite_repair", title: "NANITE REPAIR", desc: "Base Core automatically repairs +2 HP at the end of each wave.", icon: "💚", color: "#00e676" },
    { id: "cluster_munitions", title: "CLUSTER MUNITIONS", desc: "Mortar splash explosion radius and damage increased by +35%.", icon: "💥", color: "#ff9100" },
    { id: "hero_overdrive", title: "HERO OVERDRIVE", desc: "Field Hero Champion gains +60% melee damage and moves +25% faster.", icon: "🤖", color: "#b388ff" },
    { id: "plasma_inferno", title: "PLASMA INFERNO", desc: "Flame & Tesla attacks cause burning to chain to nearby enemies (+45% DoT).", icon: "🔥", color: "#ff3d00" },
    { id: "tesla_overcharge", title: "TESLA OVERCHARGE", desc: "Tesla Coil arcs to +3 extra targets, and EMP shockwaves inflict 2.5x stun.", icon: "⚡", color: "#ffd600" },
    { id: "nanite_aegis", title: "NANITE AEGIS", desc: "Shield Dome gains +500 HP and reflects 50% absorbed damage back as homing bolts.", icon: "🛡️", color: "#00e5ff" },
    { id: "siege_artillery_core", title: "SIEGE ARTILLERY", desc: "Siege Tank mode deals +60% explosion splash damage and creates burning craters.", icon: "🚜", color: "#ff9100" },
    { id: "void_collector", title: "VOID COLLECTOR", desc: "Slain hostiles award +3 gold per 5 kills and charge Mech Ult 2x faster.", icon: "🌌", color: "#b388ff" },
    { id: "chronos_overdrive", title: "CHRONOS OVERDRIVE", desc: "Mech movement speed +30%, and all skill cooldowns recharge 35% quicker.", icon: "⌛", color: "#76ff03" }
  ];

  // --- ENEMY BLUEPRINTS ---
  const ENEMY_DEFS = {
    scout:        { name: "Scout",        hp: 40,  shield: 0,   armor: 0,  spd: 96, bounty: 3,  color: "#ffd600", size: 10, marker: "▲", isFlyer: false },
    grunt:        { name: "Grunt",        hp: 100, shield: 0,   armor: 0,  spd: 60, bounty: 5,  color: "#ff5252", size: 12, marker: "●", isFlyer: false },
    tank:         { name: "Tank",         hp: 400, shield: 0,   armor: 12, armorReduction: 0.30, spd: 36, bounty: 16, color: "#d50000", size: 18, marker: "■", isFlyer: false },
    flyer:        { name: "Flyer",        hp: 70,  shield: 0,   armor: 0,  spd: 84, bounty: 6,  color: "#00e5ff", size: 11, marker: "✈", isFlyer: true },
    swarm:        { name: "Swarm",        hp: 25,  shield: 0,   armor: 0,  spd: 78, bounty: 2,  color: "#ffab00", size: 7,  marker: "◆", isFlyer: false },
    shielded:     { name: "Shielded",     hp: 120, shield: 150, armor: 4,  spd: 54, bounty: 12, color: "#00b0ff", size: 14, marker: "🛡", isFlyer: false },
    boss:         { name: "Titan Boss",   hp: 3000, shield: 0,  armor: 15, spd: 30, bounty: 150, color: "#ff1744", size: 28, isBoss: true, marker: "☠", isFlyer: false },

    // Backwards-compatible aliases
    sprinter:     { name: "Sprinter",     hp: 40,  shield: 0,   armor: 0,  spd: 96, bounty: 3,  color: "#ffd600", size: 10, marker: "▲", isFlyer: false },
    brute:        { name: "Brute",        hp: 400, shield: 0,   armor: 12, armorReduction: 0.30, spd: 36, bounty: 16, color: "#d50000", size: 18, marker: "■", isFlyer: false },
    swarmling:    { name: "Swarmling",    hp: 25,  shield: 0,   armor: 0,  spd: 78, bounty: 2,  color: "#ffab00", size: 7,  marker: "◆", isFlyer: false },
    shieldbearer: { name: "Shieldbearer", hp: 120, shield: 150, armor: 4,  spd: 54, bounty: 12, color: "#00b0ff", size: 14, marker: "🛡", isFlyer: false },
    medic:        { name: "Medic",        hp: 150, shield: 0,   armor: 0,  spd: 50, bounty: 14, color: "#00e676", size: 13, marker: "✚", isFlyer: false },
    splitter:     { name: "Splitter",     hp: 250, shield: 0,   armor: 3,  spd: 55, bounty: 10, color: "#e040fb", size: 15, marker: "✦", isFlyer: false },
    phantom:      { name: "Phantom",      hp: 180, shield: 0,   armor: 0,  spd: 75, bounty: 12, color: "#7c4dff", size: 14, marker: "★", isFlyer: false },
    gunship:      { name: "Gunship",      hp: 240, shield: 100, armor: 6,  spd: 72, bounty: 18, color: "#00e5ff", size: 16, marker: "🚁", isFlyer: true },
    kamikaze:     { name: "Kamikaze",     hp: 65,  shield: 0,   armor: 0,  spd: 120, bounty: 8,  color: "#ff3d00", size: 11, marker: "💣", isFlyer: false, isKamikaze: true },
    siege_breaker:{ name: "Siege Breaker",hp: 1250,shield: 300, armor: 22, armorReduction: 0.40, spd: 32, bounty: 45, color: "#7c4dff", size: 24, marker: "🗿", isFlyer: false, isSiegeBreaker: true },
    juggernaut:   { name: "BOSS: Juggernaut", hp: 3000,  shield: 0, armor: 15, spd: 30, bounty: 150, color: "#ff1744", size: 28, isBoss: true, marker: "☠", isFlyer: false },
    overseer:     { name: "BOSS: Overseer",   hp: 4500,  shield: 500, armor: 12, spd: 32, bounty: 200, color: "#651fff", size: 30, isBoss: true, marker: "👁", isFlyer: false },
    hive_titan:   { name: "BOSS: Hive Titan", hp: 6500,  shield: 0, armor: 18, spd: 28, bounty: 250, color: "#f50057", size: 34, isBoss: true, marker: "☣", isFlyer: false },
    void_titan:   { name: "BOSS: Void Titan", hp: 8500,  shield: 1200, armor: 20, armorReduction: 0.35, spd: 26, bounty: 300, color: "#9c27b0", size: 36, isBoss: true, isVoidTitan: true, marker: "🌌", isFlyer: false },
    chrono_phantom:{ name: "BOSS: Chrono Phantom", hp: 7200, shield: 800, armor: 14, spd: 34, bounty: 280, color: "#00e5ff", size: 32, isBoss: true, isChronoPhantom: true, marker: "⌛", isFlyer: false },
    mecha_colossus:{ name: "BOSS: Mecha Colossus", hp: 11000, shield: 1500, armor: 26, armorReduction: 0.45, spd: 24, bounty: 450, color: "#ffd600", size: 38, isBoss: true, isMechaColossus: true, marker: "🤖", isFlyer: false }
  };

  // --- BTD6-POWERED WAVE PROGRESSION & CHOREOGRAPHY ---
  // Calibrated with Bloons TD 6 Round Balance Dataset (brandonconrady/bloons-tower-defense-6-rounds-1140)
  const CAMPAIGN_WAVES_BTD6 = [
    // W1 - W5: Early Recon & Sprinter Rush
    [ { type: "grunt", count: 15, interval: 0.9 } ],
    [ { type: "grunt", count: 25, interval: 0.75 } ],
    [ { type: "grunt", count: 18, interval: 0.7 }, { type: "sprinter", count: 8, interval: 0.6 } ],
    [ { type: "sprinter", count: 22, interval: 0.45 } ],
    [ { type: "grunt", count: 15, interval: 0.6 }, { type: "sprinter", count: 18, interval: 0.5 } ],

    // W6 - W10: Swarm Vanguard & Heavy Armor Wall & Boss 1
    [ { type: "swarmling", count: 35, interval: 0.28 } ],
    [ { type: "grunt", count: 15, interval: 0.6 }, { type: "swarmling", count: 20, interval: 0.3 }, { type: "kamikaze", count: 6, interval: 0.8 } ],
    [ { type: "brute", count: 6, interval: 1.2 }, { type: "grunt", count: 14, interval: 0.7 } ],
    [ { type: "brute", count: 8, interval: 1.0 }, { type: "sprinter", count: 14, interval: 0.5 }, { type: "gunship", count: 5, interval: 1.2 } ],
    [ { type: "juggernaut", count: 1, interval: 2.5 }, { type: "grunt", count: 18, interval: 0.65 } ],

    // W11 - W15: Energy Shields, Medics & Stealth Phantoms
    [ { type: "shieldbearer", count: 8, interval: 0.8 }, { type: "sprinter", count: 15, interval: 0.5 } ],
    [ { type: "shieldbearer", count: 12, interval: 0.7 }, { type: "swarmling", count: 30, interval: 0.3 } ],
    [ { type: "medic", count: 8, interval: 0.8 }, { type: "grunt", count: 18, interval: 0.6 }, { type: "kamikaze", count: 8, interval: 0.7 } ],
    [ { type: "medic", count: 10, interval: 0.7 }, { type: "shieldbearer", count: 12, interval: 0.7 }, { type: "gunship", count: 6, interval: 1.0 } ],
    [ { type: "phantom", count: 14, interval: 0.65 }, { type: "sprinter", count: 16, interval: 0.5 } ],

    // W16 - W20: Splitters & Combined Arms & Boss 2
    [ { type: "phantom", count: 18, interval: 0.6 }, { type: "brute", count: 8, interval: 1.1 } ],
    [ { type: "splitter", count: 12, interval: 0.9 }, { type: "shieldbearer", count: 10, interval: 0.7 }, { type: "siege_breaker", count: 2, interval: 2.2 } ],
    [ { type: "splitter", count: 16, interval: 0.8 }, { type: "medic", count: 10, interval: 0.7 } ],
    [ { type: "phantom", count: 15, interval: 0.6 }, { type: "brute", count: 10, interval: 0.9 }, { type: "gunship", count: 8, interval: 0.9 } ],
    [ { type: "overseer", count: 1, interval: 2.5 }, { type: "phantom", count: 16, interval: 0.6 }, { type: "shieldbearer", count: 12, interval: 0.65 } ],

    // W21 - W25: High-Voltage Swarms & Mini-Boss Surge
    [ { type: "splitter", count: 18, interval: 0.75 }, { type: "kamikaze", count: 12, interval: 0.5 }, { type: "gunship", count: 8, interval: 0.8 } ],
    [ { type: "brute", count: 14, interval: 0.9 }, { type: "medic", count: 12, interval: 0.7 }, { type: "sprinter", count: 22, interval: 0.45 } ],
    [ { type: "phantom", count: 20, interval: 0.55 }, { type: "shieldbearer", count: 18, interval: 0.65 } ],
    [ { type: "brute", count: 12, interval: 0.85 }, { type: "siege_breaker", count: 4, interval: 1.8 }, { type: "phantom", count: 15, interval: 0.6 } ],
    [ { type: "juggernaut", count: 1, interval: 2.0 }, { type: "splitter", count: 24, interval: 0.65 }, { type: "sprinter", count: 20, interval: 0.4 } ],

    // W26 - W30: Grand Apocalypse & Hive Titan Finale
    [ { type: "shieldbearer", count: 22, interval: 0.6 }, { type: "phantom", count: 20, interval: 0.55 }, { type: "medic", count: 15, interval: 0.6 } ],
    [ { type: "grunt", count: 30, interval: 0.4 }, { type: "sprinter", count: 20, interval: 0.35 }, { type: "siege_breaker", count: 5, interval: 1.6 }, { type: "gunship", count: 10, interval: 0.8 } ],
    [ { type: "overseer", count: 1, interval: 2.5 }, { type: "phantom", count: 20, interval: 0.5 }, { type: "brute", count: 18, interval: 0.75 } ],
    [ { type: "splitter", count: 28, interval: 0.6 }, { type: "shieldbearer", count: 22, interval: 0.6 }, { type: "sprinter", count: 25, interval: 0.35 } ],
    [ { type: "hive_titan", count: 1, interval: 3.0 }, { type: "brute", count: 20, interval: 0.7 }, { type: "phantom", count: 25, interval: 0.5 } ]
  ];

  function getWaveConfig(waveNum, mode = 'CAMPAIGN') {
    if (mode === 'BOSS_RUSH') {
      if (waveNum === 1) return [{ type: "juggernaut", count: 1, interval: 2.5 }, { type: "brute", count: 6, interval: 1.0 }];
      if (waveNum === 2) return [{ type: "overseer", count: 1, interval: 2.5 }, { type: "gunship", count: 6, interval: 0.9 }];
      if (waveNum === 3) return [{ type: "hive_titan", count: 1, interval: 3.0 }, { type: "swarmling", count: 25, interval: 0.35 }];
      if (waveNum === 4) return [{ type: "juggernaut", count: 2, interval: 3.5 }, { type: "kamikaze", count: 12, interval: 0.5 }];
      if (waveNum === 5) return [{ type: "chrono_phantom", count: 1, interval: 3.0 }, { type: "phantom", count: 16, interval: 0.5 }];
      if (waveNum === 6) return [{ type: "void_titan", count: 1, interval: 3.0 }, { type: "shieldbearer", count: 14, interval: 0.6 }];
      if (waveNum === 7) return [{ type: "chrono_phantom", count: 1, interval: 3.0 }, { type: "void_titan", count: 1, interval: 4.0 }, { type: "gunship", count: 8, interval: 0.8 }];
      if (waveNum === 8) return [{ type: "mecha_colossus", count: 1, interval: 4.0 }, { type: "siege_breaker", count: 5, interval: 1.5 }];
      if (waveNum === 9) return [{ type: "overseer", count: 1, interval: 3.0 }, { type: "chrono_phantom", count: 1, interval: 3.5 }, { type: "void_titan", count: 1, interval: 4.0 }];
      if (waveNum === 10) return [{ type: "mecha_colossus", count: 1, interval: 3.0 }, { type: "hive_titan", count: 1, interval: 3.5 }, { type: "juggernaut", count: 2, interval: 4.0 }];
      return [{ type: "mecha_colossus", count: 2, interval: 4.0 }];
    }
    if (mode === 'CAMPAIGN' && waveNum >= 1 && waveNum <= 30) {
      return CAMPAIGN_WAVES_BTD6[waveNum - 1];
    }
    // Endless mode: fitted BTD6 power curve: RBE = 21.24 * wave^0.66
    const pool = ["grunt", "sprinter", "brute", "swarmling", "shieldbearer", "medic", "splitter", "phantom", "gunship", "kamikaze", "siege_breaker"];
    const baseCount = Math.floor(15 + Math.pow(waveNum, 0.75) * 3);
    const primary = pool[waveNum % pool.length];
    const secondary = pool[(waveNum + 3) % pool.length];
    const groups = [
      { type: primary, count: baseCount, interval: Math.max(0.25, 0.9 - waveNum * 0.01) },
      { type: secondary, count: Math.floor(baseCount * 0.7), interval: 0.5 }
    ];
    if (waveNum % 10 === 0) {
      const bossType = (waveNum % 60 === 0) ? "mecha_colossus" : (waveNum % 50 === 0 ? "void_titan" : (waveNum % 40 === 0 ? "chrono_phantom" : (waveNum % 30 === 0 ? "hive_titan" : (waveNum % 20 === 0 ? "overseer" : "juggernaut"))));
      groups.unshift({ type: bossType, count: Math.floor(waveNum / 30) + 1, interval: 2.5 });
    }
    return groups;
  }

  // --- GAME ENGINE ---
  class LastGridEngine {
    constructor() {
      this.canvas = document.getElementById('game-canvas');
      this.ctx = this.canvas.getContext('2d');
      this.width = 1280;
      this.height = 720;

      this.lang = localStorage.getItem('last_grid_lang') || 'uz';
      this.gameMode = 'CAMPAIGN';
      this.state = 'MENU';
      this.speed = 1;
      try { audio.playBGMTrack('menu'); } catch(e) {}
      this.loadBackgroundImages();
      this.crtEnabled = localStorage.getItem('lg_crt') === 'true';
      this.colorblind = false;
      this.screenShake = 0;
      this.flyingCoins = [];
      this.upgradePillars = [];
      this.heroMenuAnim = { breathe: 0, coreGlow: 0, stanceTimer: 0 };

      // Mobile Ergonomics & Dedicated Settings
      this.settings = {
        sfxVol: parseFloat(localStorage.getItem('lg_sfx_vol') || '1.0'),
        bgmVol: parseFloat(localStorage.getItem('lg_bgm_vol') || '0.7'),
        haptics: localStorage.getItem('lg_haptics') !== 'false',
        screenFit: localStorage.getItem('lg_screen_fit') || 'FIT',
        fpsLimit: parseInt(localStorage.getItem('lg_fps_limit') || '60'),
        lang: localStorage.getItem('last_grid_lang') || 'uz'
      };
      this.showSettingsModal = false;
      this.settingsReturnState = 'MENU';
      this.exitToastTimer = 0;
      this.lastBackTapTime = 0;

      this.currentMapIndex = 0;
      this.gold = 250;
      this.score = 0;
      this.baseHp = 20;
      this.maxBaseHp = 20;
      this.wave = 1;
      this.maxWaves = 10;
      this.waveActive = false;
      this.waveCountdown = 8;
      this.spawnQueue = [];
      this.spawnTimer = 0;

      // Active Augments
      this.activeAugments = [];
      this.draftCards = [];

      // Combat Analytics Tracker
      this.analytics = {
        damageByTower: { pulse: 0, mortar: 0, cryo: 0, tesla: 0, flame: 0, railgun: 0, beacon: 0, hero: 0, skills: 0 },
        totalKills: 0,
        totalGold: 0,
        mvpName: "Pulse Tower"
      };

      // Commander Skills
      this.skills = {
        emp:       { cost: 50, cd: 25, currentCd: 0, key: "Z", name: "EMP Storm" },
        missiles:  { cost: 65, cd: 22, currentCd: 0, key: "X", name: "Micro-Missiles" },
        shield:    { cost: 60, cd: 30, currentCd: 0, key: "C", name: "Shield Dome" },
        overclock: { cost: 50, cd: 35, currentCd: 0, key: "V", name: "Overclock", activeTime: 0 },
        orbital:   { cost: 75, cd: 30, currentCd: 0, key: "B", name: "Orbital Beam" },
        drone:     { cost: 0,  cd: 40, currentCd: 0, key: "N", name: "Supply Drone" }
      };

      // Controllable Field Hero Mech (Apex-01)
      this.hero = {
        name: "Apex-01 Mech",
        x: 300, y: 350,
        targetX: 300, targetY: 350,
        hp: 400, maxHp: 400,
        level: 1, xp: 0, maxXp: 80,
        speed: 130,
        mode: 'BIPED', // 'BIPED' (Assault Robot) | 'SIEGE' (Siege Tank)
        siegeRecoil: 0,
        siegeCooldown: 0,
        shieldDome: null,
        atkDmg: 80, atkRate: 1.3, atkCooldown: 0,
        ultCd: 22, currentUltCd: 0, ultActiveTime: 0,
        selected: false,
        angle: 0,
        walkAnim: 0,
        slashAnim: 0
      };

      // Touch Gesture & Sensor State (Mobile Optimization)
      this.touchState = {
        dragging: null, // null | 'HERO' | 'TOWER_HOTBAR'
        draggedTowerType: null,
        dragCurrent: { x: 0, y: 0 },
        lastTapTime: 0,
        lastTapPos: { x: 0, y: 0 }
      };
      this.radialBuildCell = null; // Mobile Radial Touch Quick-Build
      this.lastTouchActionTime = 0;
      this.isTouchDevice = (typeof window !== 'undefined' && (('ontouchstart' in window) || (navigator.maxTouchPoints > 0)));

      this.towers = [];
      this.enemies = [];
      this.projectiles = [];
      this.particles = [];
      this.floatingTexts = [];
      this.groundHazards = []; // Napalm fire pools
      this.casings = []; // Spent brass shell casings with physics
      this.scorchMarks = []; // Ground blast craters
      this.muzzleFlashes = []; // Dynamic weapon muzzle flashes
      this.footprints = []; // Mech / titan tread marks

      // Battlefield Dynamics v4.0.0
      this.airdrops = [];
      this.redZones = [];
      this.barricades = [];
      this.airdropCooldown = 22.0;
      this.redZoneCooldown = 38.0;
      this.radioComm = null;

      this.selectedBuildType = null;
      this.selectedTower = null;
      this.aimingSkill = null;
      this.mousePos = { x: -100, y: -100 };
      this.hoverCell = null;
      this.targetPriorities = ['FIRST', 'LAST', 'STRONGEST', 'NEAREST'];

      this.editorWaypoints = [ {x:64, y:256}, {x:512, y:256}, {x:512, y:448}, {x:1152, y:448} ];
      this.nextUid = 1;
      this.lastTimestamp = 0;
      this.playerName = localStorage.getItem('last_grid_player_name') || 'CyberCommander';
      this.minimapExpanded = true;
      this.cinematicBanner = null;
      this.codexTab = 'TOWERS';
      this.codexSelectedId = 'pulse';
      this.isDraggingSlider = null;

      this.saveData = this.loadSave();

      this.initEvents();
      this.setupCanvasScaling();
      this.initMechSystem();
      this.fetchLiveScores();
      this.startLoop();
    }

    vibrate(pattern) {
      if (this.settings && this.settings.haptics === false) return;
      try {
        if (typeof window !== 'undefined' && window.AndroidBridge && window.AndroidBridge.vibrate) {
          const val = Array.isArray(pattern) ? JSON.stringify(pattern) : String(pattern);
          window.AndroidBridge.vibrate(val);
          return;
        }
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          navigator.vibrate(pattern);
        }
      } catch (e) {}
    }

    getApiUrl() {
      const isWebHttp = (typeof window !== 'undefined' && window.location && window.location.origin && window.location.origin.startsWith('http'));
      return isWebHttp ? '/api' : 'https://last-grid-td.vercel.app/api';
    }

    t(key) {
      const dict = I18N[this.lang] || I18N.en;
      return dict[key] || key;
    }

    toggleLang() {
      const langs = ['uz', 'en', 'ru'];
      const idx = langs.indexOf(this.lang);
      this.lang = langs[(idx + 1) % langs.length];
      localStorage.setItem('last_grid_lang', this.lang);
      return this.lang.toUpperCase();
    }

    loadSave() {
      try {
        const d = localStorage.getItem('last_grid_save_v2');
        return d ? JSON.parse(d) : {
          stars: {},
          highScores: { campaign: 0, endless: 0, boss_rush: 0 },
          leaderboard: [
            { player_name: "NeonMaster", map_id: "last_grid", wave_reached: 30, score: 12450 },
            { player_name: "CyberGhost", map_id: "twin_gate", wave_reached: 29, score: 9820 },
            { player_name: "GridRunner_UZ", map_id: "iron_wall", wave_reached: 25, score: 7650 },
            { player_name: "TashkentPro", map_id: "training_grid", wave_reached: 10, score: 3400 }
          ]
        };
      } catch (e) {
        return { stars: {}, highScores: {}, leaderboard: [] };
      }
    }

    fetchLiveScores() {
      fetch(this.getApiUrl())
        .then(r => r.json())
        .then(data => {
          if (Array.isArray(data) && data.length > 0) this.saveData.leaderboard = data;
        })
        .catch(() => {});
    }

    saveProgress(mapId, stars, finalScore, waveReached) {
      if (!this.saveData.stars) this.saveData.stars = {};
      this.saveData.stars[mapId] = Math.max(this.saveData.stars[mapId] || 0, stars);

      const modeKey = this.gameMode.toLowerCase();
      this.saveData.highScores[modeKey] = Math.max(this.saveData.highScores[modeKey] || 0, finalScore);

      this.saveData.leaderboard.push({
        player_name: this.playerName,
        map_id: mapId,
        wave_reached: waveReached,
        score: finalScore,
        date: new Date().toLocaleDateString()
      });
      this.saveData.leaderboard.sort((a, b) => b.score - a.score);
      this.saveData.leaderboard = this.saveData.leaderboard.slice(0, 25);

      try {
        localStorage.setItem('last_grid_save_v2', JSON.stringify(this.saveData));
        localStorage.setItem('last_grid_player_name', this.playerName);
      } catch (e) {}

      fetch(this.getApiUrl(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          player_name: this.playerName,
          map_id: mapId,
          difficulty: "normal",
          wave_reached: waveReached,
          score: finalScore,
          seed: Math.floor(Math.random() * 1000000)
        })
      }).catch(() => {});
    }


    initMechSystem() {
      const mechCanvas = document.getElementById('mech-hangar-canvas');
      if (mechCanvas && window.Apex01System) {
        this.apexSystem = new window.Apex01System();
        this.apexSystem.init(mechCanvas);
        this.syncMechCanvasPosition();
      }
    }

    syncMechCanvasPosition() {
      const mechCanvas = document.getElementById('mech-hangar-canvas');
      if (!mechCanvas || !this.canvas) return;

      const rect = this.canvas.getBoundingClientRect();
      const scaleX = rect.width / 1280;
      const scaleY = rect.height / 720;

      // Hangar slot in 1280x720: x: 50, y: 155, w: 370, h: 325
      mechCanvas.style.left = `${rect.left + 50 * scaleX}px`;
      mechCanvas.style.top = `${rect.top + 155 * scaleY}px`;
      mechCanvas.style.width = `${Math.floor(370 * scaleX)}px`;
      mechCanvas.style.height = `${Math.floor(325 * scaleY)}px`;
    }

    setupCanvasScaling() {
      window.addEventListener('resize', () => this.resizeCanvas());
      window.addEventListener('orientationchange', () => setTimeout(() => this.resizeCanvas(), 150));
      document.addEventListener('fullscreenchange', () => setTimeout(() => this.resizeCanvas(), 150));
      this.resizeCanvas();
    }

    handleBackAction() {
      // 1. If Settings modal is open -> close it
      if (this.showSettingsModal) {
        this.showSettingsModal = false;
        if (this.state === 'MENU' && this.apexSystem) this.apexSystem.show();
        audio.click();
        return;
      }
      // 2. If Radial quick-build wheel is open -> close it
      if (this.radialBuildCell) {
        this.radialBuildCell = null;
        audio.click();
        return;
      }
      // 3. If Tower is selected -> deselect
      if (this.selectedTower) {
        this.selectedTower = null;
        audio.click();
        return;
      }
      // 4. If Build type is selected -> deselect
      if (this.selectedBuildType) {
        this.selectedBuildType = null;
        audio.click();
        return;
      }
      // 5. If Hero is selected -> deselect
      if (this.hero && this.hero.selected) {
        this.hero.selected = false;
        audio.click();
        return;
      }
      // 6. If in sub-screens -> return to MENU
      if (['MAP_SELECT', 'MANUAL', 'LEADERBOARD', 'EDITOR', 'ANALYTICS'].includes(this.state)) {
        this.state = 'MENU';
        if (this.apexSystem) this.apexSystem.show();
        audio.playBGMTrack('menu');
        audio.click();
        return;
      }
      // 7. If in 3D TPS arena -> return to MENU
      if (this.state === 'TPS_3D') {
        this.state = 'MENU';
        if (this.apexSystem) this.apexSystem.show();
        audio.playBGMTrack('menu');
        audio.sell();
        return;
      }
      // 8. If in PLAYING state -> toggle PAUSE (Never abruptly lose progress!)
      if (this.state === 'PLAYING') {
        this.togglePause();
        audio.modal();
        return;
      }
      // 9. If in PAUSED state -> safely return to MENU!
      if (this.state === 'PAUSED') {
        this.state = 'MENU';
        this.selectedTower = null;
        this.selectedBuildType = null;
        this.radialBuildCell = null;
        if (this.apexSystem) this.apexSystem.show();
        audio.playBGMTrack('menu');
        audio.sell();
        return;
      }
      // 10. If in MENU -> double tap back to exit application
      if (this.state === 'MENU') {
        const now = Date.now();
        if (now - this.lastBackTapTime < 2400) {
          if (typeof window !== 'undefined' && window.AndroidBridge && window.AndroidBridge.exitApp) {
            window.AndroidBridge.exitApp();
          }
        } else {
          this.lastBackTapTime = now;
          this.exitToastTimer = 2.4;
          this.vibrate(25);
          if (audio) audio.click();
        }
      }
    }

    renderExitToast() {
      const ctx = this.ctx;
      ctx.save();
      const alpha = Math.min(1.0, this.exitToastTimer / 0.5);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = "rgba(10, 18, 32, 0.96)";
      ctx.fillRect(360, 645, 560, 48);
      ctx.strokeStyle = "#ffd600";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(360, 645, 560, 48);
      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 13px monospace";
      ctx.textAlign = "center";
      ctx.fillText("CHIQISH UCHUN YANA BIR BOR BOSING (PRESS BACK AGAIN TO EXIT)", 640, 674);
      ctx.restore();
    }

    renderSettingsModal() {
      const ctx = this.ctx;
      ctx.save();
      // Backdrop dimmer
      ctx.fillStyle = "rgba(4, 7, 14, 0.90)";
      ctx.fillRect(0, 0, this.width, this.height);

      const mx = 240;
      const my = 40;
      const mw = 800;
      const mh = 640;
      const cut = 12;

      // Modal Background Frame
      ctx.beginPath();
      ctx.moveTo(mx + cut, my);
      ctx.lineTo(mx + mw - cut, my);
      ctx.lineTo(mx + mw, my + cut);
      ctx.lineTo(mx + mw, my + mh - cut);
      ctx.lineTo(mx + mw - cut, my + mh);
      ctx.lineTo(mx + cut, my + mh);
      ctx.lineTo(mx, my + mh - cut);
      ctx.lineTo(mx, my + cut);
      ctx.closePath();

      const bgGrad = ctx.createLinearGradient(mx, my, mx, my + mh);
      bgGrad.addColorStop(0, "rgba(16, 26, 46, 0.99)");
      bgGrad.addColorStop(1, "rgba(8, 14, 25, 0.99)");
      ctx.fillStyle = bgGrad;
      ctx.fill();

      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Top Header
      ctx.fillStyle = "#00e5ff";
      ctx.font = "900 24px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.fillText("⚙️ TIZIM VA O'YIN SOZLAMALARI (SETTINGS)", 640, my + 42);

      ctx.fillStyle = "#78909c";
      ctx.font = "bold 12px monospace";
      ctx.fillText("BOSHQARUV • OVOZ • GRAFIKA • EKRAN MOSLASHUVI", 640, my + 66);

      // Section 1: SFX Volume Slider
      ctx.textAlign = "left";
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 13px monospace";
      ctx.fillText("🔊 SFX OVOZLAR:", mx + 40, my + 115);

      const sfxTrackX = mx + 240;
      const sfxTrackY = my + 104;
      const trackW = 420;
      const trackH = 12;

      // Track base
      ctx.fillStyle = "rgba(10, 16, 28, 0.95)";
      ctx.fillRect(sfxTrackX, sfxTrackY, trackW, trackH);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.lineWidth = 1.2;
      ctx.strokeRect(sfxTrackX, sfxTrackY, trackW, trackH);

      // Track fill
      const sfxFillW = Math.max(0, Math.min(trackW, trackW * this.settings.sfxVol));
      const sfxGrad = ctx.createLinearGradient(sfxTrackX, 0, sfxTrackX + sfxFillW, 0);
      sfxGrad.addColorStop(0, "#00b0ff");
      sfxGrad.addColorStop(1, "#00e5ff");
      ctx.fillStyle = sfxGrad;
      ctx.fillRect(sfxTrackX + 1, sfxTrackY + 1, sfxFillW, trackH - 2);

      // Thumb knob
      const sfxThumbX = sfxTrackX + sfxFillW;
      ctx.fillStyle = "#ffffff";
      ctx.shadowColor = "#00e5ff";
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(sfxThumbX, sfxTrackY + trackH / 2, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Readout
      this.drawCyberButton(mx + 680, my + 92, 80, 36, `${Math.round(this.settings.sfxVol * 100)}%`, this.settings.sfxVol > 0 ? "#00e5ff" : "#455a64", "", "", false);

      // Section 2: BGM Volume Slider
      ctx.fillStyle = "#ffffff";
      ctx.fillText("🎵 MUSIQA (BGM):", mx + 40, my + 175);

      const bgmTrackX = mx + 240;
      const bgmTrackY = my + 164;

      ctx.fillStyle = "rgba(10, 16, 28, 0.95)";
      ctx.fillRect(bgmTrackX, bgmTrackY, trackW, trackH);
      ctx.strokeStyle = "rgba(0, 230, 118, 0.35)";
      ctx.lineWidth = 1.2;
      ctx.strokeRect(bgmTrackX, bgmTrackY, trackW, trackH);

      const bgmFillW = Math.max(0, Math.min(trackW, trackW * this.settings.bgmVol));
      const bgmGrad = ctx.createLinearGradient(bgmTrackX, 0, bgmTrackX + bgmFillW, 0);
      bgmGrad.addColorStop(0, "#00b0ff");
      bgmGrad.addColorStop(1, "#00e676");
      ctx.fillStyle = bgmGrad;
      ctx.fillRect(bgmTrackX + 1, bgmTrackY + 1, bgmFillW, trackH - 2);

      const bgmThumbX = bgmTrackX + bgmFillW;
      ctx.fillStyle = "#ffffff";
      ctx.shadowColor = "#00e676";
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(bgmThumbX, bgmTrackY + trackH / 2, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#00e676";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.shadowBlur = 0;

      this.drawCyberButton(mx + 680, my + 152, 80, 36, `${Math.round(this.settings.bgmVol * 100)}%`, this.settings.bgmVol > 0 ? "#00e676" : "#455a64", "", "", false);

      // Section 3: Haptic Feedback
      ctx.fillStyle = "#ffffff";
      ctx.fillText("📳 TEBRANISH:", mx + 40, my + 235);
      this.drawCyberButton(mx + 240, my + 212, 240, 36, "YONIQ 🟢 (HAPTICS ON)", this.settings.haptics ? "#00e676" : "#455a64", "", "", this.settings.haptics);
      this.drawCyberButton(mx + 500, my + 212, 240, 36, "O'CHIQ 🔴 (OFF)", !this.settings.haptics ? "#ff1744" : "#455a64", "", "", !this.settings.haptics);

      // Section 4: Screen Fit Mode
      ctx.fillStyle = "#ffffff";
      ctx.fillText("📱 EKRAN REJIMI:", mx + 40, my + 295);
      const isFit = this.settings.screenFit === 'FIT';
      this.drawCyberButton(mx + 240, my + 272, 240, 36, "FIT (16:9 NISBAT)", isFit ? "#00e5ff" : "#455a64", "ORIGINAL PROPORTION", "", isFit);
      this.drawCyberButton(mx + 500, my + 272, 240, 36, "FILL (TO'LIQ CHEKKAGACHA)", !isFit ? "#00e5ff" : "#455a64", "EDGE-TO-EDGE 20:9", "", !isFit);

      // Section 5: FPS Mode
      ctx.fillStyle = "#ffffff";
      ctx.fillText("⚡ FPS REJIMI:", mx + 40, my + 355);
      const is60 = this.settings.fpsLimit === 60;
      this.drawCyberButton(mx + 240, my + 332, 240, 36, "60 FPS (SILLIQ ULTRA)", is60 ? "#ffd600" : "#455a64", "SMOOTH COMBAT", "", is60);
      this.drawCyberButton(mx + 500, my + 332, 240, 36, "30 FPS (BATAREYA TEJASH)", !is60 ? "#ffd600" : "#455a64", "BATTERY SAVER", "", !is60);

      // Section 6: Language
      ctx.fillStyle = "#ffffff";
      ctx.fillText("🌐 TIL (LANG):", mx + 40, my + 415);
      this.drawCyberButton(mx + 240, my + 392, 160, 36, "🇺🇿 O'ZBEK", this.lang === 'uz' ? "#00e5ff" : "#455a64", "", "", this.lang === 'uz');
      this.drawCyberButton(mx + 410, my + 392, 160, 36, "🇬🇧 ENGLISH", this.lang === 'en' ? "#00e5ff" : "#455a64", "", "", this.lang === 'en');
      this.drawCyberButton(mx + 580, my + 392, 160, 36, "🇷🇺 РУССКИЙ", this.lang === 'ru' ? "#00e5ff" : "#455a64", "", "", this.lang === 'ru');

      // Section 7: Retro CRT
      ctx.fillStyle = "#ffffff";
      ctx.fillText("📺 CRT SKAN-LINIYA:", mx + 40, my + 475);
      this.drawCyberButton(mx + 240, my + 452, 240, 36, "YONIQ (CRT ON)", this.crtEnabled ? "#00e5ff" : "#455a64", "", "", this.crtEnabled);
      this.drawCyberButton(mx + 500, my + 452, 240, 36, "O'CHIQ (CLEAN)", !this.crtEnabled ? "#00e5ff" : "#455a64", "", "", !this.crtEnabled);

      // Bottom Row: Close/Save & Main Menu
      this.drawCyberButton(mx + 60, my + 540, 320, 50, "← SAQLASH VA YOPISH", "#00e676", "APPLY & RESUME", "✔", true);
      const isIngame = (this.settingsReturnState === 'PLAYING' || this.settingsReturnState === 'PAUSED');
      this.drawCyberButton(mx + 420, my + 540, 320, 50, isIngame ? "🚪 ASOSIY MENYUGA QAYTISH" : "ASOSIY MENYUDA QOLISH", "#ff1744", isIngame ? "QUIT COMBAT" : "BACK", "←", false);

      ctx.restore();
    }

    handleSettingsClick(x, y) {
      const mx = 240;
      const my = 40;

      // Section 1: SFX Slider Click / Drag
      if (y >= my + 88 && y <= my + 130 && x >= mx + 230 && x <= mx + 670) {
        const pct = Math.max(0, Math.min(1.0, (x - (mx + 240)) / 420));
        this.settings.sfxVol = Math.round(pct * 20) / 20;
        localStorage.setItem('lg_sfx_vol', this.settings.sfxVol.toString());
        audio.sfxMuted = (this.settings.sfxVol === 0.0);
        audio.shootPulse();
        this.vibrate(14);
        return;
      }
      if (x >= mx + 680 && x <= mx + 760 && y >= my + 92 && y <= my + 128) {
        this.settings.sfxVol = this.settings.sfxVol > 0 ? 0 : 0.7;
        localStorage.setItem('lg_sfx_vol', this.settings.sfxVol.toString());
        audio.sfxMuted = (this.settings.sfxVol === 0.0);
        audio.click();
        this.vibrate(15);
        return;
      }

      // Section 2: BGM Slider Click / Drag
      if (y >= my + 148 && y <= my + 190 && x >= mx + 230 && x <= mx + 670) {
        const pct = Math.max(0, Math.min(1.0, (x - (mx + 240)) / 420));
        this.settings.bgmVol = Math.round(pct * 20) / 20;
        localStorage.setItem('lg_bgm_vol', this.settings.bgmVol.toString());
        audio.bgmMuted = (this.settings.bgmVol === 0.0);
        if (audio.bgmMuted) audio.stopBGM();
        else { audio.startBGM(); audio.setBGMVolume(this.settings.bgmVol); }
        audio.click();
        this.vibrate(14);
        return;
      }
      if (x >= mx + 680 && x <= mx + 760 && y >= my + 152 && y <= my + 188) {
        this.settings.bgmVol = this.settings.bgmVol > 0 ? 0 : 0.7;
        localStorage.setItem('lg_bgm_vol', this.settings.bgmVol.toString());
        audio.bgmMuted = (this.settings.bgmVol === 0.0);
        if (audio.bgmMuted) audio.stopBGM();
        else { audio.startBGM(); audio.setBGMVolume(this.settings.bgmVol); }
        audio.click();
        this.vibrate(15);
        return;
      }

      // Section 3: Haptics
      if (y >= my + 212 && y <= my + 248) {
        if (x >= mx + 240 && x <= mx + 480) {
          this.settings.haptics = true;
          localStorage.setItem('lg_haptics', 'true');
          this.vibrate(35);
          audio.click();
          return;
        } else if (x >= mx + 500 && x <= mx + 740) {
          this.settings.haptics = false;
          localStorage.setItem('lg_haptics', 'false');
          audio.click();
          return;
        }
      }

      // Section 4: Screen Fit
      if (y >= my + 272 && y <= my + 308) {
        if (x >= mx + 240 && x <= mx + 480) {
          this.settings.screenFit = 'FIT';
          localStorage.setItem('lg_screen_fit', 'FIT');
          this.resizeCanvas();
          audio.click();
          this.vibrate(15);
          return;
        } else if (x >= mx + 500 && x <= mx + 740) {
          this.settings.screenFit = 'FILL';
          localStorage.setItem('lg_screen_fit', 'FILL');
          this.resizeCanvas();
          audio.click();
          this.vibrate(15);
          return;
        }
      }

      // Section 5: FPS Mode
      if (y >= my + 332 && y <= my + 368) {
        if (x >= mx + 240 && x <= mx + 480) {
          this.settings.fpsLimit = 60;
          localStorage.setItem('lg_fps_limit', '60');
          audio.click();
          this.vibrate(15);
          return;
        } else if (x >= mx + 500 && x <= mx + 740) {
          this.settings.fpsLimit = 30;
          localStorage.setItem('lg_fps_limit', '30');
          audio.click();
          this.vibrate(15);
          return;
        }
      }

      // Section 6: Language
      if (y >= my + 392 && y <= my + 428) {
        const langs = ['uz', 'en', 'ru'];
        for (let i = 0; i < 3; i++) {
          const bx = mx + 240 + i * 170;
          if (x >= bx && x <= bx + 160) {
            this.lang = langs[i];
            this.settings.lang = langs[i];
            localStorage.setItem('last_grid_lang', langs[i]);
            audio.click();
            this.vibrate(15);
            return;
          }
        }
      }

      // Section 7: CRT
      if (y >= my + 452 && y <= my + 488) {
        if (x >= mx + 240 && x <= mx + 480) {
          this.crtEnabled = true;
          localStorage.setItem('lg_crt', 'true');
          audio.click();
          this.vibrate(15);
          return;
        } else if (x >= mx + 500 && x <= mx + 740) {
          this.crtEnabled = false;
          localStorage.setItem('lg_crt', 'false');
          audio.click();
          this.vibrate(15);
          return;
        }
      }

      // Bottom Row: Close/Save
      if (y >= my + 540 && y <= my + 590) {
        if (x >= mx + 60 && x <= mx + 380) {
          this.showSettingsModal = false;
          if (this.state === 'MENU' && this.apexSystem) this.apexSystem.show();
          audio.click();
          this.vibrate(20);
          return;
        } else if (x >= mx + 420 && x <= mx + 740) {
          this.showSettingsModal = false;
          this.state = 'MENU';
          this.selectedTower = null;
          this.selectedBuildType = null;
          this.radialBuildCell = null;
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
          audio.sell();
          this.vibrate(25);
          return;
        }
      }
    }

    resizeCanvas() {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const screenFit = (this.settings && this.settings.screenFit) || localStorage.getItem('lg_screen_fit') || 'FIT';

      let cssW = w;
      let cssH = h;
      if (screenFit === 'FILL') {
        // True Edge-to-Edge full stretch for modern 19.5:9 & 20:9 Android screens
        this.canvas.style.width = `${w}px`;
        this.canvas.style.height = `${h}px`;
      } else {
        // Proportional 16:9 aspect preservation with centered cyber frame
        const aspect = 1280 / 720;
        let targetW = w;
        let targetH = w / aspect;
        if (targetH > h) {
          targetH = h;
          targetW = h * aspect;
        }
        cssW = Math.floor(targetW);
        cssH = Math.floor(targetH);
        this.canvas.style.width = `${cssW}px`;
        this.canvas.style.height = `${cssH}px`;
      }
      this.canvas.style.display = 'block';

      // True Native Resolution with DPR scaling (capped at 2.5 for mobile GPU performance)
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const targetBufferW = Math.round(cssW * dpr);
      const targetBufferH = Math.round(cssH * dpr);
      if (this.canvas.width !== targetBufferW || this.canvas.height !== targetBufferH) {
        this.canvas.width = targetBufferW;
        this.canvas.height = targetBufferH;
      }
      this.dpr = dpr;
      this.renderScaleX = targetBufferW / 1280;
      this.renderScaleY = targetBufferH / 720;

      if (this.ctx) {
        this.ctx.imageSmoothingEnabled = true;
        this.ctx.imageSmoothingQuality = 'high';
      }
      this.syncMechCanvasPosition();
    }

    getCanvasPos(e) {
      const rect = this.canvas.getBoundingClientRect();
      let clientX = 0;
      let clientY = 0;
      if (e.changedTouches && e.changedTouches.length > 0) {
        clientX = e.changedTouches[0].clientX;
        clientY = e.changedTouches[0].clientY;
      } else if (e.touches && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if (typeof e.clientX === 'number') {
        clientX = e.clientX;
        clientY = e.clientY;
      }
      const rw = rect.width || 1280;
      const rh = rect.height || 720;
      const scaleX = 1280 / rw;
      const scaleY = 720 / rh;
      const x = Math.max(0, Math.min(1280, (clientX - rect.left) * scaleX));
      const y = Math.max(0, Math.min(720, (clientY - rect.top) * scaleY));
      return { x, y };
    }

    initEvents() {
      // Pointer State & Ripple Tracking
      this.isPointerDown = false;
      this.buttonRipples = [];

      this.canvas.addEventListener('mousedown', (e) => {
        this.isPointerDown = true;
        this.mousePos = this.getCanvasPos(e);
        if (this.mousePos) {
          this.buttonRipples.push({ x: this.mousePos.x, y: this.mousePos.y, r: 4, maxR: 52, alpha: 0.9, color: "#00e5ff" });
        }
      });
      window.addEventListener('mouseup', () => {
        this.isPointerDown = false;
      });

      // Desktop Mouse Move
      this.canvas.addEventListener('mousemove', (e) => {
        this.mousePos = this.getCanvasPos(e);
        this.updateHoverCell();
        if (this.showSettingsModal && this.isPointerDown && this.mousePos) {
          this.handleSettingsClick(this.mousePos.x, this.mousePos.y);
        }
      });

      // Desktop Click (strictly ignores synthetic touch events)
      this.canvas.addEventListener('click', (e) => {
        if (Date.now() - this.lastTouchActionTime < 700) return;
        audio.init();
        if (audio.ctx && audio.ctx.state === 'suspended') audio.ctx.resume();
        const pos = this.getCanvasPos(e);
        this.handleCanvasClick(pos.x, pos.y, e.button === 2);
      });

      this.canvas.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const pos = this.getCanvasPos(e);
        this.handleCanvasClick(pos.x, pos.y, true);
      });

      // MOBILE TOUCH GESTURES & SENSORS
      this.canvas.addEventListener('touchstart', (e) => {
        this.isTouchDevice = true;
        this.isPointerDown = true;
        audio.init();
        const tPos = this.getCanvasPos(e);
        if (tPos) {
          this.mousePos = tPos;
          this.buttonRipples.push({ x: tPos.x, y: tPos.y, r: 4, maxR: 52, alpha: 0.9, color: "#00e5ff" });
        }
        if (this.state === 'TPS_3D' && this.tps3D) {
          const t = this.tps3D;
          for (let i = 0; i < e.changedTouches.length; i++) {
            const touch = e.changedTouches[i];
            const rect = this.canvas.getBoundingClientRect();
            const tx = (touch.clientX - rect.left) * (1280 / rect.width);
            const ty = (touch.clientY - rect.top) * (720 / rect.height);

            if (tx < 160 && ty < 70) {
              this.state = 'MENU'; audio.playBGMTrack('menu');
              audio.sell();
              return;
            }
            if (Math.hypot(tx - 1200, ty - 620) <= 52) {
              if (t.isBuilding) this.place3DTower(); else this.shoot3DTPS();
              this.vibrate(22);
              return;
            }
            if (Math.hypot(tx - 1080, ty - 640) <= 40) {
              t.player.isAiming = !t.player.isAiming;
              return;
            }
            if (Math.hypot(tx - 1200, ty - 500) <= 40) {
              t.isBuilding = !t.isBuilding;
              audio.upgrade();
              return;
            }
            if (Math.hypot(tx - 1080, ty - 540) <= 35) {
              this.reload3DTPS();
              return;
            }

            if (tx < 500 && t.touch.moveId === null) {
              t.touch.moveId = touch.identifier;
              t.touch.moveStart = { x: tx, y: ty };
              t.touch.moveVec = { x: 0, y: 0 };
            } else if (tx >= 500 && t.touch.lookId === null) {
              t.touch.lookId = touch.identifier;
              t.touch.lookLast = { x: tx, y: ty };
            }
          }
          return;
        }
        if (audio.ctx && audio.ctx.state === 'suspended') audio.ctx.resume();
        this.lastTouchActionTime = Date.now();
        const pos = this.getCanvasPos(e);
        this.mousePos = pos;
        this.updateHoverCell();

        const now = Date.now();
        const isDoubleTap = (now - this.touchState.lastTapTime < 350) &&
                            (Math.hypot(pos.x - this.touchState.lastTapPos.x, pos.y - this.touchState.lastTapPos.y) < 45);

        if (this.state === 'PLAYING') {
          // Floating Hero Ult Button (x: 1210, y: 540, radius: 45)
          if (Math.hypot(pos.x - 1210, pos.y - 540) <= 45) {
            e.preventDefault();
            this.triggerHeroUlt();
            this.vibrate([40, 25, 70]);
            this.touchState.lastTapTime = now;
            this.touchState.lastTapPos = pos;
            return;
          }
          // Floating Wave / Speed Button (x: 1210, y: 450, radius: 36)
          if (Math.hypot(pos.x - 1210, pos.y - 450) <= 36) {
            e.preventDefault();
            if (!this.waveActive) this.callNextWave();
            else this.cycleSpeed();
            this.vibrate(20);
            this.touchState.lastTapTime = now;
            this.touchState.lastTapPos = pos;
            return;
          }

          // Hero Double Tap
          const distToHero = Math.hypot(this.hero.x - pos.x, this.hero.y - pos.y);
          if (distToHero <= 45 && isDoubleTap) {
            e.preventDefault();
            this.triggerHeroUlt();
            this.vibrate([40, 25, 70]);
            this.touchState.lastTapTime = 0;
            return;
          }

          // Check Bottom Bar Tower Hotbar Drag
          if (pos.y >= 620 && !this.selectedTower) {
            const towerKeys = ['pulse', 'mortar', 'cryo', 'tesla', 'flame', 'railgun', 'beacon', 'barricade'];
            for (let i = 0; i < 8; i++) {
              const bx = 276 + i * 125;
              if (pos.x >= bx && pos.x <= bx + 120 && pos.y >= 625 && pos.y <= 715) {
                e.preventDefault();
                const key = towerKeys[i];
                this.touchState.dragging = 'TOWER_HOTBAR';
                this.touchState.draggedTowerType = key;
                this.touchState.dragCurrent = { x: pos.x, y: pos.y };
                this.selectedBuildType = key;
                this.vibrate(20);
                this.touchState.lastTapTime = now;
                this.touchState.lastTapPos = pos;
                return;
              }
            }
          }
        }

        this.touchState.lastTapTime = now;
        this.touchState.lastTapPos = pos;
      }, { passive: false });

      this.canvas.addEventListener('touchmove', (e) => {
        const pos = this.getCanvasPos(e);
        this.mousePos = pos;
        this.updateHoverCell();

        if (this.showSettingsModal && pos) {
          this.handleSettingsClick(pos.x, pos.y);
          return;
        }

        if (this.state === 'TPS_3D' && this.tps3D) {
          e.preventDefault();
          const t = this.tps3D;
          for (let i = 0; i < e.changedTouches.length; i++) {
            const touch = e.changedTouches[i];
            const rect = this.canvas.getBoundingClientRect();
            const tx = (touch.clientX - rect.left) * (1280 / rect.width);
            const ty = (touch.clientY - rect.top) * (720 / rect.height);

            if (touch.identifier === t.touch.moveId) {
              const dx = tx - t.touch.moveStart.x;
              const dy = ty - t.touch.moveStart.y;
              const dist = Math.hypot(dx, dy);
              const maxR = 60;
              t.touch.moveVec = {
                x: (dist > 0 ? (dx / dist) * Math.min(1.0, dist / maxR) : 0),
                y: (dist > 0 ? (dy / dist) * Math.min(1.0, dist / maxR) : 0)
              };
            } else if (touch.identifier === t.touch.lookId) {
              const dx = tx - t.touch.lookLast.x;
              const dy = ty - t.touch.lookLast.y;
              t.player.yaw -= dx * 0.005;
              t.player.pitch = Math.max(-0.4, Math.min(0.5, t.player.pitch + dy * 0.004));
              t.touch.lookLast = { x: tx, y: ty };
            }
          }
          return;
        }

        if (this.touchState.dragging) {
          e.preventDefault();
          this.touchState.dragCurrent = pos;
        }
      }, { passive: false });

      this.canvas.addEventListener('touchend', (e) => {
        this.isPointerDown = false;
        e.preventDefault(); // PREVENTS SYNTHETIC DUPLICATE CLICK!
        this.lastTouchActionTime = Date.now();
        const pos = this.getCanvasPos(e);

        if (this.state === 'TPS_3D' && this.tps3D) {
          const t = this.tps3D;
          for (let i = 0; i < e.changedTouches.length; i++) {
            const touch = e.changedTouches[i];
            if (touch.identifier === t.touch.moveId) {
              t.touch.moveId = null;
              t.touch.moveVec = { x: 0, y: 0 };
            } else if (touch.identifier === t.touch.lookId) {
              t.touch.lookId = null;
            }
          }
          return;
        }

        if (this.touchState.dragging === 'HERO') {
          if (pos.y >= 60 && pos.y <= 620) {
            this.hero.targetX = pos.x;
            this.hero.targetY = pos.y;
            this.hero.selected = false;
            this.spawnShockwave(pos.x, pos.y, 35, "#ffd600");
            audio.upgrade();
            this.vibrate(25);
          }
          this.touchState.dragging = null;
          return;
        }

        if (this.touchState.dragging === 'TOWER_HOTBAR') {
          const gx = Math.floor(pos.x / 64);
          const gy = Math.floor(pos.y / 64);
          if (this.isValidBuildCell(gx, gy) && pos.y >= 60 && pos.y < 620) {
            this.buildTower(this.touchState.draggedTowerType, gx, gy);
            this.vibrate([25, 30, 25]);
          }
          this.touchState.dragging = null;
          this.selectedBuildType = null;
          return;
        }

        // Tap action
        this.vibrate(12);
        this.handleCanvasClick(pos.x, pos.y, false);
      }, { passive: false });

      window.addEventListener('keyup', (e) => {
        const k = e.key.toLowerCase();
        if (this.state === 'TPS_3D' && this.tps3D) {
          if (k === 'w') this.tps3D.keys.w = false;
          if (k === 's') this.tps3D.keys.s = false;
          if (k === 'a') this.tps3D.keys.a = false;
          if (k === 'd') this.tps3D.keys.d = false;
          if (k === 'shift') this.tps3D.keys.shift = false;
        }
      });

      window.addEventListener('keydown', (e) => {
        audio.init();
        const k = e.key.toLowerCase();
        if (this.state === 'TPS_3D' && this.tps3D) {
          if (k === 'w') { this.tps3D.keys.w = true; return; }
          if (k === 's') { this.tps3D.keys.s = true; return; }
          if (k === 'a') { this.tps3D.keys.a = true; return; }
          if (k === 'd') { this.tps3D.keys.d = true; return; }
          if (k === 'shift') { this.tps3D.keys.shift = true; return; }
          if (k === 't') { this.toggle3DMechMode(); return; }
          if (k === 'r') { this.fire3DMissiles(); return; }
          if (k === 'z') { this.fire3DEMP(); return; }
          if (k === 'b') { this.tps3D.isBuilding = !this.tps3D.isBuilding; audio.upgrade(); return; }
          if (e.code === 'Space') { e.preventDefault(); this.shoot3DTPS(); return; }
          if (e.key === 'Escape' || k === 'p') {
            this.state = (this.waveActive || this.wave > 1) ? 'PLAYING' : 'MENU';
            if (this.state === 'MENU') audio.playBGMTrack('menu');
            return;
          }
        }
        if (k === 'p' && this.state === 'PLAYING') {
          this.start3DTPSMode();
          return;
        }
        if (e.key >= '1' && e.key <= '8') {
          const keys = ['pulse', 'mortar', 'cryo', 'tesla', 'flame', 'railgun', 'beacon', 'barricade'];
          this.selectBuildType(keys[parseInt(e.key) - 1]);
        } else if (e.code === 'Space') {
          e.preventDefault();
          if (this.state === 'PLAYING') this.triggerHeroUlt();
          else this.callNextWave();
        } else if (e.key === 'Escape') {
          if (this.aimingSkill) this.aimingSkill = null;
          else if (this.selectedTower) this.selectedTower = null;
          else if (this.selectedBuildType) this.selectedBuildType = null;
          else if (this.radialBuildCell) this.radialBuildCell = null;
          else if (this.hero.selected) this.hero.selected = false;
          else this.togglePause();
        } else if (k === 'u') this.upgradeSelectedTower();
        else if (k === 's') this.sellSelectedTower();
        else if (k === 't') {
          if (this.selectedTower) this.cycleTargetPriority();
          else this.toggleHeroTransform();
        }
        else if (k === 'z') this.triggerSkill('emp');
        else if (k === 'x') this.triggerSkill('missiles');
        else if (k === 'c') this.triggerSkill('shield');
        else if (k === 'v') this.triggerSkill('overclock');
        else if (k === 'b') this.triggerSkill('orbital');
        else if (k === 'n') this.triggerSkill('drone');
        else if (k === 'h') this.hero.selected = !this.hero.selected;
        else if (e.key === 'Tab') {
          e.preventDefault();
          this.cycleSpeed();
        }
      });
    }

    startMission(mapIdx = 0, mode = 'CAMPAIGN') {
      this.gameMode = mode;
      this.currentMapIndex = mapIdx;
      const savedCustom = localStorage.getItem('lg_custom_map');
      let customData = null;
      if (savedCustom) {
        try { customData = JSON.parse(savedCustom); } catch(e) {}
      }
      const customWaypoints = (customData && customData.waypoints && customData.waypoints.length >= 2) ? customData.waypoints : this.editorWaypoints;
      const customBiome = (customData && customData.biome) ? customData.biome : (this.editorBiome || 'cyber');
      const customGold = (customData && customData.gold) ? customData.gold : (this.editorGold || 350);
      const customWaves = (customData && customData.waves) ? customData.waves : (this.editorWaves || 20);

      const map = (mode === 'CUSTOM') ? {
        id: "custom", name: "Maxsus Sektor",
        gold: customGold, hp: 20, wave_count: customWaves, modifier: "none", biome: customBiome,
        lanes: [ customWaypoints ]
      } : MAPS[mapIdx];

      this.difficulty = localStorage.getItem('lg_difficulty') || 'NORMAL';
      const diffGoldMult = (this.difficulty === 'CASUAL') ? 1.25 : ((this.difficulty === 'HEROIC') ? 0.85 : 1.0);
      const diffHpMult = (this.difficulty === 'CASUAL') ? 1.2 : ((this.difficulty === 'HEROIC') ? 0.8 : 1.0);
      this.gold = Math.round((mode === 'BOSS_RUSH' ? 1200 : map.gold) * diffGoldMult);
      this.score = 0;
      this.baseHp = Math.round(map.hp * diffHpMult);
      this.maxBaseHp = this.baseHp;
      this.wave = 1;
      this.maxWaves = (mode === 'ENDLESS') ? 999 : (mode === 'BOSS_RUSH' ? 10 : map.wave_count);
      this.waveActive = false;
      this.waveCountdown = 8;
      this.speed = 1;
      try {
        const biome = (map && map.biome) ? map.biome : 'cyber';
        audio.playBGMTrack(biome);
        setTimeout(() => audio.playSample('hq_online', 0.8), 600);
      } catch(e) {}

      this.activeAugments = [];
      this.draftCards = [];
      this.analytics = {
        damageByTower: { pulse: 0, mortar: 0, cryo: 0, tesla: 0, flame: 0, railgun: 0, beacon: 0, hero: 0, skills: 0 },
        totalKills: 0,
        totalGold: this.gold,
        mvpName: "Pulse Tower"
      };

      // Reset Hero Mech
      this.hero.x = map.lanes[0][0].x + 120;
      this.hero.y = map.lanes[0][0].y;
      this.hero.targetX = this.hero.x;
      this.hero.targetY = this.hero.y;
      this.hero.hp = 400;
      this.hero.level = 1;
      this.hero.xp = 0;
      this.hero.currentUltCd = 0;
      this.hero.selected = false;
      this.hero.mode = 'BIPED';
      this.hero.speed = 130;
      this.hero.siegeRecoil = 0;
      this.hero.siegeCooldown = 0;
      this.hero.shieldDome = null;

      for (const k in this.skills) this.skills[k].currentCd = 0;
      this.skills.overclock.activeTime = 0;

      this.towers = [];
      this.enemies = [];
      this.projectiles = [];
      this.particles = [];
      this.floatingTexts = [];
      this.groundHazards = [];
      this.casings = [];
      this.scorchMarks = [];
      this.muzzleFlashes = [];
      this.footprints = [];
      this.spawnQueue = [];

      this.selectedBuildType = null;
      this.selectedTower = null;
      this.aimingSkill = null;
      this.state = 'PLAYING';
      this.bakeMapLanes(map);
      this.addFloatingText(`${map.name.toUpperCase()}`, 640, 200, "#00e5ff", 22);

      // Initialize Battlefield Dynamics (Barricades, Airdrops, Red Zones, Radio Comms)
      const baseBars = (mode === 'CUSTOM') ? [] : (MAP_BARRICADES[mapIdx] || []);
      this.barricades = baseBars.map(b => ({
        id: this.nextUid++,
        x: b.x, y: b.y,
        hp: b.hp, maxHp: b.maxHp,
        type: b.type,
        broken: false
      }));
      this.airdrops = [];
      this.redZones = [];
      this.airdropCooldown = 20.0;
      this.redZoneCooldown = 35.0;
      const briefingList = RADIO_BRIEFINGS[this.lang] || RADIO_BRIEFINGS.uz;
      this.triggerRadioComm("HQ COMMANDER", briefingList[mapIdx] || briefingList[0], 5.5);
    }

    bakeMapLanes(map) {
      this.bakedLanes = map.lanes.map(lane => {
        let total = 0;
        const segments = [];
        for (let i = 0; i < lane.length - 1; i++) {
          const p1 = lane[i];
          const p2 = lane[i + 1];
          const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
          segments.push({ p1, p2, start: total, length: dist });
          total += dist;
        }
        return { totalLength: total, segments, waypoints: lane };
      });
    }

    getPointAlongLane(laneIdx, px) {
      const lane = this.bakedLanes[laneIdx] || this.bakedLanes[0];
      if (px <= 0) return { x: lane.segments[0].p1.x, y: lane.segments[0].p1.y, angle: 0 };
      if (px >= lane.totalLength) {
        const last = lane.segments[lane.segments.length - 1];
        return { x: last.p2.x, y: last.p2.y, angle: 0 };
      }
      for (const seg of lane.segments) {
        if (px >= seg.start && px <= seg.start + seg.length) {
          const t = (px - seg.start) / seg.length;
          const x = seg.p1.x + (seg.p2.x - seg.p1.x) * t;
          const y = seg.p1.y + (seg.p2.y - seg.p1.y) * t;
          const angle = Math.atan2(seg.p2.y - seg.p1.y, seg.p2.x - seg.p1.x);
          return { x, y, angle };
        }
      }
      const last = lane.segments[lane.segments.length - 1];
      return { x: last.p2.x, y: last.p2.y, angle: 0 };
    }

    isPathCell(cellX, cellY) {
      const cx = cellX * 64 + 32;
      const cy = cellY * 64 + 32;
      const map = (this.gameMode === 'CUSTOM') ? { lanes: [this.editorWaypoints] } : MAPS[this.currentMapIndex];
      for (const lane of map.lanes) {
        for (let i = 0; i < lane.length - 1; i++) {
          const p1 = lane[i];
          const p2 = lane[i + 1];
          const dist = this.distToSegment({ x: cx, y: cy }, p1, p2);
          if (dist < 46) return true;
        }
      }
      return false;
    }

    distToSegment(p, v, w) {
      const l2 = (v.x - w.x) * (v.x - w.x) + (v.y - w.y) * (v.y - w.y);
      if (l2 === 0) return Math.hypot(p.x - v.x, p.y - v.y);
      let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
      t = Math.max(0, Math.min(1, t));
      return Math.hypot(p.x - (v.x + t * (w.x - v.x)), p.y - (v.y + t * (w.y - v.y)));
    }

        isValidBuildCell(gx, gy) {
      if (gx < 0 || gx >= 20 || gy < 1 || gy >= 10) return false;
      const isPath = this.isPathCell(gx, gy);
      const hasTower = this.towers.some(t => t.cellX === gx && t.cellY === gy);
      return !isPath && !hasTower;
    }

    updateHoverCell() {
      if (this.mousePos.y < 60 || this.mousePos.y > 620) {
        this.hoverCell = null;
        return;
      }
      const gx = Math.floor(this.mousePos.x / 64);
      const gy = Math.floor(this.mousePos.y / 64);
      if (gx >= 0 && gx < 20 && gy >= 1 && gy < 10) {
        const isPath = this.isPathCell(gx, gy);
        const hasTower = this.towers.some(t => t.cellX === gx && t.cellY === gy);
        this.hoverCell = { gx, gy, valid: !isPath && !hasTower };
      } else {
        this.hoverCell = null;
      }
    }

    handleCanvasClick(x, y, isRightClick = false) {
      if (this.state !== 'TPS_3D') {
        audio.click();
        this.vibrate(10);
      }
      // If Settings Modal is open -> handle settings interactions
      if (this.showSettingsModal) {
        this.handleSettingsClick(x, y);
        return;
      }
      if (this.state === 'TPS_3D') {
        if (x >= 20 && x <= 200 && y >= 15 && y <= 65) {
          this.state = (this.waveActive || this.wave > 1) ? 'PLAYING' : 'MENU';
          if (this.state === 'MENU') audio.playBGMTrack('menu');
          audio.sell();
          return;
        }
        // Mode toggle button
        if (x >= 955 && x <= 1060 && y >= 610 && y <= 665) {
          this.toggle3DMechMode();
          return;
        }
        // EMP button
        if (x >= 955 && x <= 1060 && y >= 550 && y <= 605) {
          this.fire3DEMP();
          return;
        }
        // Missile button
        if (x >= 1065 && x <= 1170 && y >= 550 && y <= 605) {
          this.fire3DMissiles();
          return;
        }
        if (Math.hypot(x - 1200, y - 620) <= 52) {
          if (this.tps3D.isBuilding) this.place3DTower();
          else this.shoot3DTPS();
          this.vibrate(22);
          return;
        }
        if (Math.hypot(x - 1080, y - 640) <= 40) {
          this.tps3D.player.isAiming = !this.tps3D.player.isAiming;
          return;
        }
        if (Math.hypot(x - 1200, y - 500) <= 40) {
          this.tps3D.isBuilding = !this.tps3D.isBuilding;
          audio.upgrade();
          return;
        }
        if (Math.hypot(x - 1080, y - 540) <= 35) {
          this.reload3DTPS();
          return;
        }
        if (x > 350) {
          if (this.tps3D.isBuilding) this.place3DTower();
          else this.shoot3DTPS();
          return;
        }
        return;
      }
      if (this.state === 'MENU') {
        // Left Hero Hangar Tap (Trigger Hero Sound or Open 3D Studio)
        if (x >= 40 && x <= 430 && y >= 88 && y <= 678) {
          if (y >= 580 || (x >= 55 && x <= 415 && y >= 570)) {
            window.location.href = 'preview_character.html';
            return;
          }
          audio.heroSlash();
          this.vibrate([30, 20, 50]);
          this.addFloatingText("⚡ APEX-01 SYSTEM ONLINE!", 235, 300, "#00e5ff", 18);
          return;
        }

        // Primary Action 1: Kampaniya (x: 455 to 835, y: 88 to 183)
        if (x >= 455 && x <= 835 && y >= 88 && y <= 183) { this.startMission(0, 'CAMPAIGN'); return; }

        // Primary Action 2: Cheksiz Omon Qolish (x: 855 to 1240, y: 88 to 183)
        if (x >= 855 && x <= 1240 && y >= 88 && y <= 183) { this.startMission(9, 'ENDLESS'); return; }

        // Secondary Action 3: 3D TPS Arena (x: 455 to 835, y: 195 to 267)
        if (x >= 455 && x <= 835 && y >= 195 && y <= 267) { this.start3DTPSMode(); return; }

        // Secondary Action 4: Sektorlar Xaritasi (x: 855 to 1240, y: 195 to 267)
        if (x >= 855 && x <= 1240 && y >= 195 && y <= 267) { this.state = 'MAP_SELECT'; return; }

        // Quick Ops Row 3 (y: 278 to 340)
        if (y >= 278 && y <= 340) {
          if (x >= 455 && x <= 640) { this.startMission(0, 'BOSS_RUSH'); return; }
          if (x >= 650 && x <= 835) { this.state = 'EDITOR'; return; }
          if (x >= 855 && x <= 1040) { this.state = 'LEADERBOARD'; return; }
          if (x >= 1055 && x <= 1240) { this.state = 'MANUAL'; return; }
        }

        // System Controls Row 4 (y: 350 to 408)
        if (y >= 350 && y <= 408) {
          if (x >= 455 && x <= 710) {
            this.showSettingsModal = true;
            this.settingsReturnState = 'MENU';
            if (this.apexSystem) this.apexSystem.hide();
            audio.click();
            return;
          }
          if (x >= 720 && x <= 975) { this.downloadApk(); return; }
          if (x >= 985 && x <= 1240) { this.downloadOfflineZip(); return; }
        }

        // Language Switcher Top Right
        if (x >= 1130 && x <= 1240 && y >= 18 && y <= 52) {
          this.toggleLanguage();
          return;
        }
        return;
      }

      if (this.state === 'DRAFT') {
        for (let i = 0; i < this.draftCards.length; i++) {
          const cx = 180 + i * 320;
          if (x >= cx && x <= cx + 280 && y >= 200 && y <= 520) {
            this.selectAugment(this.draftCards[i]);
            return;
          }
        }
        return;
      }

      if (this.state === 'ANALYTICS') {
        if (x >= 450 && x <= 830 && y >= 615 && y <= 695) {
          this.state = 'MENU';
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
        }
        return;
      }

      if (this.state === 'MANUAL') {
        if (x >= 20 && x <= 160 && y >= 10 && y <= 65) {
          this.state = 'MENU';
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
          return;
        }

        // Tabs
        if (y >= 15 && y <= 55) {
          if (x >= 440 && x <= 605) { this.codexTab = 'TOWERS'; this.codexSelectedId = 'pulse'; audio.click(); return; }
          if (x >= 620 && x <= 795) { this.codexTab = 'ENEMIES'; this.codexSelectedId = 'grunt'; audio.click(); return; }
          if (x >= 810 && x <= 1005) { this.codexTab = 'BOSSES'; this.codexSelectedId = 'juggernaut'; audio.click(); return; }
          if (x >= 1020 && x <= 1205) { this.codexTab = 'MECH'; this.codexSelectedId = 'biped'; audio.click(); return; }
        }

        // Item List clicks
        if (x >= 38 && x <= 312) {
          const tab = this.codexTab || 'TOWERS';
          const counts = { TOWERS: 8, ENEMIES: 9, BOSSES: 6, MECH: 2 };
          const count = counts[tab] || 8;
          const itemH = Math.min(68, Math.floor(590 / count));
          for (let i = 0; i < count; i++) {
            const iy = 88 + i * (itemH + 4);
            if (y >= iy && y <= iy + itemH) {
              const listMap = {
                TOWERS: ['pulse', 'mortar', 'cryo', 'tesla', 'flame', 'railgun', 'beacon', 'barricade'],
                ENEMIES: ['grunt', 'sprinter', 'brute', 'shieldbearer', 'medic', 'splitter', 'phantom', 'kamikaze_drone', 'gunship'],
                BOSSES: ['juggernaut', 'overseer', 'hive_titan', 'void_titan', 'chrono_phantom', 'mecha_colossus'],
                MECH: ['biped', 'siege']
              };
              const selList = listMap[tab] || listMap.TOWERS;
              if (selList[i]) {
                this.codexSelectedId = selList[i];
                audio.click();
                this.vibrate(15);
                return;
              }
            }
          }
        }
        return;
      }

      if (this.state === 'MAP_SELECT') {
        if (y >= 10 && y <= 65 && x >= 20 && x <= 180) {
          this.state = 'MENU';
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
          return;
        }
        if (x >= 580 && x <= 920 && y >= 18 && y <= 58) {
          const idx = Math.floor((x - 580) / 110);
          const diffs = ['CASUAL', 'NORMAL', 'HEROIC'];
          if (diffs[idx]) {
            this.difficulty = diffs[idx];
            localStorage.setItem('lg_difficulty', this.difficulty);
            audio.click();
            this.vibrate(15);
          }
          return;
        }
        for (let i = 0; i < 10; i++) {
          const col = i % 5;
          const row = Math.floor(i / 5);
          const mx = 40 + col * 242;
          const my = 75 + row * 245;
          if (x >= mx && x <= mx + 230 && y >= my && y <= my + 230) {
            this.startMission(i, 'CAMPAIGN');
            return;
          }
        }
        if (y >= 565 && y <= 700) {
          if (x >= 820 && x <= 1040) {
            this.startMission(0, 'CUSTOM');
            return;
          }
          if (x >= 1060 && x <= 1220) {
            this.state = 'EDITOR';
            return;
          }
        }
        return;
      }

      if (this.state === 'LEADERBOARD') {
        if (y > 25 && y < 65 && x > 50 && x < 150) {
          this.state = 'MENU';
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
          return;
        }
        if (x > 1050 && x < 1220 && y > 25 && y < 65) {
          const newName = prompt("Enter CyberCommander handle:", this.playerName);
          if (newName && newName.trim()) {
            this.playerName = newName.trim().substring(0, 18);
            localStorage.setItem('last_grid_player_name', this.playerName);
          }
        }
        return;
      }

      if (this.state === 'EDITOR') {
        this.handleEditorClick(x, y);
        return;
      }

      if (this.state === 'VICTORY' || this.state === 'DEFEAT') {
        if (this.state === 'VICTORY' && x >= 340 && x <= 940 && y >= 475 && y <= 540) {
          // Continue Endless Survival Mode!
          this.gameMode = 'ENDLESS';
          this.maxWaves = 999;
          this.wave = 31;
          this.waveActive = false;
          this.waveCountdown = 8;
          this.state = 'PLAYING';
          audio.upgrade();
          this.vibrate([30, 40, 60]);
          this.triggerRadioComm("HQ OVERWATCH", "⚠️ CHEKSIZ REJIM FAOL! Barcha mudofaa minoralari saqlandi. Omon qoling, Komandir!", 5.0);
          return;
        }
        if (x >= 330 && x <= 530 && y >= 405 && y <= 470) this.startMission(this.currentMapIndex, this.gameMode);
        else if (x >= 540 && x <= 740 && y >= 405 && y <= 470) this.state = 'ANALYTICS';
        else if (x >= 750 && x <= 950 && y >= 405 && y <= 470) {
          this.state = 'MENU';
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
        }
        return;
      }

      // Handle Tactic Pause Modal Clicks (Davom etish, Sozlamalar, Chiqish)
      if (this.state === 'PAUSED') {
        // Button 1: Davom Etish (Resume Combat: 440, 340, 400, 50)
        if (x >= 440 && x <= 840 && y >= 340 && y <= 390) {
          this.state = 'PLAYING';
          audio.modal();
          this.vibrate(15);
          return;
        }
        // Button 2: Sozlamalar (440, 405, 400, 50)
        if (x >= 440 && x <= 840 && y >= 405 && y <= 455) {
          this.showSettingsModal = true;
          this.settingsReturnState = 'PAUSED';
          if (this.apexSystem) this.apexSystem.hide();
          audio.click();
          this.vibrate(15);
          return;
        }
        // Button 3: Asosiy Menyuga Qaytish (440, 470, 400, 50)
        if (x >= 440 && x <= 840 && y >= 470 && y <= 520) {
          this.state = 'MENU';
          this.selectedTower = null;
          this.selectedBuildType = null;
          this.radialBuildCell = null;
          if (this.apexSystem) this.apexSystem.show();
          audio.playBGMTrack('menu');
          audio.sell();
          this.vibrate(25);
          return;
        }
        return; // Click blocked by pause overlay
      }

      // Tutorial Skip Click
      if (this.currentMapIndex === 0 && !localStorage.getItem('lg_tutorial_done') && x >= 1090 && x <= 1240 && y >= 15 && y <= 50) {
        localStorage.setItem('lg_tutorial_done', 'true');
        this.addFloatingText("TUTORIAL O'TKAZILDI", 640, 100, "#ffd600");
        return;
      }

      // 1. Mobile Floating Thumb Buttons (⚡ ULT & ▶ WAVE/SPEED)
      if (Math.hypot(x - 1210, y - 540) <= 45) {
        this.triggerHeroUlt();
        this.vibrate([40, 25, 70]);
        return;
      }
      if (Math.hypot(x - 1210, y - 450) <= 36) {
        if (!this.waveActive) this.callNextWave();
        else this.cycleSpeed();
        this.vibrate(20);
        return;
      }

      // Radar Minimap Click / Tactical Waypoint Navigation
      if (x >= 1118 && x <= 1266 && y >= 62 && y <= (this.minimapExpanded ? 162 : 92)) {
        if (y <= (this.minimapExpanded ? 84 : 92)) {
          this.minimapExpanded = !this.minimapExpanded;
          audio.click();
        } else if (this.minimapExpanded) {
          const ix = 1118 + 6;
          const iy = 62 + 22;
          const iw = 148 - 12;
          const ih = 100 - 26;
          const targetWorldX = Math.max(64, Math.min(1216, (x - ix) / (iw / 1280)));
          const targetWorldY = Math.max(64, Math.min(640, (y - iy) / (ih / 704)));
          this.hero.targetX = targetWorldX;
          this.hero.targetY = targetWorldY;
          this.hero.selected = false;
          this.hero.dashSpeedBoost = 2.4;
          this.hero.dashTimer = 0.45;
          this.spawnShockwave(targetWorldX, targetWorldY, 35, "#00e5ff");
          this.addFloatingText("RADAR WAYPOINT", targetWorldX, targetWorldY - 20, "#00e5ff", 14);
          if (audio) audio.shootPulse();
          this.vibrate([20, 20]);
        }
        return;
      }

      // 2. Mobile Quick Radial Build Wheel Clicks
      if (this.radialBuildCell) {
        const rc = this.radialBuildCell;
        const towerList = ['pulse', 'mortar', 'cryo', 'tesla', 'flame', 'railgun', 'beacon', 'barricade'];
        let chosen = null;
        for (let i = 0; i < 8; i++) {
          const ang = -Math.PI / 2 + (Math.PI * 2 / 8) * i;
          const bx = rc.px + Math.cos(ang) * 84;
          const by = rc.py + Math.sin(ang) * 84;
          if (Math.hypot(x - bx, y - by) <= 28) {
            chosen = towerList[i];
            break;
          }
        }
        if (chosen) {
          this.buildTower(chosen, rc.gx, rc.gy);
          this.radialBuildCell = null;
          this.vibrate([25, 30, 25]);
          return;
        } else {
          // Tapped outside radial buttons or center dismisses
          this.radialBuildCell = null;
          return;
        }
      }

      // 3. Hero Click or Move with Kinetic Booster Dash
      if (this.hero.selected) {
        if (y >= 60 && y <= 620) {
          this.hero.targetX = x;
          this.hero.targetY = y;
          this.hero.selected = false;
          // Trigger Kinetic Booster Rocket Dash
          this.hero.dashSpeedBoost = 2.4;
          this.hero.dashTimer = 0.45;
          this.spawnShockwave(this.hero.x, this.hero.y, 45, "#00e5ff");
          this.spawnShockwave(x, y, 35, "#ffd600");
          this.addFloatingText("⚡ KINETIC DASH!", this.hero.x, this.hero.y - 25, "#00e5ff", 16);
          if (audio) audio.shootPulse();
          this.vibrate([20, 20, 35]);
          return;
        }
      }

      if (Math.hypot(this.hero.x - x, this.hero.y - y) <= 38) {
        this.hero.selected = !this.hero.selected;
        this.selectedTower = null;
        this.selectedBuildType = null;
        this.radialBuildCell = null;
        if (this.hero.selected) {
          this.addFloatingText("HERO SELECTED: TAP MAP TO MOVE", this.hero.x, this.hero.y - 30, "#ffd600", 14);
        }
        audio.hit();
        this.vibrate(15);
        return;
      }

      // 4. Top HUD Bar clicks
      if (y >= 0 && y <= 60) {
        if (x >= 440 && x <= 618) this.callNextWave();
        else if (x >= 620 && x <= 718) this.cycleSpeed();
        else if (x >= 720 && x <= 852) {
          this.showSettingsModal = true;
          this.settingsReturnState = (this.state === 'PAUSED' ? 'PAUSED' : 'PLAYING');
          if (this.apexSystem) this.apexSystem.hide();
          audio.click();
        }
        else if (x >= 855 && x <= 968) this.togglePause();
        else if (x >= 970 && x <= 1090) {
          this.state = 'PAUSED';
          audio.modal();
        }
        else if (x >= 1092 && x <= 1265) {
          this.start3DTPSMode();
          return;
        }
        return;
      }

      if (this.aimingSkill) {
        this.executeSkill(this.aimingSkill, x, y);
        this.aimingSkill = null;
        return;
      }

      // Airdrop Crate Tap / Click Looting
      if (this.airdrops && this.airdrops.length > 0) {
        for (const ad of this.airdrops) {
          if (ad.landed && !ad.looted && Math.hypot(x - ad.crateX, y - ad.crateY) <= 45) {
            this.lootAirdrop(ad);
            return;
          }
        }
      }

      // Barricade Tap: Repair or Rebuild
      if (this.barricades && this.barricades.length > 0) {
        for (const b of this.barricades) {
          if (Math.hypot(x - b.x, y - b.y) <= 35) {
            if (b.broken) {
              if (this.gold >= 45) {
                this.gold -= 45;
                b.broken = false;
                b.hp = b.maxHp;
                audio.upgrade();
                this.spawnShockwave(b.x, b.y, 60, "#00e676");
                this.addFloatingText("🏗️ QAYTA QURILDI (-45g)", b.x, b.y - 20, "#00e676", 16);
                this.triggerRadioComm("HQ OVERWATCH", "HQ: Himoya to'sig'i qayta tiklandi!", 3.5);
                this.vibrate([30, 40, 50]);
              } else {
                this.addFloatingText(this.t("notEnoughGold") + " (45g)", b.x, b.y - 20, "#ff1744", 15);
              }
              return;
            } else if (b.hp < b.maxHp) {
              if (this.gold >= 20) {
                this.gold -= 20;
                b.hp = Math.min(b.maxHp, b.hp + 120);
                audio.upgrade();
                this.addFloatingText("🔧 +120 HP (-20g)", b.x, b.y - 20, "#00e5ff", 16);
                this.vibrate(20);
              } else {
                this.addFloatingText(this.t("notEnoughGold") + " (20g)", b.x, b.y - 20, "#ff1744", 15);
              }
              return;
            }
          }
        }
      }

      // Tactical Holographic Radial Tower Clicks (When tower is selected)
      if (this.selectedTower) {
        const t = this.selectedTower;
        const def = TOWER_DEFS[t.type];

        // Top Upgrade / Branch Clicks
        if (t.tier === 2) {
          if (x >= t.x - 110 && x <= t.x - 5 && y >= t.y - 70 && y <= t.y - 34) { this.upgradeBranch('A'); return; }
          if (x >= t.x + 5 && x <= t.x + 110 && y >= t.y - 70 && y <= t.y - 34) { this.upgradeBranch('B'); return; }
        } else if (t.tier === 1) {
          if (x >= t.x - 70 && x <= t.x + 70 && y >= t.y - 65 && y <= t.y - 29) { this.upgradeSelectedTower(); return; }
        }

        // Left Sell Click
        if (x >= t.x - 115 && x <= t.x - 40 && y >= t.y - 18 && y <= t.y + 18) { this.sellSelectedTower(); return; }

        // Right Priority Click
        if (x >= t.x + 40 && x <= t.x + 115 && y >= t.y - 18 && y <= t.y + 18) { this.cycleTargetPriority(); return; }

        // Bottom Close Click
        if (x >= t.x - 35 && x <= t.x + 35 && y >= t.y + 40 && y <= t.y + 68) { this.selectedTower = null; return; }
      }

      // 5. Bottom Bar actions
      if (y >= 620) {
        this.radialBuildCell = null;

        // Hero Mech Ult button at x: 5 to 49
        if (x >= 5 && x <= 49) { this.triggerHeroUlt(); this.vibrate([40, 25, 70]); return; }

        // Hero Mech Mode Toggle button at x: 50 to 95
        if (x >= 50 && x <= 95) { this.toggleHeroTransform(); return; }

        // Commander Super Skills Mobile Buttons (x: 98, 142, 186, 230; each w: 40)
        if (x >= 96 && x <= 139) { this.triggerSkill('emp'); this.vibrate(20); return; }
        else if (x >= 140 && x <= 183) { this.triggerSkill('missiles'); this.vibrate(20); return; }
        else if (x >= 184 && x <= 227) { this.triggerSkill('shield'); this.vibrate(20); return; }
        else if (x >= 228 && x <= 273) { this.triggerSkill('overclock'); this.vibrate(20); return; }

        if (this.selectedTower) {
          const t = this.selectedTower;
          const def = TOWER_DEFS[t.type];

          // Tier 3 Branch A and Branch B buttons
          if (t.tier === 2) {
            if (x >= 485 && x <= 635 && y >= 630 && y <= 705) { this.upgradeBranch('A'); this.vibrate([25, 30, 25]); return; }
            if (x >= 640 && x <= 790 && y >= 630 && y <= 705) { this.upgradeBranch('B'); this.vibrate([25, 30, 25]); return; }
          } else {
            // Normal Upgrade (Tier 1 -> Tier 2)
            if (x >= 515 && x <= 665 && y >= 630 && y <= 705) { this.upgradeSelectedTower(); this.vibrate([25, 30, 25]); return; }
          }

          // Sell button
          if (x >= 795 && x <= 915 && y >= 630 && y <= 705) { this.sellSelectedTower(); this.vibrate(20); return; }
          // Priority button
          if (x >= 920 && x <= 1045 && y >= 630 && y <= 705) { this.cycleTargetPriority(); this.vibrate(15); return; }
          // Close button
          if (x >= 1050 && x <= 1110 && y >= 630 && y <= 705) { this.selectedTower = null; return; }
        } else {
          // 8 Hotbar Items (7 Towers + Barricade)
          const hotbarKeys = ['pulse', 'mortar', 'cryo', 'tesla', 'flame', 'railgun', 'beacon', 'barricade'];
          for (let i = 0; i < 8; i++) {
            const bx = 276 + i * 125;
            if (x >= bx && x <= bx + 120 && y >= 625 && y <= 715) {
              if (i === 7) {
                this.selectedBuildType = (this.selectedBuildType === 'barricade') ? null : 'barricade';
              } else {
                this.selectBuildType(hotbarKeys[i]);
              }
              this.vibrate(15);
              return;
            }
          }
        }
        return;
      }

      // 6. Grid Cell Taps (Radial Quick-Build or Direct Build)
      const gx = Math.floor(x / 64);
      const gy = Math.floor(y / 64);
      const clickedTower = this.towers.find(t => t.cellX === gx && t.cellY === gy);

      if (clickedTower) {
        this.selectedTower = clickedTower;
        this.selectedBuildType = null;
        this.hero.selected = false;
        this.radialBuildCell = null;
        this.vibrate(15);
      } else if (this.selectedBuildType && this.isValidBuildCell(gx, gy)) {
        this.buildTower(this.selectedBuildType, gx, gy);
        this.selectedBuildType = null;
        this.radialBuildCell = null;
        this.vibrate([25, 30, 25]);
      } else if (y >= 60 && y <= 620 && this.isValidBuildCell(gx, gy)) {
        // Open Radial Quick Build on empty valid cell!
        this.radialBuildCell = { gx, gy, px: gx * 64 + 32, py: gy * 64 + 32 };
        this.selectedTower = null;
        this.selectedBuildType = null;
        this.vibrate(15);
      } else {
        this.selectedTower = null;
        this.radialBuildCell = null;
      }
    }

    // --- BATTLEFIELD DYNAMICS METHODS (v4.0.0) ---
    triggerRadioComm(speaker, text, duration = 4.5, sampleKey = null) {
      this.radioComm = {
        speaker: speaker || "HQ COMMANDER",
        text: text || "",
        maxTimer: duration,
        timer: duration,
        anim: 0
      };
      audio.voiceRadio(text, sampleKey);
    }

    updateRadioComms(dt) {
      if (this.radioComm) {
        this.radioComm.timer -= dt;
        this.radioComm.anim += dt * 32;
        if (this.radioComm.timer <= 0) this.radioComm = null;
      }
    }

    updateBiomeParticles(dt) {
      if (!this.biomeParticles) this.biomeParticles = [];
      const map = (this.gameMode === 'CUSTOM') ? { biome: "cyber" } : MAPS[this.currentMapIndex];
      const biome = (map && map.biome) ? map.biome : "cyber";

      if (this.biomeParticles.length < 28) {
        if (biome === 'lava') {
          this.biomeParticles.push({
            x: Math.random() * this.width,
            y: 620 + Math.random() * 20,
            vx: (Math.random() - 0.5) * 20,
            vy: -30 - Math.random() * 40,
            size: 1.5 + Math.random() * 2.5,
            life: 2.0 + Math.random() * 2.0,
            maxLife: 4.0,
            color: Math.random() > 0.4 ? "#ff3d00" : "#ff9100"
          });
        } else if (biome === 'cryo') {
          this.biomeParticles.push({
            x: Math.random() * this.width,
            y: 50 + Math.random() * 30,
            vx: 15 + Math.random() * 25,
            vy: 20 + Math.random() * 30,
            size: 1.2 + Math.random() * 2.2,
            life: 3.0 + Math.random() * 3.0,
            maxLife: 6.0,
            color: Math.random() > 0.3 ? "#80deea" : "#ffffff"
          });
        }
      }

      for (let i = this.biomeParticles.length - 1; i >= 0; i--) {
        const p = this.biomeParticles[i];
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.life -= dt;
        if (p.life <= 0 || p.x < 0 || p.x > this.width || p.y < 55 || p.y > 625) {
          this.biomeParticles.splice(i, 1);
        }
      }
    }

    renderBiomeParticles(ctx, biome) {
      if (!this.biomeParticles || biome === 'cyber') return;
      ctx.save();
      for (const p of this.biomeParticles) {
        const alpha = Math.max(0, p.life / p.maxLife) * 0.7;
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    renderBossAlert() {
      if (!this.bossAlert || this.bossAlert.timer <= 0) return;
      const ctx = this.ctx;
      const b = this.bossAlert;
      const alpha = Math.min(1.0, b.timer, (b.maxTimer - b.timer) * 2.5);
      const pulse = (Math.sin(performance.now() * 0.012) + 1) * 0.5;

      ctx.save();
      // 1. Screen Edge Threat Pulsing
      ctx.strokeStyle = `rgba(255, 23, 68, ${0.25 + pulse * 0.45 * alpha})`;
      ctx.lineWidth = 6;
      ctx.strokeRect(3, 63, this.width - 6, 554);

      // 2. Center Cinematic Holographic Banner
      const bw = 680;
      const bh = 95;
      const bx = (this.width - bw) / 2;
      const by = 85;

      ctx.fillStyle = `rgba(10, 2, 6, ${0.90 * alpha})`;
      ctx.fillRect(bx, by, bw, bh);

      ctx.strokeStyle = `rgba(255, 23, 68, ${0.9 * alpha})`;
      ctx.lineWidth = 2;
      ctx.strokeRect(bx, by, bw, bh);

      ctx.fillStyle = `rgba(255, 23, 68, ${alpha})`;
      ctx.font = "bold 13px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.fillText("⚠️ TIKLANISH REJIMI: RED ALERT • TITAN BOSS ANIQLANDI ⚠️", 640, by + 22);

      ctx.font = "900 24px 'Segoe UI', monospace";
      ctx.fillStyle = b.color || "#ff1744";
      ctx.fillText(`${b.marker} ${b.name}`, 640, by + 52);

      ctx.font = "bold 12px monospace";
      ctx.fillStyle = "#cfd8dc";
      ctx.fillText(`HP: ${b.hp}  |  ARMOR: ${b.armor}  |  ${b.desc || "CRITICAL SECTOR THREAT"}`, 640, by + 76);

      ctx.restore();
    }

    renderRadioComms() {
      if (!this.radioComm) return;
      const ctx = this.ctx;
      const rc = this.radioComm;
      const bx = 16, by = 68, bw = 460, bh = 70;

      ctx.save();
      // Cyber Glassmorphism Box
      ctx.fillStyle = "rgba(7, 12, 24, 0.92)";
      ctx.fillRect(bx, by, bw, bh);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.65)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(bx, by, bw, bh);

      // Top Header
      ctx.fillStyle = "rgba(0, 229, 255, 0.15)";
      ctx.fillRect(bx, by, bw, 20);
      ctx.fillStyle = "#ff1744";
      ctx.beginPath();
      ctx.arc(bx + 12, by + 10, 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 10px monospace";
      ctx.textAlign = "left";
      ctx.fillText("LIVE COMMS // CH-01 SEC-NET", bx + 22, by + 14);

      // Audio waveform animation
      const now = performance.now() * 0.01;
      for (let i = 0; i < 6; i++) {
        const barH = 3 + Math.abs(Math.sin(now + i * 0.8)) * 10;
        ctx.fillStyle = "#ffd600";
        ctx.fillRect(bx + bw - 60 + i * 8, by + 16 - barH, 4, barH);
      }

      // Speaker & Message
      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 11px monospace";
      ctx.fillText(rc.speaker, bx + 12, by + 36);

      ctx.fillStyle = "#ffffff";
      ctx.font = "11px monospace";
      const charCount = Math.floor(rc.anim);
      const visibleText = rc.text.substring(0, charCount);

      // Multi-line wrap
      const words = visibleText.split(" ");
      let line1 = "", line2 = "";
      for (const w of words) {
        if ((line1 + " " + w).length <= 44) line1 += (line1 ? " " : "") + w;
        else line2 += (line2 ? " " : "") + w;
      }
      ctx.fillText(line1, bx + 12, by + 50);
      if (line2) ctx.fillText(line2, bx + 12, by + 64);

      ctx.restore();
    }

    spawnAirdrop() {
      const tx = 260 + Math.random() * 740;
      const ty = 140 + Math.random() * 420;
      this.airdrops.push({
        id: this.nextUid++,
        planeX: -120,
        planeY: 52,
        planeSpeed: 380,
        targetX: tx,
        targetY: ty,
        cargoDropped: false,
        crateX: tx,
        crateY: 52,
        crateVy: 65,
        landed: false,
        looted: false,
        smokeFlareTimer: 25.0,
        swingAnim: 0
      });
      audio.airdropFlyby();
      this.triggerRadioComm("HQ OVERWATCH", "📦 Taktik Kiber-Airdrop havoda! Koordinataga yuk tashlanmoqda!", 4.0);
    }

    updateAirdrops(dt) {
      for (let i = this.airdrops.length - 1; i >= 0; i--) {
        const ad = this.airdrops[i];
        if (!ad.cargoDropped) {
          ad.planeX += ad.planeSpeed * dt;
          if (Math.random() < 0.45) {
            this.particles.push({
              x: ad.planeX - 35, y: ad.planeY,
              vx: -40, vy: (Math.random() * 6 - 3),
              color: "rgba(200, 230, 255, 0.4)", size: 3, growth: 8, life: 0.4, maxLife: 0.4
            });
          }
          if (ad.planeX >= ad.targetX) {
            ad.cargoDropped = true;
            ad.crateX = ad.targetX;
            ad.crateY = ad.planeY;
          }
        }
        if (ad.cargoDropped && !ad.landed) {
          ad.crateY += ad.crateVy * dt;
          ad.swingAnim += dt * 4.0;
          if (ad.crateY >= ad.targetY) {
            ad.crateY = ad.targetY;
            ad.landed = true;
            this.screenShake = 5;
            audio.hit();
            for (let k = 0; k < 10; k++) {
              this.particles.push({
                x: ad.crateX, y: ad.crateY,
                vx: (Math.random() * 80 - 40),
                vy: (Math.random() * 40 - 20),
                color: "#e2e8f0", size: 3, life: 0.4, maxLife: 0.4
              });
            }
            this.addFloatingText("📦 AIRDROP YERGA TUSHDI!", ad.crateX, ad.crateY - 20, "#ffd600", 15);
          }
        }
        if (ad.landed && !ad.looted) {
          ad.smokeFlareTimer -= dt;
          if (Math.random() < 0.5) {
            this.particles.push({
              x: ad.crateX + (Math.random() * 8 - 4),
              y: ad.crateY - 14,
              vx: (Math.random() * 14 - 7),
              vy: -55 - Math.random() * 30,
              color: "rgba(255, 23, 68, 0.75)", size: 4, growth: 14, life: 0.8, maxLife: 0.8
            });
          }
          // Auto-pickup by Hero Mech
          if (Math.hypot(this.hero.x - ad.crateX, this.hero.y - ad.crateY) <= 46) {
            this.lootAirdrop(ad);
          }
        }
        if (ad.looted && ad.smokeFlareTimer <= 0) {
          this.airdrops.splice(i, 1);
        }
      }
    }

    lootAirdrop(ad) {
      if (ad.looted) return;
      ad.looted = true;
      ad.smokeFlareTimer = 2.0;
      const rewardGold = 250;
      this.gold += rewardGold;
      this.score += 500;
      this.skills.overclock.activeTime = 12.0; // 12s Double Fire Rate Overclock Matrix!
      audio.airdropLoot();
      this.vibrate([50, 40, 100, 50, 150]);
      this.spawnShockwave(ad.crateX, ad.crateY, 140, "#ffd600");
      this.addFloatingText(`+${rewardGold} OLTIN! OVERCLOCK MATRIX FAOL!`, ad.crateX, ad.crateY - 25, "#ffd600", 20);
      this.triggerRadioComm("HQ COMMANDER", "📦 Airdrop ochildi! +250 Oltin olindi va barcha minoralarga Overclock kuchaytirish berildi!", 4.5);
    }

    renderAirdrops() {
      const ctx = this.ctx;
      for (const ad of this.airdrops) {
        // 1. Cargo Transport Aircraft
        if (ad.planeX < this.width + 120) {
          ctx.save();
          ctx.translate(ad.planeX, ad.planeY);
          ctx.fillStyle = "#1e293b";
          ctx.beginPath();
          ctx.moveTo(35, 0);
          ctx.lineTo(-30, -18);
          ctx.lineTo(-20, 0);
          ctx.lineTo(-30, 18);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = "#00e5ff";
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // Navigation lights
          ctx.fillStyle = "#00e676";
          ctx.beginPath(); ctx.arc(-25, -16, 2.5, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = "#ff1744";
          ctx.beginPath(); ctx.arc(-25, 16, 2.5, 0, Math.PI * 2); ctx.fill();
          ctx.restore();
        }

        // 2. Parachute & Crate descending
        if (ad.cargoDropped && !ad.landed) {
          ctx.save();
          ctx.translate(ad.crateX, ad.crateY);
          const sway = Math.sin(ad.swingAnim) * 0.15;
          ctx.rotate(sway);

          // Parachute Canopy
          ctx.beginPath();
          ctx.arc(0, -32, 28, Math.PI, 0, false);
          ctx.closePath();
          ctx.fillStyle = "#ff1744";
          ctx.fill();
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 2;
          ctx.stroke();

          // White center gore
          ctx.beginPath();
          ctx.arc(0, -32, 14, Math.PI, 0, false);
          ctx.closePath();
          ctx.fillStyle = "#ffffff";
          ctx.fill();

          // Suspension cords
          ctx.strokeStyle = "rgba(255, 255, 255, 0.7)";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-26, -32); ctx.lineTo(-8, -6);
          ctx.moveTo(26, -32); ctx.lineTo(8, -6);
          ctx.moveTo(0, -32); ctx.lineTo(0, -6);
          ctx.stroke();

          // Supply Crate
          ctx.fillStyle = "#d32f2f";
          ctx.fillRect(-12, -8, 24, 20);
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 1.5;
          ctx.strokeRect(-12, -8, 24, 20);
          ctx.restore();
        }

        // 3. Landed Crate with Red Smoke Signal Flare
        if (ad.landed && !ad.looted) {
          ctx.save();
          ctx.translate(ad.crateX, ad.crateY);

          // Pulsing Beacon Ring
          const pulse = (Math.sin(performance.now() * 0.006) + 1) * 0.5;
          ctx.strokeStyle = `rgba(255, 23, 68, ${0.4 + pulse * 0.5})`;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(0, 0, 26 + pulse * 10, 0, Math.PI * 2);
          ctx.stroke();

          // Dropped parachute fabric on ground
          ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
          ctx.beginPath();
          ctx.ellipse(-16, 6, 12, 6, -0.2, 0, Math.PI * 2);
          ctx.fill();

          // Crate body
          ctx.fillStyle = "#b71c1c";
          ctx.fillRect(-14, -14, 28, 24);
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 2;
          ctx.strokeRect(-14, -14, 28, 24);

          // Stencil mark
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 8px monospace";
          ctx.textAlign = "center";
          ctx.fillText("AIRDROP", 0, 1);

          // Beacon Strobe
          ctx.fillStyle = pulse > 0.5 ? "#ffd600" : "#ff1744";
          ctx.beginPath();
          ctx.arc(0, -15, 3, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = "#ffd600";
          ctx.font = "bold 10px monospace";
          ctx.fillText("📦 TEGING!", 0, -26);
          ctx.restore();
        }
      }
    }

    triggerRedZone() {
      let rx = 640, ry = 360;
      if (this.enemies.length > 0) {
        const e = this.enemies[Math.floor(Math.random() * this.enemies.length)];
        rx = e.x; ry = e.y;
      } else {
        rx = 320 + Math.random() * 640;
        ry = 180 + Math.random() * 320;
      }
      audio.redZoneSiren();
      this.triggerRadioComm("HQ OVERWATCH", "🚨 XAVF: Red Zone artilleriya zarbasi! 4 soniyada zonani tark eting!", 4.5);
      this.redZones.push({
        id: this.nextUid++,
        x: rx, y: ry,
        radius: 135,
        warningTimer: 4.5,
        activeTimer: 5.0,
        shellsToFire: 9,
        shellInterval: 0.45,
        shellCooldown: 0,
        shells: []
      });
    }

    updateRedZones(dt) {
      for (let i = this.redZones.length - 1; i >= 0; i--) {
        const rz = this.redZones[i];
        if (rz.warningTimer > 0) {
          rz.warningTimer -= dt;
        } else if (rz.activeTimer > 0) {
          rz.activeTimer -= dt;
          rz.shellCooldown -= dt;
          if (rz.shellsToFire > 0 && rz.shellCooldown <= 0) {
            rz.shellCooldown = rz.shellInterval;
            rz.shellsToFire--;
            const targetX = rz.x + (Math.random() * (rz.radius * 1.5) - rz.radius * 0.75);
            const targetY = rz.y + (Math.random() * (rz.radius * 1.5) - rz.radius * 0.75);
            const startX = targetX - 160;
            const startY = -40;
            rz.shells.push({
              startX, startY, targetX, targetY,
              x: startX, y: startY,
              flightTime: 0.32, t: 0
            });
          }
        }
        // Update shells
        for (let j = rz.shells.length - 1; j >= 0; j--) {
          const sh = rz.shells[j];
          sh.t += dt / sh.flightTime;
          sh.x = sh.startX + (sh.targetX - sh.startX) * sh.t;
          sh.y = sh.startY + (sh.targetY - sh.startY) * sh.t;
          if (Math.random() < 0.6) {
            this.particles.push({
              x: sh.x, y: sh.y,
              vx: (Math.random() * 20 - 10), vy: (Math.random() * 20 - 10),
              color: "#ff9100", size: 2.5, life: 0.2, maxLife: 0.2
            });
          }
          if (sh.t >= 1.0) {
            // Detonation!
            audio.artilleryBlast();
            this.screenShake = 14;
            this.spawnShockwave(sh.targetX, sh.targetY, 95, "#ff1744");
            this.scorchMarks.push({ x: sh.targetX, y: sh.targetY, radius: 24, life: 12.0, maxLife: 12.0 });
            for (let k = 0; k < 16; k++) {
              this.particles.push({
                x: sh.targetX, y: sh.targetY,
                vx: (Math.random() * 180 - 90),
                vy: (Math.random() * 180 - 90),
                color: Math.random() < 0.5 ? "#ff3d00" : "#ff9100",
                size: 3 + Math.random() * 4, growth: 8, life: 0.5, maxLife: 0.5
              });
            }
            // Damage enemies in 85px radius
            for (const e of this.enemies) {
              if (Math.hypot(e.x - sh.targetX, e.y - sh.targetY) <= 85) {
                this.applyDamage(e, 420, 'EXPLOSIVE', null, 'mortar');
              }
            }
            // Damage Hero Mech if inside
            if (Math.hypot(this.hero.x - sh.targetX, this.hero.y - sh.targetY) <= 85) {
              this.hero.hp = Math.max(0, this.hero.hp - 35);
              this.addFloatingText("⚠️ MECH -35 HP!", this.hero.x, this.hero.y - 20, "#ff1744", 16);
              this.vibrate([60, 40, 60]);
            }
            rz.shells.splice(j, 1);
          }
        }
        if (rz.warningTimer <= 0 && rz.activeTimer <= 0 && rz.shells.length === 0 && rz.shellsToFire === 0) {
          this.redZones.splice(i, 1);
          this.triggerRadioComm("HQ OVERWATCH", "💥 Red Zone zarbasi tugadi. Sektor xavfsiz!", 3.5);
        }
      }
    }

    renderRedZones() {
      const ctx = this.ctx;
      for (const rz of this.redZones) {
        ctx.save();
        const pulse = (Math.sin(performance.now() * 0.008) + 1) * 0.5;

        // Danger Circle
        ctx.fillStyle = `rgba(255, 23, 68, ${0.12 + pulse * 0.1})`;
        ctx.beginPath();
        ctx.arc(rz.x, rz.y, rz.radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = "#ff1744";
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 6]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Crosshairs
        ctx.strokeStyle = "rgba(255, 23, 68, 0.4)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(rz.x - rz.radius, rz.y); ctx.lineTo(rz.x + rz.radius, rz.y);
        ctx.moveTo(rz.x, rz.y - rz.radius); ctx.lineTo(rz.x, rz.y + rz.radius);
        ctx.stroke();

        // Warning Label
        ctx.fillStyle = "#ff1744";
        ctx.font = "bold 13px monospace";
        ctx.textAlign = "center";
        if (rz.warningTimer > 0) {
          ctx.fillText(`⚠️ RED ZONE: ${rz.warningTimer.toFixed(1)}s`, rz.x, rz.y - rz.radius - 8);
        } else {
          ctx.fillText("💥 ARTILLERIYA ZARBASI! 💥", rz.x, rz.y - rz.radius - 8);
        }

        // Falling artillery shells
        for (const sh of rz.shells) {
          ctx.fillStyle = "#ffd600";
          ctx.beginPath();
          ctx.arc(sh.x, sh.y, 4, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = "#ff3d00";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(sh.x - 18, sh.y - 18);
          ctx.lineTo(sh.x, sh.y);
          ctx.stroke();
        }
        ctx.restore();
      }
    }

    renderBarricades() {
      const ctx = this.ctx;
      for (const b of this.barricades) {
        ctx.save();
        ctx.translate(b.x, b.y);

        if (b.broken) {
          // Shattered Debris Rubble
          ctx.fillStyle = "#334155";
          ctx.fillRect(-18, -10, 36, 20);
          ctx.fillStyle = "#1e293b";
          ctx.beginPath();
          ctx.moveTo(-18, -10); ctx.lineTo(-6, -18); ctx.lineTo(8, -8); ctx.lineTo(18, -10);
          ctx.fill();

          ctx.strokeStyle = "#ff1744";
          ctx.lineWidth = 1.5;
          ctx.strokeRect(-18, -10, 36, 20);

          ctx.fillStyle = "#ff1744";
          ctx.font = "bold 9px monospace";
          ctx.textAlign = "center";
          ctx.fillText("BUZILGAN", 0, -2);
          ctx.fillStyle = "#ffd600";
          ctx.font = "bold 8px monospace";
          ctx.fillText("[QURISH 45g]", 0, 7);
        } else {
          // Reinforced Concrete Bunker Barricade
          ctx.fillStyle = "#1e293b";
          ctx.fillRect(-20, -14, 40, 28);

          // Yellow/Black Hazard Stripes
          ctx.fillStyle = "#eab308";
          ctx.fillRect(-18, -12, 36, 6);
          ctx.fillStyle = "#0f172a";
          for (let s = -18; s < 18; s += 8) {
            ctx.beginPath();
            ctx.moveTo(s, -12); ctx.lineTo(s + 4, -12); ctx.lineTo(s + 2, -6); ctx.lineTo(s - 2, -6);
            ctx.fill();
          }

          // Concrete Face
          ctx.fillStyle = "#475569";
          ctx.fillRect(-18, -5, 36, 17);

          // Structural Border
          ctx.strokeStyle = b.type === 'fortified' ? "#00e5ff" : "#94a3b8";
          ctx.lineWidth = 2;
          ctx.strokeRect(-20, -14, 40, 28);

          // Cracks when damaged
          const hpPct = b.hp / b.maxHp;
          if (hpPct < 0.75) {
            ctx.strokeStyle = "#0f172a";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(-10, 4); ctx.lineTo(-2, -2); ctx.lineTo(4, 3);
            ctx.stroke();
          }
          if (hpPct < 0.40) {
            ctx.strokeStyle = "#ff1744";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(6, -4); ctx.lineTo(12, 6);
            ctx.moveTo(-14, -2); ctx.lineTo(-8, 8);
            ctx.stroke();
          }

          // HP Bar
          ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
          ctx.fillRect(-18, -22, 36, 5);
          ctx.fillStyle = hpPct > 0.5 ? "#00e676" : (hpPct > 0.25 ? "#ffd600" : "#ff1744");
          ctx.fillRect(-18, -22, 36 * hpPct, 5);
          ctx.strokeStyle = "#000000";
          ctx.lineWidth = 0.5;
          ctx.strokeRect(-18, -22, 36, 5);

          // Label
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 8px monospace";
          ctx.textAlign = "center";
          ctx.fillText(`${Math.ceil(b.hp)}HP`, 0, 7);
        }
        ctx.restore();
      }
    }

    downloadApk() {
      if (typeof window !== 'undefined' && window.AndroidBridge) {
        if (this.addFloatingText) this.addFloatingText("Siz Android APK dasiz (v4.1.0)!", 640, 360, "#00e676", 18);
        return;
      }
      const a = document.createElement('a');
      a.href = 'TowerDefense_LastGrid_v4.1.0.apk';
      a.download = 'TowerDefense_LastGrid_v4.1.0.apk';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }

    downloadOfflineZip() {
      const a = document.createElement('a');
      a.href = 'last-grid-offline-v2.zip';
      a.download = 'last-grid-offline-v2.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }

    handleEditorClick(x, y) {
      if (y >= 10 && y <= 55) {
        // 1. Menu
        if (x >= 20 && x <= 115) { this.state = 'MENU'; if (this.apexSystem) this.apexSystem.show(); audio.playBGMTrack('menu'); return; }
        // 2. Test Play
        if (x >= 120 && x <= 245) { this.startMission(0, 'CUSTOM'); return; }
        // 3. Save
        if (x >= 250 && x <= 355) {
          localStorage.setItem('lg_custom_map', JSON.stringify({
            waypoints: this.editorWaypoints,
            biome: this.editorBiome || 'cyber',
            waves: this.editorWaves || 20,
            gold: this.editorGold || 350
          }));
          this.addFloatingText("💾 XARITA SAQLANDI!", 640, 200, "#ffd600", 24);
          audio.upgrade();
          return;
        }
        // 4. Clear
        if (x >= 360 && x <= 455) {
          this.editorWaypoints = [{ x: 64, y: 320 }];
          this.addFloatingText("XARITA TOZALANDI!", 640, 200, "#ff1744", 20);
          audio.sell();
          return;
        }
        // 5. Export
        if (x >= 460 && x <= 555) {
          prompt("Xarita JSON nusxasi:", JSON.stringify({
            waypoints: this.editorWaypoints,
            biome: this.editorBiome || 'cyber',
            waves: this.editorWaves || 20,
            gold: this.editorGold || 350
          }));
          return;
        }
        // 6. Import
        if (x >= 560 && x <= 655) {
          const input = prompt("Xarita JSON kodini kiriting:");
          if (input) {
            try {
              const parsed = JSON.parse(input);
              if (Array.isArray(parsed) && parsed.length >= 2) this.editorWaypoints = parsed;
              else if (parsed.waypoints && parsed.waypoints.length >= 2) {
                this.editorWaypoints = parsed.waypoints;
                if (parsed.biome) this.editorBiome = parsed.biome;
                if (parsed.waves) this.editorWaves = parsed.waves;
                if (parsed.gold) this.editorGold = parsed.gold;
              }
              this.addFloatingText("XARITA YUKLANDI!", 640, 200, "#00e676", 24);
              audio.upgrade();
            } catch(e) {}
          }
          return;
        }
        // 7. Biome Toggle
        if (x >= 660 && x <= 790) {
          const biomes = ['cyber', 'lava', 'cryo'];
          const curIdx = biomes.indexOf(this.editorBiome || 'cyber');
          this.editorBiome = biomes[(curIdx + 1) % biomes.length];
          audio.click();
          return;
        }
        // 8. Waves Toggle
        if (x >= 795 && x <= 905) {
          const waveOptions = [10, 15, 20, 25, 30];
          const wIdx = waveOptions.indexOf(this.editorWaves || 20);
          this.editorWaves = waveOptions[(wIdx + 1) % waveOptions.length];
          audio.click();
          return;
        }
        // 9. Gold Toggle
        if (x >= 910 && x <= 1020) {
          const goldOptions = [250, 350, 500, 1000];
          const gIdx = goldOptions.indexOf(this.editorGold || 350);
          this.editorGold = goldOptions[(gIdx + 1) % goldOptions.length];
          audio.click();
          return;
        }
        // 10. Undo
        if (x >= 1025 && x <= 1130) {
          if (this.editorWaypoints.length > 1) {
            this.editorWaypoints.pop();
            audio.sell();
          }
          return;
        }
      }
      if (y >= 65 && y <= 660) {
        const gx = Math.floor(x / 64) * 64 + 32;
        const gy = Math.floor(y / 64) * 64 + 32;
        const existingIdx = this.editorWaypoints.findIndex(pt => Math.hypot(pt.x - gx, pt.y - gy) < 32);
        if (existingIdx > 0 && this.editorWaypoints.length > 2) {
          this.editorWaypoints.splice(existingIdx, 1);
          audio.sell();
        } else {
          this.editorWaypoints.push({ x: gx, y: gy });
          audio.build();
        }
      }
    }

    // --- ROGUELIKE AUGMENT DRAFT ---
    triggerAugmentDraft() {
      this.state = 'DRAFT';
      const available = AUGMENT_POOL.filter(a => !this.activeAugments.includes(a.id));
      const shuffled = available.sort(() => 0.5 - Math.random());
      this.draftCards = shuffled.slice(0, 3);
      audio.upgrade();
    }

    selectAugment(card) {
      this.activeAugments.push(card.id);
      this.addFloatingText(`AUGMENT ACTIVATED: ${card.title}!`, 640, 200, card.color, 24);
      audio.victory();
      this.state = 'PLAYING';
      this.recalculateBeaconBuffs();
    }

    hasAugment(id) {
      return this.activeAugments.includes(id);
    }

    // --- FIELD HERO MECH ---
    triggerHeroUlt() {
      if (this.hero.currentUltCd > 0) {
        this.addFloatingText(`HERO ULT CHARGING (${Math.ceil(this.hero.currentUltCd)}s)`, this.hero.x, this.hero.y - 20, "#ff1744");
        return;
      }
      this.hero.currentUltCd = this.hero.ultCd;
      this.hero.ultActiveTime = 0.6;
      audio.heroSlash();
      this.screenShake = 9;
      this.spawnShockwave(this.hero.x, this.hero.y, 160, "#00e5ff");

      // 400 damage in 160px radius
      for (const e of this.enemies) {
        if (Math.hypot(e.x - this.hero.x, e.y - this.hero.y) <= 160) {
          this.applyDamage(e, 400, 'HERO');
        }
      }
      this.addFloatingText("CYBER-SLASH WAVE!", this.hero.x, this.hero.y - 28, "#00e5ff", 22);
    }

    toggleHeroTransform() {
      const h = this.hero;
      if (h.mode === 'BIPED') {
        h.mode = 'SIEGE';
        h.speed = 45;
        h.siegeCooldown = 0.5;
        h.siegeRecoil = 0;
        audio.mechTransform();
        this.screenShake = 6;
        this.spawnShockwave(h.x, h.y, 65, "#ffd600");
        this.addFloatingText("🚜 SIEGE TANK (+50% ZIRH • 120MM GAUBITSA)", h.x, h.y - 32, "#ffd600", 17);
        this.triggerRadioComm("APEX-01 AI", "TRANSFORMATSIYA: SIEGE TANK REJIMI FAOL! 120mm gaubitsa va og'ir zirh ishga tushdi!", 4.0);
        this.vibrate([40, 30, 80]);
      } else {
        h.mode = 'BIPED';
        h.speed = 130;
        audio.mechTransform();
        this.screenShake = 4;
        this.spawnShockwave(h.x, h.y, 50, "#00e5ff");
        this.addFloatingText("🤖 ROBOT REJIMI (130 TEZLIK • PLAZMA KATANA)", h.x, h.y - 32, "#00e5ff", 17);
        this.triggerRadioComm("APEX-01 AI", "TRANSFORMATSIYA: ASSAULT ROBOT REJIMI! Yuqori manyovr va katana faol!", 4.0);
        this.vibrate([30, 20, 60]);
      }
    }

    damageHero(rawDmg) {
      let dmg = rawDmg;
      if (this.hero.shieldDome && this.hero.shieldDome.hp > 0) {
        const absorb = Math.min(this.hero.shieldDome.hp, dmg);
        this.hero.shieldDome.hp -= absorb;
        dmg -= absorb;
        this.addFloatingText(`-${absorb} QALQON`, this.hero.x, this.hero.y - 22, "#00e5ff", 14);
        if (dmg <= 0) return;
      }
      if (this.hero.mode === 'SIEGE') {
        dmg *= 0.50; // +50% armor damage reduction in SIEGE mode!
      }
      this.hero.hp = Math.max(0, this.hero.hp - dmg);
      this.addFloatingText(`-${Math.round(dmg)} HP`, this.hero.x, this.hero.y - 15, "#ff1744", 15);
      if (this.hero.hp <= 0) {
        this.hero.hp = 1;
        this.addFloatingText("⚡ EMERGENCY SHIELD REBOOT!", this.hero.x, this.hero.y - 30, "#ffd600", 18);
        this.triggerRadioComm("APEX-01 AI", "OGOHLANTIRISH: Mech kritik shikastlandi! Favqulodda qayta yuklash faol!", 3.5);
      }
    }

    // --- COMMANDER SKILLS ---
    triggerSkill(skillKey) {
      const s = this.skills[skillKey];
      if (!s) return;
      if (s.currentCd > 0) return;
      if (this.gold < s.cost) {
        this.addFloatingText(this.t("notEnoughGold"), 640, 600, "#ff1744");
        return;
      }
      if (skillKey === 'overclock') {
        this.gold -= s.cost;
        s.currentCd = s.cd;
        s.activeTime = 8.0;
        audio.upgrade();
        this.screenShake = 4;
        this.analytics.damageByTower.skills += 50;
        this.addFloatingText("OVERCLOCK ACTIVE! (+80% ROF / 8s)", 640, 200, "#ffd600", 24);
      } else if (skillKey === 'shield') {
        this.gold -= s.cost;
        s.currentCd = s.cd;
        const shieldMaxHp = this.hasAugment("nanite_aegis") ? 1500 : 1000;
        this.hero.shieldDome = { active: true, radius: 170, maxHp: shieldMaxHp, hp: shieldMaxHp, duration: 10.0, timer: 10.0 };
        audio.shieldDome();
        this.screenShake = 5;
        this.spawnShockwave(this.hero.x, this.hero.y, 170, "#00e5ff");
        this.addFloatingText(`🛡️ SHIELD DOME FAOL (${shieldMaxHp} HP / 10s)!`, this.hero.x, this.hero.y - 30, "#00e5ff", 22);
        this.triggerRadioComm("HQ COMMANDER", "Qalqon gumbazi o'rnatildi! Barcha zarbalar yutiladi!", 3.5);
      } else if (skillKey === 'missiles') {
        this.gold -= s.cost;
        s.currentCd = s.cd;
        audio.missileLaunch();
        this.screenShake = 6;
        this.addFloatingText("🚀 MICRO-MISSILE SWARM (12 RAKETA)!", this.hero.x, this.hero.y - 30, "#ff9100", 22);
        this.triggerRadioComm("APEX-01 AI", "Mikro-raketalar yelka bo'lmasidan uchirildi! Nishonlar o'q ostida!", 3.5);
        for (let i = 0; i < 12; i++) {
          setTimeout(() => {
            if (this.state !== 'PLAYING') return;
            let target = null;
            if (this.enemies.length > 0) {
              const pool = this.enemies.filter(e => !e.phased);
              target = pool.length > 0 ? pool[Math.floor(Math.random() * pool.length)] : null;
            }
            const offsetAng = (i % 2 === 0 ? -1 : 1) * (0.3 + Math.random() * 0.5);
            const launchAng = (this.hero.angle || 0) + offsetAng;
            this.projectiles.push({
              type: 'missile',
              x: this.hero.x + Math.cos(launchAng) * 16,
              y: this.hero.y + Math.sin(launchAng) * 16,
              angle: launchAng,
              speed: 460,
              target: target,
              targetX: target ? target.x : this.hero.x + Math.cos(launchAng) * 280,
              targetY: target ? target.y : this.hero.y + Math.sin(launchAng) * 280,
              damage: 75,
              splash: 40,
              life: 3.2
            });
            audio.missileLaunch();
          }, i * 55);
        }
      } else if (skillKey === 'drone') {
        this.gold += 75;
        this.analytics.totalGold += 75;
        s.currentCd = s.cd;
        audio.sell();
        this.addFloatingText("+75 GOLD DELIVERED!", 640, 200, "#00e676", 24);
      } else {
        this.aimingSkill = skillKey;
      }
    }

    executeSkill(skillKey, x, y) {
      const s = this.skills[skillKey];
      if (this.gold < s.cost) return;
      this.gold -= s.cost;
      s.currentCd = s.cd;

      if (skillKey === 'emp') {
        audio.emp();
        this.screenShake = 10;
        this.spawnShockwave(x, y, 260, "#00e5ff");
        this.spawnShockwave(x, y, 160, "#ffffff");
        const stunDur = this.hasAugment("tesla_overcharge") ? 10.0 : 4.0;
        for (const e of this.enemies) {
          if (Math.hypot(e.x - x, e.y - y) <= 260) {
            e.slowRatio = 1.0;
            e.slowTimer = stunDur;
            e.shield = 0; // Destroy 100% of enemy shields!
            this.applyDamage(e, 120, 'SKILL');
            this.addFloatingText(this.hasAugment("tesla_overcharge") ? "⚡ TESLA OVERCHARGE STUN (10s)!" : "⚡ EMP STUN + SHIELD SHATTER!", e.x, e.y - 14, "#00e5ff", 14);
          }
        }
      } else if (skillKey === 'orbital') {
        audio.orbital();
        this.screenShake = 14;
        this.particles.push({ x: x, y: y, beam: true, life: 0.5, maxLife: 0.5 });
        this.spawnShockwave(x, y, 140, "#ff007f");
        for (const e of this.enemies) {
          if (Math.hypot(e.x - x, e.y - y) <= 140) {
            this.applyDamage(e, 500, 'SKILL');
          }
        }
      }
    }

    selectBuildType(type) {
      if (this.selectedBuildType === type) this.selectedBuildType = null;
      else {
        this.selectedBuildType = type;
        this.selectedTower = null;
        this.aimingSkill = null;
      }
    }

    buildTower(type, gx, gy) {
      const def = TOWER_DEFS[type];
      if (this.gold < def.cost) {
        this.addFloatingText(this.t("notEnoughGold"), gx * 64 + 32, gy * 64, "#ff1744");
        return;
      }
      this.gold -= def.cost;
      const tower = {
        uid: this.nextUid++,
        type: type,
        cellX: gx, cellY: gy,
        x: gx * 64 + 32, y: gy * 64 + 32,
        tier: 1,
        branch: null,
        totalInvested: def.cost,
        cooldown: 0,
        angle: 0,
        kills: 0,
        damageDealt: 0,
        priority: 'FIRST',
        laserTimer: 0,
        targetPoint: null,
        recoil: 0,
        barrelSpin: 0,
        heat: 0
      };
      this.towers.push(tower);
      audio.upgrade();
      this.addFloatingText(`-${def.cost}g`, tower.x, tower.y, "#ffd600");
      this.selectedTower = tower;
      this.selectedBuildType = null;
      this.recalculateBeaconBuffs();
    }

    upgradeSelectedTower() {
      if (!this.selectedTower) return;
      const t = this.selectedTower;
      const def = TOWER_DEFS[t.type];
      if (t.tier >= 3) return;
      const cost = def.tiers[t.tier - 1].upCost;
      if (this.gold < cost) {
        this.addFloatingText(this.t("notEnoughGold"), t.x, t.y, "#ff1744");
        return;
      }
      this.gold -= cost;
      t.totalInvested += cost;
      t.tier++;
      audio.upgrade();
      this.addFloatingText(`TIER ${t.tier}!`, t.x, t.y, "#00e5ff");
      this.recalculateBeaconBuffs();
    }

    upgradeBranch(branchKey) {
      if (!this.selectedTower) return;
      const t = this.selectedTower;
      const def = TOWER_DEFS[t.type];
      const branch = def.branches[branchKey];
      if (this.gold < branch.cost) {
        this.addFloatingText(this.t("notEnoughGold"), t.x, t.y, "#ff1744");
        return;
      }
      this.gold -= branch.cost;
      t.totalInvested += branch.cost;
      t.tier = 3;
      t.branch = branchKey;
      audio.victory();
      this.spawnShockwave(t.x, t.y, 80, branch.color);
      this.addFloatingText(`${branch.name.toUpperCase()}!`, t.x, t.y, branch.color, 16);
      this.recalculateBeaconBuffs();
    }

    sellSelectedTower() {
      if (!this.selectedTower) return;
      const t = this.selectedTower;
      const refund = Math.floor(t.totalInvested * 0.70);
      this.gold += refund;
      this.analytics.totalGold += refund;
      this.towers = this.towers.filter(item => item !== t);
      audio.sell();
      this.addFloatingText(`+${refund}g (70%)`, t.x, t.y, "#00e676");
      this.selectedTower = null;
      this.recalculateBeaconBuffs();
    }

    cycleTargetPriority() {
      if (!this.selectedTower) return;
      const idx = this.targetPriorities.indexOf(this.selectedTower.priority);
      this.selectedTower.priority = this.targetPriorities[(idx + 1) % this.targetPriorities.length];
      this.addFloatingText(this.selectedTower.priority, this.selectedTower.x, this.selectedTower.y - 20, "#00e5ff");
    }

    cycleSpeed() {
      this.speed = this.speed === 1 ? 2 : (this.speed === 2 ? 3 : 1);
    }

    togglePause() {
      if (this.state === 'PLAYING') this.state = 'PAUSED';
      else if (this.state === 'PAUSED') this.state = 'PLAYING';
    }

    recalculateBeaconBuffs() {
      const globalRof = this.hasAugment("overclock_matrix") ? 1.20 : 1.0;
      for (const t of this.towers) {
        t.buffDmg = 1.0;
        t.buffRange = 1.0;
        t.buffRate = globalRof;
      }
      for (const b of this.towers) {
        if (b.type !== 'beacon') continue;
        const bDef = (b.branch) ? TOWER_DEFS.beacon.branches[b.branch] : TOWER_DEFS.beacon.tiers[b.tier - 1];
        for (const t of this.towers) {
          if (t === b) continue;
          const dist = Math.hypot(t.x - b.x, t.y - b.y);
          if (dist <= bDef.range) {
            t.buffDmg = Math.max(t.buffDmg, 1.0 + bDef.dmgBuff);
            t.buffRange = Math.max(t.buffRange, 1.0 + bDef.rangeBuff);
            if (bDef.rateBuff) t.buffRate = Math.max(t.buffRate, (globalRof + bDef.rateBuff));
          }
        }
      }
    }

    callNextWave() {
      if (this.waveActive) {
        if (this.waveCountdown > 0) {
          const bonus = Math.floor(this.waveCountdown);
          this.gold += bonus;
          this.analytics.totalGold += bonus;
          this.score += bonus * 10;
          this.addFloatingText(`EARLY +${bonus}g!`, 640, 100, "#ffd600");
          this.waveCountdown = 0;
        }
        return;
      }
      this.startWave(this.wave);
    }

    startWave(waveNum) {
      this.wave = waveNum;
      this.waveActive = true;
      this.waveCountdown = 0;
      const groups = getWaveConfig(waveNum, this.gameMode);
      this.spawnQueue = [];
      let delay = 0;
      for (const g of groups) {
        for (let i = 0; i < g.count; i++) {
          this.spawnQueue.push({
            type: g.type,
            time: delay,
            laneIdx: Math.floor(Math.random() * this.bakedLanes.length)
          });
          delay += g.interval;
        }
      }
      this.spawnTimer = 0;
      this.addFloatingText(`${this.t("wave")} ${waveNum}!`, 640, 150, "#00e5ff", 28);

      // Trigger Cinematic Wave Alert Banner
      const bossGroup = groups.find(g => ENEMY_DEFS[g.type] && ENEMY_DEFS[g.type].isBoss);
      const isBoss = !!bossGroup;
      const bossDef = isBoss ? ENEMY_DEFS[bossGroup.type] : null;
      const title = isBoss ? `⚠ BOSS DETECTED — WAVE ${waveNum}!` : `WAVE ${waveNum} INBOUND`;
      const subtitle = isBoss ?
        `${bossDef.name.toUpperCase()} (HP: ${bossDef.hp}) — HEAVY TITAN CLASS` :
        `HOSTILE SWARM APPROACHING GRID DEFENSE PERIMETER`;

      this.cinematicBanner = {
        title: title,
        subtitle: subtitle,
        isBoss: isBoss,
        duration: 3.2,
        timer: 3.2,
        color: isBoss ? "#ff1744" : "#00e5ff"
      };

      if (isBoss) {
        audio.emergencySiren();
        this.screenShake = 12;
      } else {
        audio.waveClear();
      }
    }

    spawnEnemy(type, laneIdx) {
      const def = ENEMY_DEFS[type] || ENEMY_DEFS['grunt'];
      const map = (this.gameMode === 'CUSTOM') ? { modifier: "none" } : MAPS[this.currentMapIndex];
      let spdMult = 1.0;
      let armorMult = 1.0;
      let hpMult = 1.0;

      // Difficulty scaling
      if (this.difficulty === 'CASUAL') hpMult *= 0.80;
      else if (this.difficulty === 'HEROIC') hpMult *= 1.30;

      if (this.hasAugment("bounty_hunter")) spdMult *= 1.10;
      if (this.gameMode === 'ENDLESS' && this.wave > 20) {
        // Soft curve after wave 20
        hpMult *= Math.pow(1.12, 19) * Math.pow(1.05, this.wave - 20);
      } else if (this.gameMode === 'CAMPAIGN' && this.wave > 1) {
        hpMult *= Math.pow(1.12, this.wave - 1);
      }

      if (map.modifier === 'fast_lane') spdMult = 1.15;
      if (map.modifier === 'armored') armorMult = 1.20;

      let bounty = Math.round((def.bounty || 4) + 0.6 * this.wave);
      if (map.modifier === 'scarce') bounty = Math.floor(bounty * 0.8);
      if (this.hasAugment("bounty_hunter")) bounty = Math.floor(bounty * 1.30);

      if (def.isBoss) {
        this.triggerRadioComm("HQ OVERWATCH", `☠️ DIQQAT: ${def.name.toUpperCase()} JANG MAYDONIGA KIRDI! Barcha olovni jamlang!`, 5.0);
        this.screenShake = 20;
        audio.bossSiren();
        audio.playBGMTrack('boss');
        audio.playSample('hq_boss', 0.85);
        this.vibrate([150, 80, 150, 80, 350]);
        this.bossAlert = {
          name: def.name.toUpperCase(),
          hp: Math.round(def.hp * hpMult),
          armor: Math.round(def.armor * armorMult),
          marker: def.marker || "☠",
          color: def.color || "#ff1744",
          timer: 4.8,
          maxTimer: 4.8,
          desc: (type === 'juggernaut') ? "OG'IR ZIRHLI TANK • 50% HP ENRAGE REJIMI" :
                (type === 'overseer') ? "ENERGIYA QALQONI GENERATORI • DRON SUMMONER" :
                "BIO-MEXANIK TITAN • 3 FAZALI APOLISIS GIGANTI"
        };
      }

      const enemy = {
        uid: this.nextUid++,
        type: type,
        laneIdx: laneIdx,
        progress: 0,
        hp: def.hp * hpMult,
        maxHp: def.hp * hpMult,
        shield: def.shield * hpMult,
        maxShield: def.shield * hpMult,
        armor: def.armor * armorMult,
        speed: def.spd * spdMult,
        bounty: bounty,
        size: def.size,
        color: def.color,
        marker: def.marker,
        isBoss: !!def.isBoss,
        isFlyer: !!def.isFlyer,
        slowRatio: 0,
        slowTimer: 0,
        phaseTimer: 0,
        phased: false,
        healTimer: 0,
        shieldRegenTimer: 0,
        x: 0, y: 0, angle: 0
      };
      const pos = this.getPointAlongLane(laneIdx, 0);
      enemy.x = pos.x;
      enemy.y = pos.y;
      this.enemies.push(enemy);
    }

    startLoop() {
      const step = (timestamp) => {
        if (!this.lastTimestamp) this.lastTimestamp = timestamp;
        const dt = Math.min(0.1, (timestamp - this.lastTimestamp) / 1000.0);
        this.lastTimestamp = timestamp;
        this.uiTime = (this.uiTime || 0) + dt;

        // Animate Button Click Ripples
        if (this.buttonRipples && this.buttonRipples.length > 0) {
          for (let i = this.buttonRipples.length - 1; i >= 0; i--) {
            const rip = this.buttonRipples[i];
            rip.r += dt * 85;
            rip.alpha -= dt * 2.2;
            if (rip.alpha <= 0 || rip.r >= rip.maxR) this.buttonRipples.splice(i, 1);
          }
        }

        if (this.state === 'PLAYING') {
          for (let i = 0; i < this.speed; i++) this.update(dt);
        } else if (this.state === 'TPS_3D') {
          this.update3DTPS(dt);
        }
        this.render();
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }

    update(dt) {
      if (this.screenShake > 0) this.screenShake = Math.max(0, this.screenShake - 20 * dt);

      if (this.cinematicBanner && this.cinematicBanner.timer > 0) {
        this.cinematicBanner.timer = Math.max(0, this.cinematicBanner.timer - dt);
      }

      if (this.bossAlert && this.bossAlert.timer > 0) {
        this.bossAlert.timer = Math.max(0, this.bossAlert.timer - dt);
      }
      this.updateBiomeParticles(dt);

      // Flying Gold Coins Update
      for (let i = this.flyingCoins.length - 1; i >= 0; i--) {
        const c = this.flyingCoins[i];
        c.progress += dt * c.speed;
        if (c.progress >= 1.0) {
          this.flyingCoins.splice(i, 1);
        } else {
          // Quadratic bezier trajectory towards top gold counter (180, 30)
          const t = c.progress;
          const ctrlX = (c.startX + c.targetX) / 2 + c.curveOffset;
          const ctrlY = Math.min(c.startY, c.targetY) - 60;
          c.x = (1 - t) * (1 - t) * c.startX + 2 * (1 - t) * t * ctrlX + t * t * c.targetX;
          c.y = (1 - t) * (1 - t) * c.startY + 2 * (1 - t) * t * ctrlY + t * t * c.targetY;
        }
      }

      // Upgrade Light Pillars Update
      for (let i = this.upgradePillars.length - 1; i >= 0; i--) {
        const p = this.upgradePillars[i];
        p.timer -= dt;
        if (p.timer <= 0) this.upgradePillars.splice(i, 1);
      }

      // Radio Comms & Battlefield Events
      this.updateRadioComms(dt);
      this.updateAirdrops(dt);
      this.updateRedZones(dt);

      if (this.waveActive) {
        this.airdropCooldown -= dt;
        if (this.airdropCooldown <= 0) {
          this.airdropCooldown = 45.0 + Math.random() * 25.0;
          this.spawnAirdrop();
        }

        if (this.wave >= 2) {
          this.redZoneCooldown -= dt;
          if (this.redZoneCooldown <= 0) {
            this.redZoneCooldown = 50.0 + Math.random() * 25.0;
            this.triggerRedZone();
          }
        }
      }

      const skillCdMult = this.hasAugment("chronos_overdrive") ? 1.35 : 1.0;
      for (const k in this.skills) {
        if (this.skills[k].currentCd > 0) this.skills[k].currentCd = Math.max(0, this.skills[k].currentCd - dt * skillCdMult);
      }
      if (this.skills.overclock.activeTime > 0) {
        this.skills.overclock.activeTime = Math.max(0, this.skills.overclock.activeTime - dt);
      }

      // Hero Mech Update
      this.updateHero(dt);

      // Ground Hazards (Napalm Cyber-Fire)
      for (let i = this.groundHazards.length - 1; i >= 0; i--) {
        const h = this.groundHazards[i];
        h.life -= dt;
        h.tickTimer += dt;
        if (h.tickTimer >= 0.5) {
          h.tickTimer = 0;
          for (const e of this.enemies) {
            if (Math.hypot(e.x - h.x, e.y - h.y) <= h.radius) {
              this.applyDamage(e, 20, 'EXPLOSIVE', null, 'mortar');
            }
          }
        }
        if (h.life <= 0) this.groundHazards.splice(i, 1);
      }

      // 1. Spawning
      if (this.waveActive) {
        this.spawnTimer += dt;
        while (this.spawnQueue.length > 0 && this.spawnTimer >= this.spawnQueue[0].time) {
          const item = this.spawnQueue.shift();
          this.spawnEnemy(item.type, item.laneIdx);
        }
        if (this.spawnQueue.length === 0 && this.enemies.length === 0) {
          this.onWaveCleared();
        }
      } else {
        this.waveCountdown -= dt;
        if (this.waveCountdown <= 0) this.startWave(this.wave);
      }

      // 2. Enemies Update
      const map = (this.gameMode === 'CUSTOM') ? { modifier: "none" } : MAPS[this.currentMapIndex];
      for (let i = this.enemies.length - 1; i >= 0; i--) {
        const e = this.enemies[i];
        if (e.slowTimer > 0) {
          e.slowTimer -= dt;
          if (e.slowTimer <= 0) e.slowRatio = 0;
        }
        if (e.type === 'phantom') {
          // Radar beacon permanently reveals phantoms
          const hasRadar = this.towers.some(t => t.branch === 'B' && t.type === 'beacon');
          if (!hasRadar) {
            e.phaseTimer += dt;
            if (e.phaseTimer >= 4.0) {
              e.phased = true;
              if (e.phaseTimer >= 5.5) { e.phased = false; e.phaseTimer = 0; }
            }
          } else {
            e.phased = false;
          }
        }
        if (e.type === 'medic') {
          e.healTimer += dt;
          if (e.healTimer >= 1.0) {
            e.healTimer = 0;
            for (const other of this.enemies) {
              if (other !== e && Math.hypot(other.x - e.x, other.y - e.y) <= 96) {
                other.hp = Math.min(other.maxHp, other.hp + 15);
                this.addFloatingText("+15", other.x, other.y - 10, "#00e676", 11);
              }
            }
          }
        }
        if (e.type === 'shieldbearer' && e.shield < e.maxShield) {
          e.shieldRegenTimer += dt;
          if (e.shieldRegenTimer > 3.0) e.shield = Math.min(e.maxShield, e.shield + 20 * dt);
        }

        // Advanced Boss AI Behavior Modeling
        if (e.isBoss) {
          e.abilityTimer = (e.abilityTimer || 0) + dt;

          // 1. Juggernaut Enrage (Phase 2 at 50% HP)
          if (e.type === 'juggernaut' && !e.enraged && e.hp <= e.maxHp * 0.5) {
            e.enraged = true;
            e.speed *= 1.35;
            this.screenShake = 18;
            this.addFloatingText("☠️ JUGGERNAUT ENRAGED!", e.x, e.y - 35, "#ff1744", 24);
            this.triggerRadioComm("HQ OVERWATCH", "⚠️ DIQQAT: Juggernaut 50% HP! Enrage rejimi: tezlik va zarba oshdi!", 4.0);
            this.spawnShockwave(e.x, e.y, 90, "#ff1744");
            if (audio) audio.artilleryBlast();
          }

          // 2. Overseer Energy Shield Pulse (Every 6.5s)
          if (e.type === 'overseer' && e.abilityTimer >= 6.5) {
            e.abilityTimer = 0;
            this.spawnShockwave(e.x, e.y, 140, "#651fff");
            this.addFloatingText("🛡️ SHIELD PULSE AURA!", e.x, e.y - 32, "#00b0ff", 18);
            if (audio) audio.shootCryo();
            for (const other of this.enemies) {
              if (Math.hypot(other.x - e.x, other.y - e.y) <= 140) {
                other.shield = Math.min(other.maxShield || 150, (other.shield || 0) + 75);
                other.maxShield = Math.max(other.maxShield || 0, other.shield);
              }
            }
          }

          // 3. Hive Titan Swarm Deployment (Every 5.5s)
          if (e.type === 'hive_titan' && e.abilityTimer >= 5.5) {
            e.abilityTimer = 0;
            this.spawnShockwave(e.x, e.y, 80, "#f50057");
            this.addFloatingText("☣️ SWARM DEPLOYED!", e.x, e.y - 35, "#ffab00", 18);
            for (let k = -1; k <= 1; k += 2) {
              this.enemies.push({
                uid: this.nextUid++,
                type: 'swarmling',
                laneIdx: e.laneIdx,
                progress: Math.max(0, e.progress + k * 18),
                hp: 35, maxHp: 35, shield: 0, maxShield: 0, armor: 0,
                speed: 95, bounty: 2, size: 7, color: '#ffab00', marker: '◆', isBoss: false,
                slowRatio: 0, slowTimer: 0, x: e.x, y: e.y, angle: e.angle
              });
            }
          }

          // 4. Void Titan Gravity Well (Every 4.5s)
          if (e.type === 'void_titan' && e.abilityTimer >= 4.5) {
            e.abilityTimer = 0;
            this.spawnShockwave(e.x, e.y, 160, "#9c27b0");
            this.addFloatingText("🌌 VOID GRAVITY VORTEX!", e.x, e.y - 36, "#ba68c8", 20);
            if (audio) audio.zap();
            // Pull hero and nearby barricades
            if (this.hero) {
              const dHero = Math.hypot(this.hero.x - e.x, this.hero.y - e.y);
              if (dHero <= 200) {
                const pullAngle = Math.atan2(e.y - this.hero.y, e.x - this.hero.x);
                this.hero.x += Math.cos(pullAngle) * 35;
                this.hero.y += Math.sin(pullAngle) * 35;
                this.damageHero(25);
              }
            }
          }

          // 5. Chrono Phantom Temporal Warp (Every 3.8s)
          if (e.type === 'chrono_phantom' && e.abilityTimer >= 3.8) {
            e.abilityTimer = 0;
            e.progress += 30; // Temporal time leap forward!
            this.spawnShockwave(e.x, e.y, 130, "#00e5ff");
            this.addFloatingText("⌛ TIME DILATION WARP!", e.x, e.y - 34, "#00e5ff", 20);
            if (audio) audio.teleport();
            // Disrupt nearby towers attack cooldowns
            for (const tw of this.towers) {
              if (Math.hypot(tw.x - e.x, tw.y - e.y) <= 160) {
                tw.cooldown = Math.max(tw.cooldown, 2.2);
              }
            }
          }

          // 6. Mecha Colossus Missile Barrage (Every 5.0s)
          if (e.type === 'mecha_colossus' && e.abilityTimer >= 5.0) {
            e.abilityTimer = 0;
            this.screenShake = 14;
            this.addFloatingText("🤖 COLOSSUS MISSILE SALVO!", e.x, e.y - 38, "#ffd600", 22);
            if (audio) audio.missileLaunch();
            for (let m = 0; m < 2; m++) {
              const targetObj = this.hero || (this.barricades && this.barricades[0]) || { x: e.x + 80, y: e.y };
              this.projectiles.push({
                type: 'missile',
                x: e.x + (m === 0 ? -15 : 15),
                y: e.y,
                vx: (Math.random() - 0.5) * 60,
                vy: (Math.random() - 0.5) * 60,
                damage: 75,
                radius: 40,
                target: targetObj,
                color: "#ffd600",
                homing: true,
                isEnemyProj: true
              });
            }
          }
        }

        // Burning Flame DoT
        if (e.burnTimer > 0) {
          e.burnTimer -= dt;
          e.burnTick = (e.burnTick || 0) + dt;
          if (e.burnTick >= 0.4) {
            e.burnTick = 0;
            const dotMult = this.activeAugments.includes('plasma_inferno') ? 1.45 : 1.0;
            this.applyDamage(e, (e.burnDmg || 25) * 0.4 * dotMult, 'FIRE', null, 'flame');
            if (this.activeAugments.includes('plasma_inferno')) {
              // Spread flame to nearby enemies
              for (const other of this.enemies) {
                if (other !== e && Math.hypot(other.x - e.x, other.y - e.y) <= 65) {
                  other.burnTimer = Math.max(other.burnTimer || 0, 2.5);
                  other.burnDmg = Math.max(other.burnDmg || 0, 30);
                }
              }
            }
            this.particles.push({
              x: e.x + (Math.random() * 12 - 6),
              y: e.y + (Math.random() * 12 - 6),
              vx: (Math.random() - 0.5) * 15,
              vy: -25 - Math.random() * 20,
              color: "#ff3d00", size: 2.5, growth: 2, life: 0.3, maxLife: 0.3
            });
          }
        }

        // Kamikaze Drone Suicide Detonation
        if (e.isKamikaze) {
          e.beepTimer = (e.beepTimer || 0) + dt;
          if (e.beepTimer >= 0.5) {
            e.beepTimer = 0;
            audio.kamikazeBeep();
          }
          const distToHero = Math.hypot(e.x - this.hero.x, e.y - this.hero.y);
          if (distToHero <= 40) {
            this.screenShake = 9;
            this.spawnShockwave(e.x, e.y, 70, "#ff1744");
            this.spawnScorchMark(e.x, e.y, 45);
            audio.artilleryBlast();
            this.damageHero(120);
            this.enemies.splice(i, 1);
            continue;
          }
        }

        // Siege Breaker Ground Stomp
        if (e.isSiegeBreaker) {
          e.stompTimer = (e.stompTimer || 0) + dt;
          if (e.stompTimer >= 5.5) {
            e.stompTimer = 0;
            this.screenShake = 12;
            audio.artilleryBlast();
            this.spawnShockwave(e.x, e.y, 160, "#7c4dff");
            this.spawnScorchMark(e.x, e.y, 60);
            this.addFloatingText("🗿 GROUND STOMP!", e.x, e.y - 35, "#7c4dff", 18);
            for (const t of this.towers) {
              if (Math.hypot(t.x - e.x, t.y - e.y) <= 170) {
                t.cooldown = Math.max(t.cooldown || 0, 1.8);
                this.addFloatingText("DISRUPTED!", t.x, t.y - 18, "#ffd600", 12);
              }
            }
            if (Math.hypot(this.hero.x - e.x, this.hero.y - e.y) <= 170) {
              this.damageHero(40);
            }
          }
        }

        const effSpeed = e.speed * (1.0 - Math.min(e.isBoss ? 0.5 : 1.0, e.slowRatio));

        // Battlefield Destructible Barricade blocking & attack
        let isBlocked = false;
        if (this.barricades && this.barricades.length > 0) {
          for (const b of this.barricades) {
            if (!b.broken && Math.hypot(e.x - b.x, e.y - b.y) <= 32) {
              isBlocked = true;
              e.attackTimer = (e.attackTimer || 0) + dt;
              if (e.attackTimer >= 0.7) {
                e.attackTimer = 0;
                const bDmg = e.isBoss ? 55 : (e.type === 'brute' ? 32 : (e.type === 'shieldbearer' ? 22 : 12));
                b.hp = Math.max(0, b.hp - bDmg);
                this.addFloatingText(`-${bDmg}`, b.x + (Math.random() * 16 - 8), b.y - 12, "#ff5252", 12);
                audio.barricadeHit();
                this.particles.push({
                  x: b.x + (Math.random() * 20 - 10),
                  y: b.y + (Math.random() * 20 - 10),
                  vx: (Math.random() * 40 - 20),
                  vy: (Math.random() * 40 - 20),
                  color: "#94a3b8", size: 3, life: 0.35, maxLife: 0.35
                });
                if (b.hp <= 0) {
                  b.broken = true;
                  this.screenShake = 12;
                  audio.barricadeBreak();
                  for (let k = 0; k < 12; k++) {
                    this.particles.push({
                      x: b.x, y: b.y,
                      vx: (Math.random() * 120 - 60),
                      vy: (Math.random() * 120 - 60),
                      color: "#64748b", size: 4 + Math.random() * 4, life: 0.7, maxLife: 0.7
                    });
                  }
                  this.addFloatingText("💥 TO'SIQ BUZILDI!", b.x, b.y - 25, "#ff1744", 18);
                  this.triggerRadioComm("HQ OVERWATCH", "⚠️ DIQQAT: Himoya to'sig'i dushmanlar tomonidan buzib tashlandi!", 4.5);
                }
              }
              break;
            }
          }
        }

        const lane = this.bakedLanes[e.laneIdx] || this.bakedLanes[0];
        if (e.isFlyer) {
          // Aerial drone bypasses barricades and flies straight to Core
          const endPt = lane.points[lane.points.length - 1];
          const fdx = endPt.x - e.x;
          const fdy = endPt.y - e.y;
          const fdist = Math.hypot(fdx, fdy);
          e.angle = Math.atan2(fdy, fdx);
          e.progress += effSpeed * dt;
          if (fdist > 8) {
            e.x += Math.cos(e.angle) * effSpeed * dt;
            e.y += Math.sin(e.angle) * effSpeed * dt;
          }
          if (Math.random() < 0.25) {
            this.particles.push({
              x: e.x - Math.cos(e.angle) * 12,
              y: e.y - Math.sin(e.angle) * 12,
              vx: -Math.cos(e.angle) * 40 + (Math.random() * 20 - 10),
              vy: -Math.sin(e.angle) * 40 + (Math.random() * 20 - 10),
              color: "#00e5ff", size: 2.5, life: 0.25, maxLife: 0.25
            });
          }
        } else {
          if (!isBlocked) {
            e.progress += effSpeed * dt;
          }
          e.walkAnim = (e.walkAnim || 0) + effSpeed * dt * 0.15;
          const pt = this.getPointAlongLane(e.laneIdx, e.progress);
          e.x = pt.x;
          e.y = pt.y;
          e.angle = pt.angle;
        }

        if (e.progress >= lane.totalLength) {
          this.baseHp = Math.max(0, this.baseHp - (e.isBoss ? 10 : 1));
          audio.leak();
          this.screenShake = 10;
          this.vibrate([80, 40, 80]);
          this.addFloatingText(e.isBoss ? "-10 HP!" : "-1 HP!", e.x, e.y, "#ff1744", 20);

          // Reactive Core augment perk
          if (this.hasAugment("reactive_core")) {
            this.spawnShockwave(e.x, e.y, 250, "#ff007f");
            for (const other of this.enemies) {
              other.slowRatio = 1.0;
              other.slowTimer = 3.0;
            }
          }

          this.enemies.splice(i, 1);
          if (this.baseHp <= 0) {
            this.onDefeat();
            return;
          }
        }
      }

      // 3. Towers Combat
      const overclockMult = (this.skills.overclock.activeTime > 0) ? 1.6 : 1.0;
      for (const t of this.towers) {
        if (t.type === 'beacon') continue;
        const def = TOWER_DEFS[t.type];
        const currentSpec = t.branch ? def.branches[t.branch] : def.tiers[t.tier - 1];
        const mapFog = (map.modifier === 'fog') ? 0.85 : 1.0;
        const effRange = currentSpec.range * (t.buffRange || 1.0) * mapFog;
        const effRate = currentSpec.rate * (t.buffRate || 1.0) * overclockMult;
        const effDmg = currentSpec.dmg * (t.buffDmg || 1.0);

        t.cooldown -= dt;
        if (t.laserTimer > 0) t.laserTimer -= dt;
        if (t.lightningArcs) {
          t.lightningArcs.time -= dt;
          if (t.lightningArcs.time <= 0) t.lightningArcs = null;
        }
        if (t.recoil > 0) t.recoil = Math.max(0, t.recoil - dt * 6.5);
        if (t.heat > 0) t.heat = Math.max(0, t.heat - dt * 0.7);
        if (t.branch === 'A' && t.type === 'pulse') t.barrelSpin = (t.barrelSpin || 0) + dt * 14;

        const targets = this.findTargets(t, effRange);
        if (targets.length > 0) {
          const primary = targets[0];
          t.angle = Math.atan2(primary.y - t.y, primary.x - t.x);
          if (t.cooldown <= 0) {
            t.cooldown = 1.0 / effRate;
            this.fireTower(t, targets, effDmg, currentSpec, effRange);
          }
        }
      }

      // 4. Projectiles
      for (let i = this.projectiles.length - 1; i >= 0; i--) {
        const p = this.projectiles[i];
        if (p.type === 'pulse') {
          if (p.target && this.enemies.includes(p.target)) {
            const angle = Math.atan2(p.target.y - p.y, p.target.x - p.x);
            p.x += Math.cos(angle) * p.speed * dt;
            p.y += Math.sin(angle) * p.speed * dt;
            if (Math.hypot(p.target.x - p.x, p.target.y - p.y) < 14) {
              this.applyDamage(p.target, p.damage, 'KINETIC', p.tower, 'pulse');
              this.projectiles.splice(i, 1);
            }
          } else {
            this.projectiles.splice(i, 1);
          }
        } else if (p.type === 'mortar') {
          p.t += dt / p.flightTime;
          p.x = p.startX + (p.targetX - p.startX) * p.t;
          p.y = p.startY + (p.targetY - p.startY) * p.t - Math.sin(p.t * Math.PI) * 90;
          if (p.t >= 1.0) {
            this.detonateMortar(p.targetX, p.targetY, p.damage, p.splash, p.tower, p.branch);
            this.projectiles.splice(i, 1);
          }
        } else if (p.type === 'siege_shell') {
          p.t += dt / p.flightTime;
          p.x = p.startX + (p.targetX - p.startX) * p.t;
          p.y = p.startY + (p.targetY - p.startY) * p.t - Math.sin(p.t * Math.PI) * 45;
          if (p.t >= 1.0) {
            this.screenShake = 6;
            audio.artilleryBlast();
            const splashRad = p.splash * (this.hasAugment("siege_artillery_core") ? 1.6 : 1.0);
            this.spawnShockwave(p.targetX, p.targetY, splashRad, "#ffd600");
            this.spawnScorchMark(p.targetX, p.targetY, splashRad * 0.7);
            if (this.hasAugment("siege_artillery_core")) {
              this.groundHazards.push({ x: p.targetX, y: p.targetY, radius: splashRad * 0.65, life: 4.0, tickTimer: 0 });
            }
            for (const e of this.enemies) {
              const d = Math.hypot(e.x - p.targetX, e.y - p.targetY);
              if (d <= splashRad) {
                const falloff = 1.0 - (d / splashRad) * 0.4;
                this.applyDamage(e, p.damage * falloff, 'EXPLOSIVE', null, 'hero');
              }
            }
            this.projectiles.splice(i, 1);
          }
        } else if (p.type === 'missile') {
          p.life -= dt;
          if (p.target && this.enemies.includes(p.target)) {
            p.targetX = p.target.x;
            p.targetY = p.target.y;
          }
          const dx = p.targetX - p.x;
          const dy = p.targetY - p.y;
          const dist = Math.hypot(dx, dy);
          const desAng = Math.atan2(dy, dx);
          p.angle = p.angle || desAng;
          let angDiff = desAng - p.angle;
          while (angDiff < -Math.PI) angDiff += Math.PI * 2;
          while (angDiff > Math.PI) angDiff -= Math.PI * 2;
          p.angle += Math.sign(angDiff) * Math.min(Math.abs(angDiff), dt * 10);
          p.x += Math.cos(p.angle) * p.speed * dt;
          p.y += Math.sin(p.angle) * p.speed * dt;

          if (Math.random() < 0.45) {
            this.particles.push({
              x: p.x - Math.cos(p.angle) * 8,
              y: p.y - Math.sin(p.angle) * 8,
              vx: (Math.random() - 0.5) * 15,
              vy: (Math.random() - 0.5) * 15,
              color: "rgba(220, 220, 220, 0.55)", size: 3, growth: 5, life: 0.35, maxLife: 0.35
            });
          }

          if (dist < 16 || p.life <= 0) {
            this.spawnShockwave(p.x, p.y, p.splash, "#ff9100");
            audio.hit();
            for (const e of this.enemies) {
              if (Math.hypot(e.x - p.x, e.y - p.y) <= p.splash) {
                this.applyDamage(e, p.damage, 'EXPLOSIVE', null, 'skills');
              }
            }
            this.projectiles.splice(i, 1);
          }
        }
      }

      for (let i = this.particles.length - 1; i >= 0; i--) {
        const pt = this.particles[i];
        if (!pt.beam) {
          pt.x += pt.vx * dt;
          pt.y += pt.vy * dt;
          if (pt.growth) pt.size += pt.growth * dt;
        }
        pt.life -= dt;
        if (pt.life <= 0) this.particles.splice(i, 1);
      }
      for (let i = this.casings.length - 1; i >= 0; i--) {
        const c = this.casings[i];
        c.x += c.vx * dt;
        c.y += c.vy * dt;
        c.rot += c.rotSpd * dt;
        c.vx *= 0.91;
        c.vy *= 0.91;
        c.rotSpd *= 0.91;
        c.life -= dt;
        if (c.life <= 0) this.casings.splice(i, 1);
      }
      for (let i = this.scorchMarks.length - 1; i >= 0; i--) {
        const sm = this.scorchMarks[i];
        sm.life -= dt;
        if (sm.life <= 0) this.scorchMarks.splice(i, 1);
      }
      for (let i = this.muzzleFlashes.length - 1; i >= 0; i--) {
        const mf = this.muzzleFlashes[i];
        mf.life -= dt;
        if (mf.life <= 0) this.muzzleFlashes.splice(i, 1);
      }
      for (let i = this.footprints.length - 1; i >= 0; i--) {
        const fp = this.footprints[i];
        fp.life -= dt;
        if (fp.life <= 0) this.footprints.splice(i, 1);
      }
      for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
        const ft = this.floatingTexts[i];
        ft.y -= 25 * dt;
        ft.life -= dt;
        if (ft.life <= 0) this.floatingTexts.splice(i, 1);
      }
    }

    updateHero(dt) {
      const h = this.hero;
      if (h.currentUltCd > 0) h.currentUltCd = Math.max(0, h.currentUltCd - dt * (this.hasAugment("chronos_overdrive") ? 1.35 : 1.0));
      if (h.ultActiveTime > 0) h.ultActiveTime = Math.max(0, h.ultActiveTime - dt);
      if (h.slashAnim > 0) h.slashAnim = Math.max(0, h.slashAnim - dt);
      if (h.dashTimer > 0) h.dashTimer = Math.max(0, h.dashTimer - dt);
      if (h.siegeRecoil > 0) h.siegeRecoil = Math.max(0, h.siegeRecoil - dt * 4.5);

      // Energy Shield Dome decay
      if (h.shieldDome) {
        h.shieldDome.timer -= dt;
        if (h.shieldDome.timer <= 0 || h.shieldDome.hp <= 0) {
          h.shieldDome = null;
          this.addFloatingText("SHIELD DOME TUGADI", h.x, h.y - 25, "#78909c", 13);
        }
      }

      // Hero Movement toward target
      const distToTarget = Math.hypot(h.targetX - h.x, h.targetY - h.y);
      if (distToTarget > 4) {
        const dashMult = (h.dashTimer > 0) ? 2.4 : 1.0;
        const moveSpd = h.speed * (this.hasAugment("hero_overdrive") ? 1.25 : 1.0) * (this.hasAugment("chronos_overdrive") ? 1.30 : 1.0) * dashMult;
        h.angle = Math.atan2(h.targetY - h.y, h.targetX - h.x);
        h.x += Math.cos(h.angle) * moveSpd * dt;
        h.y += Math.sin(h.angle) * moveSpd * dt;
        h.walkAnim = (h.walkAnim || 0) + dt * (h.dashTimer > 0 ? 20 : 10);

        // Footstep dust & imprints
        if (Math.random() < 0.22) {
          this.spawnFootprint(h.x, h.y, h.angle, h.mode === 'SIEGE');
          this.particles.push({
            x: h.x + (Math.random() * 8 - 4),
            y: h.y + (Math.random() * 8 - 4),
            vx: -Math.cos(h.angle) * 15 + (Math.random() * 6 - 3),
            vy: -Math.sin(h.angle) * 15 + (Math.random() * 6 - 3),
            color: "rgba(100, 116, 139, 0.35)", size: 3, growth: 7, life: 0.35, maxLife: 0.35
          });
        }

        // Thruster sparks
        if (Math.random() < 0.35) {
          const backX = h.x - Math.cos(h.angle) * 16;
          const backY = h.y - Math.sin(h.angle) * 16;
          this.particles.push({
            x: backX + (Math.random() * 6 - 3),
            y: backY + (Math.random() * 6 - 3),
            vx: -Math.cos(h.angle) * 30 + (Math.random() * 10 - 5),
            vy: -Math.sin(h.angle) * 30 + (Math.random() * 10 - 5),
            color: (h.mode === 'SIEGE') ? "#ffd600" : "#00e5ff", size: 2.5, life: 0.25, maxLife: 0.25
          });
        }
      } else {
        h.walkAnim = (h.walkAnim || 0) + dt * 2;
      }

      // Hero Combat State: SIEGE vs BIPED
      let inCombat = false;
      if (h.mode === 'SIEGE') {
        // SIEGE MODE: Heavy Dual 120mm Artillery Auto-Targeting (Range: 250px)
        h.siegeCooldown = Math.max(0, (h.siegeCooldown || 0) - dt);
        let bestTarget = null;
        let maxProg = -1;
        for (const e of this.enemies) {
          if (e.phased) continue;
          const d = Math.hypot(e.x - h.x, e.y - h.y);
          if (d <= 250) {
            inCombat = true;
            const score = (e.isBoss ? 1000 : 0) + (e.progress || 0);
            if (score > maxProg) {
              maxProg = score;
              bestTarget = e;
            }
          }
        }
        if (bestTarget) {
          h.angle = Math.atan2(bestTarget.y - h.y, bestTarget.x - h.x);
          if (h.siegeCooldown <= 0) {
            h.siegeCooldown = 1.35;
            h.siegeRecoil = 1.0;
            audio.shootMortar();
            this.screenShake = 4;
            this.vibrate(22);
            this.spawnMuzzleFlash(h.x, h.y, h.angle, 34, "#ffd600");
            this.spawnMuzzleSmoke(h.x, h.y, h.angle, "rgba(255, 180, 0, 0.45)");
            this.spawnSpentCasing(h.x, h.y, h.angle);
            // Launch 120mm Heavy Siege Shell
            this.projectiles.push({
              type: 'siege_shell',
              x: h.x + Math.cos(h.angle) * 20,
              y: h.y + Math.sin(h.angle) * 20,
              startX: h.x,
              startY: h.y,
              targetX: bestTarget.x,
              targetY: bestTarget.y,
              t: 0,
              flightTime: 0.45,
              damage: 180 * (this.hasAugment("hero_overdrive") ? 1.5 : 1.0),
              splash: 65
            });
          }
        }
      } else {
        // BIPED MODE: In-Combat Melee Plasma Katana (Range: 50px)
        h.atkCooldown -= dt;
        for (const e of this.enemies) {
          if (Math.hypot(e.x - h.x, e.y - h.y) <= 50) {
            inCombat = true;
            h.angle = Math.atan2(e.y - h.y, e.x - h.x);
            if (h.atkCooldown <= 0) {
              h.atkCooldown = 1.0 / h.atkRate;
              h.slashAnim = 0.22;
              audio.heroSlash();
              this.vibrate(18);
              const dmg = h.atkDmg * (this.hasAugment("hero_overdrive") ? 1.6 : 1.0);
              this.applyDamage(e, dmg, 'HERO', null, 'hero');
              this.particles.push({ x: e.x, y: e.y, vx: 0, vy: -30, color: "#ffd600", size: 5, life: 0.35, maxLife: 0.35 });
            }
            break;
          }
        }
      }

      // Hero HP Regen out of combat
      if (!inCombat && h.hp < h.maxHp) {
        const regenRate = this.hasAugment("hero_overdrive") ? 30 : 15;
        h.hp = Math.min(h.maxHp, h.hp + regenRate * dt);
      }
    }


    spawnSpentCasing(x, y, barrelAngle) {
      if (this.casings.length > 90) this.casings.shift();
      const side = Math.random() > 0.5 ? 1 : -1;
      const ejectAngle = barrelAngle + (Math.PI / 2) * side + (Math.random() * 0.4 - 0.2);
      const speed = 75 + Math.random() * 55;
      this.casings.push({
        x: x + Math.cos(barrelAngle) * 8,
        y: y + Math.sin(barrelAngle) * 8,
        vx: Math.cos(ejectAngle) * speed,
        vy: Math.sin(ejectAngle) * speed,
        rot: Math.random() * Math.PI * 2,
        rotSpd: (Math.random() * 20 - 10),
        life: 4.5,
        maxLife: 4.5,
        len: 6,
        thick: 2.2
      });
    }

    spawnMuzzleSmoke(x, y, angle, color = "rgba(180, 195, 210, 0.45)") {
      for (let i = 0; i < 3; i++) {
        const speed = 25 + Math.random() * 35;
        const spread = angle + (Math.random() * 0.6 - 0.3);
        this.particles.push({
          x: x + Math.cos(angle) * 16,
          y: y + Math.sin(angle) * 16,
          vx: Math.cos(spread) * speed,
          vy: Math.sin(spread) * speed,
          color: color,
          size: 4 + Math.random() * 3,
          growth: 12,
          life: 0.35 + Math.random() * 0.2,
          maxLife: 0.55
        });
      }
    }

    spawnMuzzleFlash(x, y, angle, radius = 24, color = "#ffd600") {
      this.muzzleFlashes.push({
        x: x + Math.cos(angle) * 18,
        y: y + Math.sin(angle) * 18,
        radius: radius,
        color: color,
        life: 0.08,
        maxLife: 0.08
      });
    }

    spawnScorchMark(x, y, radius = 32) {
      if (this.scorchMarks.length > 45) this.scorchMarks.shift();
      this.scorchMarks.push({
        x: x,
        y: y,
        radius: radius,
        life: 8.0,
        maxLife: 8.0
      });
    }

    spawnFootprint(x, y, angle, isHeavy = false) {
      if (this.footprints.length > 60) this.footprints.shift();
      this.footprints.push({
        x: x,
        y: y,
        angle: angle,
        isHeavy: isHeavy,
        life: 3.5,
        maxLife: 3.5
      });
    }

    findTargets(tower, range) {
      const candidates = [];
      const tDef = TOWER_DEFS[tower.type];
      const canHitAir = tDef ? (tDef.targetsAir !== false) : true;
      for (const e of this.enemies) {
        if (e.phased) continue;
        if (e.isFlyer && !canHitAir) continue; // Mortars cannot target aerial flyers
        const dist = Math.hypot(e.x - tower.x, e.y - tower.y);
        if (dist <= range) candidates.push({ enemy: e, dist: dist });
      }
      if (candidates.length === 0) return [];
      candidates.sort((a, b) => {
        let diff = 0;
        if (tower.priority === 'FIRST') diff = b.enemy.progress - a.enemy.progress;
        else if (tower.priority === 'LAST') diff = a.enemy.progress - b.enemy.progress;
        else if (tower.priority === 'STRONGEST') diff = (b.enemy.hp + b.enemy.shield) - (a.enemy.hp + a.enemy.shield);
        else if (tower.priority === 'NEAREST') diff = a.dist - b.dist;
        return diff !== 0 ? diff : (a.enemy.uid - b.enemy.uid);
      });
      return candidates.map(c => c.enemy);
    }

    fireTower(tower, targets, dmg, spec, range) {
      const primary = targets[0];
      let finalDmg = dmg;

      // Specialization perks
      if (tower.branch === 'B' && tower.type === 'pulse') {
        // Sniper Rail-Pulse 300% crit on boss/brute
        if (primary.isBoss || primary.type === 'brute') finalDmg *= 3.0;
      }

      tower.recoil = 1.0;
      tower.heat = Math.min(1.0, (tower.heat || 0) + 0.25);

      if (tower.type === 'pulse') {
        audio.shootPulse();
        this.spawnSpentCasing(tower.x, tower.y, tower.angle);
        this.spawnMuzzleFlash(tower.x, tower.y, tower.angle, tower.branch === 'B' ? 32 : 22, "#ffd600");
        this.spawnMuzzleSmoke(tower.x, tower.y, tower.angle);
        this.projectiles.push({ type: 'pulse', x: tower.x, y: tower.y, speed: 700, target: primary, damage: finalDmg, tower: tower, branch: tower.branch });
        if (tower.branch === 'A') primary.armor = Math.max(0, primary.armor - 1); // Gatling armor shred
      } else if (tower.type === 'mortar') {
        audio.shootMortar();
        this.spawnMuzzleFlash(tower.x, tower.y, tower.angle, 38, "#ff9100");
        this.spawnMuzzleSmoke(tower.x, tower.y, tower.angle, "rgba(120, 120, 120, 0.55)");
        this.projectiles.push({ type: 'mortar', startX: tower.x, startY: tower.y, targetX: primary.x, targetY: primary.y, x: tower.x, y: tower.y, t: 0, flightTime: 0.7, damage: finalDmg, splash: spec.splash, tower: tower, branch: tower.branch });
      } else if (tower.type === 'cryo') {
        audio.shootCryo();
        this.spawnShockwave(tower.x, tower.y, range, spec.color);
        this.spawnMuzzleSmoke(tower.x, tower.y, tower.angle, "rgba(0, 240, 255, 0.45)");
        for (const target of targets) {
          target.slowRatio = spec.slow || 0.45;
          target.slowTimer = spec.slowDur || 3.0;
          this.applyDamage(target, finalDmg, 'ENERGY', tower, 'cryo');
          // Tesla Chain Arc
          if (tower.branch === 'B') {
            const nearby = targets.filter(t => t !== target).slice(0, 3);
            for (const n of nearby) this.applyDamage(n, finalDmg * 0.7, 'ENERGY', tower, 'cryo');
          }
        }
      } else if (tower.type === 'railgun') {
        audio.shootRailgun();
        this.screenShake = 3;
        tower.laserTimer = 0.25;
        this.spawnMuzzleFlash(tower.x, tower.y, tower.angle, 42, "#e040fb");
        tower.targetPoint = { x: primary.x, y: primary.y };
        const pierceCount = spec.pierce || 2;
        const hitEnemies = targets.slice(0, pierceCount);
        for (const target of hitEnemies) {
          if (tower.branch === 'B') target.shield = 0; // Ion disrupter strips shields
          this.applyDamage(target, finalDmg, 'PIERCE', tower, 'railgun');
          // Superconductors augment spark
          if (this.hasAugment("superconductors")) {
            const extra = targets.find(e => !hitEnemies.includes(e));
            if (extra) this.applyDamage(extra, finalDmg * 0.5, 'ENERGY', tower, 'railgun');
          }
        }
      } else if (tower.type === 'tesla') {
        audio.shootTesla();
        this.spawnMuzzleFlash(tower.x, tower.y, tower.angle, 28, "#ffd600");
        const bonusChains = this.hasAugment("tesla_overcharge") ? 3 : 0;
        const chainCount = (spec.chainCount || 4) + bonusChains;
        const chained = [];
        let curr = primary;
        let chainDmg = finalDmg;
        for (let i = 0; i < chainCount && curr; i++) {
          chained.push(curr);
          this.applyDamage(curr, chainDmg, 'ENERGY', tower, 'tesla');
          if (tower.branch === 'A') {
            curr.slowRatio = 1.0;
            curr.slowTimer = 1.2; // EMP shock stun
          }
          const next = this.enemies.find(e => !chained.includes(e) && !e.phased && Math.hypot(e.x - curr.x, e.y - curr.y) <= 100);
          curr = next;
          chainDmg *= 0.85;
        }
        tower.lightningArcs = {
          time: 0.16,
          points: [{ x: tower.x, y: tower.y }, ...chained.map(c => ({ x: c.x, y: c.y }))]
        };
        if (tower.branch === 'B') {
          this.spawnShockwave(tower.x, tower.y, range, "#ffd600");
          for (const e of targets) {
            if (!chained.includes(e)) this.applyDamage(e, finalDmg * 0.65, 'ENERGY', tower, 'tesla');
          }
        }
      } else if (tower.type === 'flame') {
        audio.shootFlame();
        const coneHalf = (spec.coneAngle || 0.7) / 2;
        // Conical flame particles
        for (let p = 0; p < 7; p++) {
          const spreadAng = tower.angle + (Math.random() - 0.5) * (coneHalf * 2);
          const spd = 160 + Math.random() * 120;
          this.particles.push({
            x: tower.x + Math.cos(tower.angle) * 16,
            y: tower.y + Math.sin(tower.angle) * 16,
            vx: Math.cos(spreadAng) * spd,
            vy: Math.sin(spreadAng) * spd,
            color: (tower.branch === 'B') ? (Math.random() > 0.4 ? "#00e5ff" : "#ffffff") : (Math.random() > 0.4 ? "#ff3d00" : "#ffd600"),
            size: 4 + Math.random() * 5,
            growth: 14,
            life: 0.35 + Math.random() * 0.2,
            maxLife: 0.55
          });
        }
        for (const e of targets) {
          const toTargetAng = Math.atan2(e.y - tower.y, e.x - tower.x);
          let diffAng = Math.abs(toTargetAng - tower.angle);
          while (diffAng > Math.PI) diffAng = Math.abs(diffAng - Math.PI * 2);
          if (diffAng <= coneHalf) {
            this.applyDamage(e, finalDmg, 'FIRE', tower, 'flame');
            e.burnDmg = spec.dotDmg || 25;
            e.burnTimer = spec.dotDur || 3.0;
            if (tower.branch === 'B') {
              e.armor = Math.max(0, e.armor * 0.30); // 70% armor melt
            }
          }
        }
        if (tower.branch === 'A' && Math.random() < 0.25) {
          const poolDist = 40 + Math.random() * (range - 50);
          const px = tower.x + Math.cos(tower.angle) * poolDist;
          const py = tower.y + Math.sin(tower.angle) * poolDist;
          this.groundHazards.push({ x: px, y: py, radius: 40, life: 3.5, tickTimer: 0 });
        }
      }
    }

    detonateMortar(x, y, dmg, splashRadius, tower, branch) {
      audio.hit();
      this.screenShake = 6;
      let finalRadius = splashRadius;
      if (this.hasAugment("cluster_munitions")) finalRadius *= 1.35;
      if (this.hasAugment("siege_artillery_core")) {
        finalRadius *= 1.60;
        this.groundHazards.push({ x: x, y: y, radius: finalRadius * 0.65, life: 4.0, tickTimer: 0 });
      }

      this.spawnShockwave(x, y, finalRadius, '#ff9100');
      this.spawnScorchMark(x, y, finalRadius * 0.75);
      for (const e of this.enemies) {
        const d = Math.hypot(e.x - x, e.y - y);
        if (d <= finalRadius) {
          const falloff = 1.0 - (d / finalRadius) * 0.6;
          this.applyDamage(e, dmg * falloff, 'EXPLOSIVE', tower, 'mortar');
        }
      }

      // Branch A: Cluster Bomb bomblets
      if (branch === 'A') {
        for (let i = 0; i < 4; i++) {
          const ang = (Math.PI / 2) * i;
          const bx = x + Math.cos(ang) * 50;
          const by = y + Math.sin(ang) * 50;
          setTimeout(() => {
            this.spawnShockwave(bx, by, 35, '#ffd600');
            for (const e of this.enemies) {
              if (Math.hypot(e.x - bx, e.y - by) <= 35) this.applyDamage(e, 40, 'EXPLOSIVE', tower, 'mortar');
            }
          }, 150);
        }
      }

      // Branch B: Napalm Fire pool
      if (branch === 'B') {
        this.groundHazards.push({ x: x, y: y, radius: 45, life: 4.0, tickTimer: 0 });
      }
    }

    applyDamage(enemy, rawDmg, dmgType, tower, category = 'pulse') {
      let finalDmg = rawDmg;

      // Augment perks
      if (this.hasAugment("titan_slayer") && (enemy.isBoss || enemy.type === 'brute')) finalDmg *= 1.45;
      if (this.hasAugment("shatter_frost") && enemy.slowTimer > 0) finalDmg *= 1.80;

      if (dmgType === 'KINETIC' || dmgType === 'PIERCE') finalDmg = Math.max(1.0, rawDmg - enemy.armor);

      // Track combat analytics
      if (this.analytics.damageByTower[category] !== undefined) {
        this.analytics.damageByTower[category] += Math.round(finalDmg);
      }
      if (tower) tower.damageDealt += Math.round(finalDmg);

      if (enemy.shield > 0) {
        enemy.shieldRegenTimer = 0;
        if (enemy.shield >= finalDmg) {
          enemy.shield -= finalDmg;
          this.score += Math.round(finalDmg);
          this.addFloatingText(`${Math.round(finalDmg)}`, enemy.x, enemy.y - 12, '#00b0ff', 12);
          finalDmg = 0;
        } else {
          finalDmg -= enemy.shield;
          this.score += Math.round(enemy.shield);
          enemy.shield = 0;
        }
      }

      if (finalDmg > 0) {
        enemy.hp -= finalDmg;
        this.score += Math.round(finalDmg * 1.5);
        const color = dmgType === 'EXPLOSIVE' ? '#ff9100' : (dmgType === 'PIERCE' ? '#ff007f' : '#ffd600');
        this.addFloatingText(`${Math.round(finalDmg)}`, enemy.x, enemy.y - 12, color, 13);
      }

      if (enemy.hp <= 0) this.killEnemy(enemy, tower);
    }

    killEnemy(enemy, tower) {
      if (tower) tower.kills++;
      this.analytics.totalKills++;
      this.gold += enemy.bounty;
      this.analytics.totalGold += enemy.bounty;
      this.score += enemy.bounty * 50;
      this.spawnFlyingCoins(enemy.x, enemy.y, enemy.bounty);

      // Void Collector Augment
      if (this.hasAugment("void_collector")) {
        this.voidKillCount = (this.voidKillCount || 0) + 1;
        if (this.voidKillCount % 5 === 0) {
          this.gold += 3;
          this.analytics.totalGold += 3;
          this.addFloatingText("+3g VOID HARVEST", enemy.x, enemy.y - 32, "#7c4dff", 14);
        }
        if (this.hero.currentUltCd > 0) {
          this.hero.currentUltCd = Math.max(0, this.hero.currentUltCd - 0.5);
        }
      }

      // Hero XP
      this.hero.xp += (enemy.isBoss ? 40 : 10);
      if (this.hero.xp >= this.hero.maxXp && this.hero.level < 10) {
        this.hero.level++;
        this.hero.xp = 0;
        this.hero.maxXp += 40;
        this.hero.maxHp += 50;
        this.hero.hp = this.hero.maxHp;
        this.hero.atkDmg += 15;
        audio.upgrade();
        this.addFloatingText(`HERO LEVEL UP! (LV ${this.hero.level})`, this.hero.x, this.hero.y - 30, "#ffd600", 20);
      }

      this.addFloatingText(`+${enemy.bounty}g`, enemy.x, enemy.y - 20, '#ffd600', 14);

      if (enemy.type === 'splitter') {
        for (let i = -1; i <= 1; i += 2) {
          this.enemies.push({
            uid: this.nextUid++,
            type: 'swarmling',
            laneIdx: enemy.laneIdx,
            progress: Math.max(0, enemy.progress + i * 20),
            hp: 25, maxHp: 25, shield: 0, maxShield: 0, armor: 0,
            speed: 85, bounty: 2, size: 7, color: '#ffab00', marker: '◆', isBoss: false,
            slowRatio: 0, slowTimer: 0, x: enemy.x, y: enemy.y, angle: enemy.angle
          });
        }
      }

      if (enemy.isBoss) {
        this.screenShake = 12;
        audio.victory();
      }

      this.spawnDeathParticles(enemy.x, enemy.y, enemy.color);
      this.enemies = this.enemies.filter(item => item !== enemy);
    }

    onWaveCleared() {
      this.waveActive = false;
      const bonus = 20 + this.wave * 5;
      this.gold += bonus;
      this.analytics.totalGold += bonus;
      this.score += bonus * 25;

      if (this.hasAugment("nanite_repair")) {
        this.baseHp = Math.min(this.maxBaseHp, this.baseHp + 2);
        this.addFloatingText("+2 BASE HP REPAIRED!", 640, 110, "#00e676", 18);
      }

      this.addFloatingText(`${this.t("waveCleared")} +${bonus}g`, 640, 150, '#00e676', 26);
      audio.upgrade();

      // Roguelike Draft at Wave 5, 10, 15, 20, 25 OR after every wave in BOSS_RUSH!
      if ((this.gameMode === 'BOSS_RUSH' && this.wave < this.maxWaves) || (this.wave % 5 === 0 && this.wave < this.maxWaves)) {
        this.triggerAugmentDraft();
        this.wave++;
        this.waveCountdown = 8;
        return;
      }

      if ((this.gameMode === 'CAMPAIGN' || this.gameMode === 'CUSTOM') && this.wave >= this.maxWaves) this.onVictory();
      else if (this.gameMode === 'BOSS_RUSH' && this.wave >= this.maxWaves) this.onVictory();
      else {
        this.wave++;
        this.waveCountdown = 8;
      }
    }

    onVictory() {
      this.state = 'VICTORY';
      audio.playBGMTrack('victory');
      this.calculateMVP();
      const stars = (this.baseHp === this.maxBaseHp) ? 3 : (this.baseHp >= this.maxBaseHp * 0.5 ? 2 : 1);
      const mapId = (this.gameMode === 'CUSTOM') ? 'custom' : MAPS[this.currentMapIndex].id;
      this.saveProgress(mapId, stars, this.score, this.wave);
    }

    onDefeat() {
      this.state = 'DEFEAT';
      if (this.gameMode === 'ENDLESS') {
        try {
          const cur = parseInt(localStorage.getItem('lg_endless_wave') || '0');
          if (this.wave > cur) {
            localStorage.setItem('lg_endless_wave', this.wave.toString());
          }
          if (this.score > (this.saveData.highScores?.endless || 0)) {
            if (!this.saveData.highScores) this.saveData.highScores = {};
            this.saveData.highScores.endless = this.score;
            localStorage.setItem('last_grid_save_v2', JSON.stringify(this.saveData));
          }
        } catch(e) {}
      }
      audio.defeat();
      this.calculateMVP();
      const mapId = (this.gameMode === 'CUSTOM') ? 'custom' : MAPS[this.currentMapIndex].id;
      this.saveProgress(mapId, 0, this.score, this.wave);
    }

    calculateMVP() {
      let maxDmg = 0;
      let mvp = "Hero Apex-01";
      for (const t of this.towers) {
        if (t.damageDealt > maxDmg) {
          maxDmg = t.damageDealt;
          mvp = `${t.branch ? TOWER_DEFS[t.type].branches[t.branch].name : TOWER_DEFS[t.type].name} (#${t.uid})`;
        }
      }
      this.analytics.mvpName = mvp;
    }

    spawnShockwave(x, y, radius, color) {
      for (let i = 0; i < 16; i++) {
        const ang = (Math.PI * 2 / 16) * i;
        this.particles.push({
          x: x, y: y,
          vx: Math.cos(ang) * radius * 2.2,
          vy: Math.sin(ang) * radius * 2.2,
          color: color,
          size: 3, life: 0.35, maxLife: 0.35
        });
      }
    }

    spawnDeathParticles(x, y, color) {
      for (let i = 0; i < 12; i++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = 40 + Math.random() * 90;
        this.particles.push({
          x: x, y: y,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          color: color,
          size: 3 + Math.random() * 3,
          life: 0.5, maxLife: 0.5
        });
      }
    }

    spawnFlyingCoins(startX, startY, amount = 1) {
      const count = Math.min(6, Math.max(2, Math.floor(amount / 8)));
      for (let i = 0; i < count; i++) {
        this.flyingCoins.push({
          x: startX + (Math.random() - 0.5) * 24,
          y: startY + (Math.random() - 0.5) * 24,
          startX: startX,
          startY: startY,
          targetX: 180,
          targetY: 30,
          progress: 0,
          speed: 1.4 + Math.random() * 0.8,
          curveOffset: (Math.random() - 0.5) * 80,
          size: 7 + Math.random() * 3
        });
      }
    }

    spawnUpgradePillar(x, y, color = "#00e5ff") {
      this.upgradePillars.push({
        x, y, color,
        timer: 0.55,
        maxTimer: 0.55
      });
      this.screenShake = Math.max(this.screenShake, 6);
    }

    addFloatingText(text, x, y, color = '#ffffff', size = 13) {
      this.floatingTexts.push({ text, x, y, color, size, life: 1.0 });
    }

    // --- RENDERING PIPELINE ---
    
    renderTutorialOverlay(ctx) {
      ctx.save();
      const time = Date.now() * 0.005;
      const pulseRing = 10 + Math.sin(time) * 4;

      if (this.towers.length === 0) {
        // Step 1: Place Tower
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 2.5;
        // Highlight Pulse slot in bottom bar (x: 170, y: 648)
        ctx.strokeRect(130, 642, 65, 72);

        // Highlight optimal grid slot (x: 320, y: 320)
        ctx.beginPath();
        ctx.arc(384, 320, 24 + pulseRing, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = "rgba(10, 25, 47, 0.92)";
        ctx.strokeStyle = "#ffd600";
        ctx.beginPath();
        ctx.roundRect(140, 560, 420, 50, 8);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#ffd600";
        ctx.font = "bold 15px monospace";
        ctx.textAlign = "center";
        ctx.fillText("1. PASTKI PANELDAN MINORA TANLAB XARITAGA QO'YING!", 350, 590);
      } else if (!this.waveActive) {
        // Step 2: Engage Wave (Top HUD Bar)
        ctx.strokeStyle = "#ffd600";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(530, 30, 42 + pulseRing, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = "rgba(10, 25, 47, 0.92)";
        ctx.strokeStyle = "#00e5ff";
        ctx.beginPath();
        ctx.roundRect(330, 80, 400, 46, 8);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#00e5ff";
        ctx.font = "bold 14px monospace";
        ctx.textAlign = "center";
        ctx.fillText("2. TO'LQINNI BOSHLASH UCHUN 'JANGGA'NI BOSING!", 530, 108);
      }

      // Skip Button
      ctx.fillStyle = "rgba(255, 23, 68, 0.85)";
      ctx.beginPath();
      ctx.roundRect(1100, 18, 140, 30, 6);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("TUTORIALNI O'TKAZISH", 1170, 37);
      ctx.restore();
    }

    render() {
      // Clear entire backing buffer at full physical resolution
      this.ctx.setTransform(1, 0, 0, 1, 0, 0);
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      this.ctx.save();
      const sx = this.renderScaleX || (this.canvas.width / 1280);
      const sy = this.renderScaleY || (this.canvas.height / 720);
      this.ctx.setTransform(sx, 0, 0, sy, 0, 0);

      if (this.screenShake > 0) {
        const shakeX = (Math.random() * 2 - 1) * this.screenShake;
        const shakeY = (Math.random() * 2 - 1) * this.screenShake;
        this.ctx.translate(shakeX, shakeY);
      }

      // Hide 3D mech when Settings modal is open or when not in MENU
      if (this.apexSystem) {
        if (this.state === 'MENU' && !this.showSettingsModal) this.apexSystem.show();
        else this.apexSystem.hide();
      }
      if (this.state === 'MENU') this.renderMainMenu();
      else if (this.state === 'MAP_SELECT') this.renderMapSelect();
      else if (this.state === 'LEADERBOARD') this.renderLeaderboardModal();
      else if (this.state === 'MANUAL') this.renderFieldManual();
      else if (this.state === 'EDITOR') this.renderEditor();
      else if (this.state === 'DRAFT') this.renderDraftModal();
      else if (this.state === 'ANALYTICS') this.renderAnalyticsScreen();
      else if (this.state === 'TPS_3D') this.render3DTPS();
      else {
        this.renderBackgroundGrid();
        this.renderLanes();
        this.renderGroundDecals();
        this.renderGroundHazards();
        this.renderRedZones();
        this.renderBarricades();
        this.renderUnitShadows();
        this.renderBaseCore();
        this.renderTowers();
        this.renderAirdrops();
        this.renderHero();
        this.renderEnemies();
        this.renderProjectiles();
        this.renderParticles();
        this.renderUpgradePillars();
        this.renderFlyingCoins();
        this.renderSelectedTowerRadialHUD();
        this.renderCriticalLowHPPulse();
        this.renderDynamicLightingLayer();
        this.renderFloatingText();
        this.renderPlacementGhost();
        this.renderTacticalDragVector();
        this.renderRadialBuildWheel();
        this.renderRadioComms();
        this.renderBossAlert();
        this.renderMinimapHUD();
        this.renderCinematicBanner();
        this.renderTopHUD();
        this.renderBottomBar();
        this.renderMobileFloatingButtons();

        if (this.state === 'PAUSED') this.renderPauseModal();
        if (this.state === 'VICTORY') this.renderVictoryModal();
        if (this.state === 'DEFEAT') this.renderDefeatModal();
      }

      if (this.showSettingsModal) this.renderSettingsModal();
      if (this.exitToastTimer > 0) this.renderExitToast();
      if (this.crtEnabled) this.renderCRTOverlay();
      this.ctx.restore();
    }


    toggleLanguage() {
      return this.toggleLang();
    }

    loadBackgroundImages() {
      this.bgImages = {};
      const list = {
        cyber: 'assets/backgrounds/bg_cyber_grid_hd.png',
        lava: 'assets/backgrounds/bg_lava_core_hd.png',
        cryo: 'assets/backgrounds/bg_cryo_base_hd.png',
        menu: 'assets/backgrounds/bg_menu_hangar_hd.png'
      };
      for (const [key, path] of Object.entries(list)) {
        try {
          const img = new Image();
          img.src = path;
          img.onload = () => { this.bgImages[key] = img; };
        } catch(e) {}
      }
    }

    renderUpgradePillars() {
      if (!this.upgradePillars || this.upgradePillars.length === 0) return;
      const ctx = this.ctx;
      for (const p of this.upgradePillars) {
        const progress = Math.max(0, p.timer / p.maxTimer);
        const alpha = progress;
        ctx.save();
        ctx.globalAlpha = alpha * 0.85;
        const grad = ctx.createLinearGradient(p.x, p.y + 10, p.x, p.y - 140);
        grad.addColorStop(0, p.color || '#00e5ff');
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = grad;
        ctx.fillRect(p.x - 24, p.y - 140, 48, 150);

        ctx.strokeStyle = p.color || '#00e5ff';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 40 * (1 - progress), 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    renderFlyingCoins() {
      if (!this.flyingCoins || this.flyingCoins.length === 0) return;
      const ctx = this.ctx;
      ctx.save();
      for (const c of this.flyingCoins) {
        ctx.fillStyle = "#ffd600";
        ctx.shadowColor = "#ffea00";
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(c.x, c.y, c.size || 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#fff9c4";
        ctx.beginPath();
        ctx.arc(c.x, c.y, (c.size || 6) * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    renderSelectedTowerRadialHUD() {
      if (!this.selectedTower) return;
      const t = this.selectedTower;
      const def = TOWER_DEFS[t.type];
      const ctx = this.ctx;
      ctx.save();

      // Top Upgrade or Branch A/B buttons
      if (t.tier === 1) {
        const upCost = def.tiers[0].upCost;
        const canAfford = this.gold >= upCost;
        ctx.fillStyle = canAfford ? "rgba(0, 229, 255, 0.9)" : "rgba(80, 90, 100, 0.85)";
        ctx.fillRect(t.x - 65, t.y - 62, 130, 32);
        ctx.strokeStyle = canAfford ? "#00e5ff" : "#546e7a";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(t.x - 65, t.y - 62, 130, 32);
        ctx.fillStyle = "#05070d";
        ctx.font = "bold 12px monospace";
        ctx.textAlign = "center";
        ctx.fillText(`▲ UPGRADE (${upCost}g)`, t.x, t.y - 42);
      } else if (t.tier === 2) {
        // Branch A (Left top)
        const bA = def.branches.A;
        const canA = this.gold >= bA.cost;
        ctx.fillStyle = canA ? "rgba(0, 229, 255, 0.9)" : "rgba(80, 90, 100, 0.85)";
        ctx.fillRect(t.x - 110, t.y - 70, 105, 36);
        ctx.strokeStyle = "#00e5ff";
        ctx.strokeRect(t.x - 110, t.y - 70, 105, 36);
        ctx.fillStyle = "#05070d";
        ctx.font = "bold 11px monospace";
        ctx.textAlign = "center";
        ctx.fillText(`${bA.name.slice(0, 10)}`, t.x - 57, t.y - 53);
        ctx.fillText(`(${bA.cost}g)`, t.x - 57, t.y - 40);

        // Branch B (Right top)
        const bB = def.branches.B;
        const canB = this.gold >= bB.cost;
        ctx.fillStyle = canB ? "rgba(255, 145, 0, 0.9)" : "rgba(80, 90, 100, 0.85)";
        ctx.fillRect(t.x + 5, t.y - 70, 105, 36);
        ctx.strokeStyle = "#ff9100";
        ctx.strokeRect(t.x + 5, t.y - 70, 105, 36);
        ctx.fillStyle = "#05070d";
        ctx.font = "bold 11px monospace";
        ctx.textAlign = "center";
        ctx.fillText(`${bB.name.slice(0, 10)}`, t.x + 57, t.y - 53);
        ctx.fillText(`(${bB.cost}g)`, t.x + 57, t.y - 40);
      }

      // Left Sell Button
      const refund = Math.floor(t.totalInvested * 0.70);
      ctx.fillStyle = "rgba(255, 23, 68, 0.85)";
      ctx.fillRect(t.x - 115, t.y - 18, 75, 36);
      ctx.strokeStyle = "#ff1744";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(t.x - 115, t.y - 18, 75, 36);
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("SOTISH", t.x - 77, t.y);
      ctx.fillText(`+${refund}g`, t.x - 77, t.y + 12);

      // Right Priority Button
      ctx.fillStyle = "rgba(124, 77, 255, 0.85)";
      ctx.fillRect(t.x + 40, t.y - 18, 75, 36);
      ctx.strokeStyle = "#7c4dff";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(t.x + 40, t.y - 18, 75, 36);
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("NISHON", t.x + 77, t.y);
      ctx.fillText(`${t.priority.slice(0, 6)}`, t.x + 77, t.y + 12);

      // Bottom Close Button
      ctx.fillStyle = "rgba(38, 50, 56, 0.9)";
      ctx.fillRect(t.x - 35, t.y + 40, 70, 28);
      ctx.strokeStyle = "#90a4ae";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(t.x - 35, t.y + 40, 70, 28);
      ctx.fillStyle = "#eceff1";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "center";
      ctx.fillText("✕ YOPISH", t.x, t.y + 58);

      ctx.restore();
    }

    renderCriticalLowHPPulse() {
      if (this.baseHp > 5 || this.state !== 'PLAYING') return;
      const ctx = this.ctx;
      const pulse = 0.5 + 0.5 * Math.sin(Date.now() * 0.008);
      ctx.save();
      ctx.strokeStyle = `rgba(255, 23, 68, ${0.35 + 0.35 * pulse})`;
      ctx.lineWidth = 8;
      ctx.strokeRect(4, 4, this.width - 8, this.height - 8);

      ctx.fillStyle = `rgba(255, 23, 68, ${0.12 * pulse})`;
      ctx.fillRect(0, 0, this.width, this.height);
      ctx.restore();
    }

    renderCRTOverlay() {
      this.ctx.fillStyle = "rgba(0, 229, 255, 0.02)";
      for (let y = 0; y < this.height; y += 4) {
        this.ctx.fillRect(0, y, this.width, 1.5);
      }
    }

    renderBackgroundGrid() {
      const ctx = this.ctx;
      const map = (this.gameMode === 'CUSTOM') ? { biome: "cyber" } : MAPS[this.currentMapIndex];
      const biome = (map && map.biome) ? map.biome : "cyber";

      // Background gradient based on biome
      const bgGrad = ctx.createLinearGradient(0, 0, 0, this.height);
      if (biome === 'lava') {
        bgGrad.addColorStop(0, "#150403");
        bgGrad.addColorStop(0.5, "#220805");
        bgGrad.addColorStop(1, "#100202");
      } else if (biome === 'cryo') {
        bgGrad.addColorStop(0, "#030c18");
        bgGrad.addColorStop(0.5, "#07182c");
        bgGrad.addColorStop(1, "#020812");
      } else {
        bgGrad.addColorStop(0, "#050812");
        bgGrad.addColorStop(0.5, "#080e1e");
        bgGrad.addColorStop(1, "#04060d");
      }
      if (this.bgImages && this.bgImages[biome]) {
        try {
          ctx.drawImage(this.bgImages[biome], 0, 0, this.width, this.height);
        } catch(e) {
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, this.width, this.height);
        }
      } else {
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, this.width, this.height);
      }

      // Grid Lines
      const gridStroke = (biome === 'lava') ? "rgba(255, 87, 34, 0.12)" :
                         (biome === 'cryo') ? "rgba(128, 222, 234, 0.14)" :
                         "rgba(0, 229, 255, 0.08)";
      ctx.strokeStyle = gridStroke;
      ctx.lineWidth = 1;
      for (let x = 0; x <= this.width; x += 64) {
        ctx.beginPath(); ctx.moveTo(x, 60); ctx.lineTo(x, 620); ctx.stroke();
      }
      for (let y = 60; y <= 620; y += 64) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.width, y); ctx.stroke();
      }

      // Tech Junction Crosshairs
      ctx.fillStyle = (biome === 'lava') ? "rgba(255, 112, 67, 0.35)" :
                      (biome === 'cryo') ? "rgba(0, 229, 255, 0.40)" :
                      "rgba(0, 229, 255, 0.25)";
      for (let x = 64; x < this.width; x += 128) {
        for (let y = 124; y < 620; y += 128) {
          ctx.fillRect(x - 3, y - 0.5, 6, 1);
          ctx.fillRect(x - 0.5, y - 3, 1, 6);
        }
      }

      // Outer Perimeter Defense Hazard Border
      ctx.strokeStyle = (biome === 'lava') ? "rgba(255, 61, 0, 0.45)" :
                        (biome === 'cryo') ? "rgba(0, 229, 255, 0.40)" :
                        "rgba(0, 229, 255, 0.30)";
      ctx.lineWidth = 1;
      ctx.strokeRect(2, 62, this.width - 4, 556);

      // Atmospheric Biome Floating Particles
      this.renderBiomeParticles(ctx, biome);
    }

    renderLanes() {
      const map = (this.gameMode === 'CUSTOM') ? { lanes: [this.editorWaypoints] } : MAPS[this.currentMapIndex];
      const ctx = this.ctx;
      const time = performance.now() * 0.003;

      for (const lane of map.lanes) {
        if (!lane || lane.length < 2) continue;

        // 1. Reinforced Trench Roadway (Dark Heavy Composite Base)
        ctx.beginPath();
        ctx.moveTo(lane[0].x, lane[0].y);
        for (let i = 1; i < lane.length; i++) ctx.lineTo(lane[i].x, lane[i].y);
        ctx.strokeStyle = "#0d1629";
        ctx.lineWidth = 48;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.stroke();

        // 2. Concrete Curb Edge Lines
        ctx.strokeStyle = "rgba(0, 229, 255, 0.28)";
        ctx.lineWidth = 44;
        ctx.stroke();

        // 3. Inner Dark Pavement
        ctx.strokeStyle = "#0a1120";
        ctx.lineWidth = 38;
        ctx.stroke();

        // 4. Animated Tactical Guidance Dashed Centerline
        ctx.save();
        ctx.strokeStyle = "rgba(0, 229, 255, 0.85)";
        ctx.lineWidth = 2.5;
        ctx.lineDashOffset = -time * 28;
        ctx.setLineDash([14, 12]);
        ctx.beginPath();
        ctx.moveTo(lane[0].x, lane[0].y);
        for (let i = 1; i < lane.length; i++) ctx.lineTo(lane[i].x, lane[i].y);
        ctx.stroke();
        ctx.restore();
      }

      // Holographic Quantum Warp Gate at Spawn
      for (const lane of map.lanes) {
        if (!lane || lane.length < 2) continue;
        const sp = lane[0];
        ctx.save();
        ctx.translate(sp.x, sp.y);

        // Rotating hazard ring
        ctx.rotate(time * 1.6);
        ctx.strokeStyle = "#ff1744";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, 24, 0, Math.PI * 2);
        ctx.stroke();

        // Pulsing hazard arcs
        ctx.strokeStyle = "rgba(255, 23, 68, 0.7)";
        ctx.lineWidth = 1.8;
        for (let i = 0; i < 3; i++) {
          const a = (Math.PI * 2 / 3) * i;
          ctx.beginPath();
          ctx.arc(0, 0, 30, a, a + Math.PI / 4);
          ctx.stroke();
        }
        ctx.restore();

        // Spawn Gate Core
        ctx.fillStyle = "rgba(255, 23, 68, 0.9)";
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 9px monospace";
        ctx.textAlign = "center";
        ctx.fillText("WARP", sp.x, sp.y + 3);
      }
    }

    renderGroundHazards() {
      for (const h of this.groundHazards) {
        this.ctx.fillStyle = "rgba(255, 61, 0, 0.35)";
        this.ctx.beginPath();
        this.ctx.arc(h.x, h.y, h.radius, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.strokeStyle = "#ff3d00";
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
      }
    }

    // --- HIGH-TECH PROCEDURAL SCI-FI RENDERING PIPELINE ---

    renderGroundDecals() {
      const ctx = this.ctx;

      // 1. Blast Scorch Marks
      for (const sm of this.scorchMarks) {
        const alpha = Math.max(0, sm.life / sm.maxLife) * 0.65;
        const grad = ctx.createRadialGradient(sm.x, sm.y, sm.radius * 0.15, sm.x, sm.y, sm.radius);
        grad.addColorStop(0, `rgba(15, 23, 42, ${alpha})`);
        grad.addColorStop(0.5, `rgba(25, 12, 12, ${alpha * 0.7})`);
        grad.addColorStop(1, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(sm.x, sm.y, sm.radius, 0, Math.PI * 2);
        ctx.fill();

        // Cracked pavement fracture lines
        ctx.strokeStyle = `rgba(5, 5, 12, ${alpha * 0.85})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        for (let i = 0; i < 4; i++) {
          const a = (Math.PI / 2) * i + 0.35;
          ctx.moveTo(sm.x, sm.y);
          ctx.lineTo(sm.x + Math.cos(a) * sm.radius * 0.8, sm.y + Math.sin(a) * sm.radius * 0.8);
        }
        ctx.stroke();
      }

      // 2. Footprints & Tread Marks
      for (const fp of this.footprints) {
        const alpha = Math.max(0, fp.life / fp.maxLife) * (fp.isHeavy ? 0.35 : 0.2);
        ctx.save();
        ctx.translate(fp.x, fp.y);
        ctx.rotate(fp.angle);
        ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
        if (fp.isHeavy) {
          ctx.fillRect(-8, -12, 16, 5);
          ctx.fillRect(-8, 7, 16, 5);
        } else {
          ctx.fillRect(-4, -6, 8, 4);
          ctx.fillRect(-4, 2, 8, 4);
        }
        ctx.restore();
      }

      // 3. Spent Brass Shell Casings (Physics bounce & spin)
      for (const c of this.casings) {
        const alpha = Math.min(1.0, c.life / 0.5);
        ctx.save();
        ctx.translate(c.x, c.y);
        ctx.rotate(c.rot);
        ctx.globalAlpha = alpha;

        // Drop shadow
        ctx.fillStyle = "rgba(0, 0, 0, 0.45)";
        ctx.fillRect(-c.len / 2 + 1, -c.thick / 2 + 1, c.len, c.thick);

        // Metallic Brass Gradient
        const brassGrad = ctx.createLinearGradient(0, -c.thick / 2, 0, c.thick / 2);
        brassGrad.addColorStop(0, "#ffe082"); // specular top highlight
        brassGrad.addColorStop(0.35, "#ffd54f"); // polished yellow brass
        brassGrad.addColorStop(0.8, "#ffb300"); // dark copper
        brassGrad.addColorStop(1, "#6d4c41"); // shadow bevel
        ctx.fillStyle = brassGrad;
        ctx.fillRect(-c.len / 2, -c.thick / 2, c.len, c.thick);

        // Primer rim cap
        ctx.fillStyle = "#ff8f00";
        ctx.fillRect(-c.len / 2, -c.thick / 2, 1.2, c.thick);

        ctx.restore();
      }
      ctx.globalAlpha = 1.0;
    }

    renderUnitShadows() {
      const ctx = this.ctx;
      const map = (this.gameMode === 'CUSTOM') ? { lanes: [this.editorWaypoints] } : MAPS[this.currentMapIndex];
      const base = map.lanes[0][map.lanes[0].length - 1];

      // 1. Base Core Heavy Contact Shadow
      const baseShadowGrad = ctx.createRadialGradient(base.x + 4, base.y + 8, 10, base.x + 4, base.y + 8, 48);
      baseShadowGrad.addColorStop(0, "rgba(0, 0, 0, 0.75)");
      baseShadowGrad.addColorStop(0.65, "rgba(0, 0, 0, 0.35)");
      baseShadowGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = baseShadowGrad;
      ctx.beginPath();
      ctx.ellipse(base.x + 4, base.y + 8, 48, 28, 0, 0, Math.PI * 2);
      ctx.fill();

      // 2. Towers Ambient Occlusion & Barrel Shadows
      for (const t of this.towers) {
        const shadowGrad = ctx.createRadialGradient(t.x + 3, t.y + 7, 6, t.x + 3, t.y + 7, 34);
        shadowGrad.addColorStop(0, "rgba(0, 0, 0, 0.8)");
        shadowGrad.addColorStop(0.65, "rgba(0, 0, 0, 0.4)");
        shadowGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = shadowGrad;
        ctx.beginPath();
        ctx.ellipse(t.x + 3, t.y + 7, 34, 22, 0, 0, Math.PI * 2);
        ctx.fill();

        // Directional Barrel Cast Shadow
        ctx.save();
        ctx.translate(t.x + 2, t.y + 6);
        ctx.rotate(t.angle);
        ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
        ctx.fillRect(0, -4, 28, 8);
        ctx.restore();
      }

      // 3. Hero Mech Ground Contact Shadow
      const h = this.hero;
      const heroShadowGrad = ctx.createRadialGradient(h.x + 3, h.y + 7, 4, h.x + 3, h.y + 7, 24);
      heroShadowGrad.addColorStop(0, "rgba(0, 0, 0, 0.75)");
      heroShadowGrad.addColorStop(0.6, "rgba(0, 0, 0, 0.35)");
      heroShadowGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = heroShadowGrad;
      ctx.beginPath();
      ctx.ellipse(h.x + 3, h.y + 7, 24, 14, h.angle * 0.3, 0, Math.PI * 2);
      ctx.fill();

      // 4. Enemies Ground Contact Shadows
      for (const e of this.enemies) {
        if (e.phased) continue;
        const radX = e.size * 1.35;
        const radY = e.size * 0.75;
        const sGrad = ctx.createRadialGradient(e.x + 3, e.y + 5, radX * 0.2, e.x + 3, e.y + 5, radX);
        const shadowAlpha = e.isBoss ? 0.75 : 0.55;
        sGrad.addColorStop(0, `rgba(0, 0, 0, ${shadowAlpha})`);
        sGrad.addColorStop(0.6, `rgba(0, 0, 0, ${shadowAlpha * 0.5})`);
        sGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = sGrad;
        ctx.beginPath();
        ctx.ellipse(e.x + 3, e.y + 5, radX, radY, e.angle * 0.3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    renderBaseCore() {
      const map = (this.gameMode === 'CUSTOM') ? { lanes: [this.editorWaypoints] } : MAPS[this.currentMapIndex];
      const base = map.lanes[0][map.lanes[0].length - 1];
      const time = performance.now() * 0.002;
      const ctx = this.ctx;
      const hpPct = Math.max(0, this.baseHp / this.maxBaseHp);

      ctx.save();
      ctx.translate(base.x, base.y);

      // 1. Reinforced Hexagonal Heavy Cast-Titanium Platform
      const plinthGrad = ctx.createLinearGradient(-36, -36, 36, 36);
      plinthGrad.addColorStop(0, "#334155"); // specular top edge
      plinthGrad.addColorStop(0.5, "#1e293b"); // gunmetal body
      plinthGrad.addColorStop(1, "#0f172a"); // dark shadow bevel
      ctx.fillStyle = plinthGrad;
      ctx.strokeStyle = hpPct < 0.3 ? "#ff1744" : "rgba(0, 229, 255, 0.8)";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i;
        const px = Math.cos(a) * 38;
        const py = Math.sin(a) * 38;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Inner 3D Chamfer Rim
      ctx.strokeStyle = "rgba(100, 116, 139, 0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i;
        const px = Math.cos(a) * 32;
        const py = Math.sin(a) * 32;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();

      // Corner Stainless Steel Bolts
      ctx.fillStyle = "#94a3b8";
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i + Math.PI / 6;
        const bx = Math.cos(a) * 30;
        const by = Math.sin(a) * 30;
        ctx.beginPath();
        ctx.arc(bx, by, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(bx - 1, by - 1, 1.5, 1.5);
        ctx.fillStyle = "#94a3b8";
      }

      // 2. Counter-Rotating Gyro Containment Rings
      ctx.save();
      ctx.rotate(time * 0.8);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.85)";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, 25, 0, Math.PI * 1.6);
      ctx.stroke();
      // Counter-weight nodules
      ctx.fillStyle = "#ffd600";
      ctx.fillRect(23, -3, 5, 6);
      ctx.fillRect(-27, -3, 5, 6);
      ctx.restore();

      ctx.save();
      ctx.rotate(-time * 1.2);
      ctx.strokeStyle = "rgba(0, 240, 255, 0.65)";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(0, 0, 19, 0, Math.PI * 1.4);
      ctx.stroke();
      ctx.restore();

      // 3. Central Quantum Plasma Reactor Core
      const grad = ctx.createRadialGradient(0, 0, 2, 0, 0, 15);
      grad.addColorStop(0, "#ffffff");
      grad.addColorStop(0.35, hpPct < 0.3 ? "#ff1744" : "#00e5ff");
      grad.addColorStop(0.8, hpPct < 0.3 ? "#d50000" : "#0091ea");
      grad.addColorStop(1, hpPct < 0.3 ? "rgba(255, 23, 68, 0)" : "rgba(0, 110, 255, 0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, 15 + Math.sin(time * 4) * 2, 0, Math.PI * 2);
      ctx.fill();

      // Magnetic Flare Corona
      ctx.strokeStyle = hpPct < 0.3 ? "rgba(255, 23, 68, 0.7)" : "rgba(0, 229, 255, 0.6)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(0, 0, 31 + Math.sin(time * 3) * 3, 0, Math.PI * 2);
      ctx.stroke();

      ctx.restore();

      // Holographic Status Display
      ctx.fillStyle = hpPct < 0.3 ? "#ff1744" : "#ffffff";
      ctx.font = "bold 10px monospace";
      ctx.textAlign = "center";
      ctx.fillText(hpPct < 0.3 ? "CRITICAL" : "CORE", base.x, base.y + 4);
    }

    renderHero() {
      const h = this.hero;
      const ctx = this.ctx;
      ctx.save();
      ctx.translate(h.x, h.y);

      // 1. Ultimate Holographic Mandala Blade Storm
      if (h.ultActiveTime > 0) {
        const ultProg = h.ultActiveTime / 0.6;
        ctx.save();
        ctx.rotate(performance.now() * 0.015);
        ctx.strokeStyle = "rgba(0, 229, 255, 0.9)";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(0, 0, 85 * (1.1 - ultProg * 0.3), 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = "rgba(255, 214, 0, 0.85)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 125 * (1.0 - ultProg * 0.4), 0, Math.PI * 2);
        ctx.stroke();

        for (let i = 0; i < 4; i++) {
          const ang = (Math.PI / 2) * i;
          ctx.beginPath();
          ctx.arc(0, 0, 75, ang, ang + Math.PI / 3);
          ctx.stroke();
        }
        ctx.restore();
      }

      // 2. Selection Halo (Tactical Reticle)
      if (h.selected) {
        ctx.strokeStyle = "#ffd600";
        ctx.lineWidth = 2.5;
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        ctx.arc(0, 0, 32, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // 3. Facing Orientation & Articulated Mech (SIEGE vs BIPED)
      const ang = h.angle || 0;
      ctx.rotate(ang);

      const walkCycle = Math.sin(h.walkAnim || 0);

      if (h.mode === 'SIEGE') {
        // --- SIEGE TANK: ARMORED CATERPILLAR TRACKS & DUAL 120MM CANNONS ---
        const trackCycle = (h.walkAnim || 0) * 8;
        const recoil = (h.siegeRecoil || 0) * 7;

        // Left Caterpillar Tread Assembly
        ctx.fillStyle = "#090d16";
        ctx.fillRect(-17 - recoil, -20, 34, 10);
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-17 - recoil, -20, 34, 10);
        // Track segments
        ctx.fillStyle = "#334155";
        for (let t = -15; t <= 13; t += 5) {
          const off = ((t + trackCycle) % 28) - 14;
          ctx.fillRect(off - recoil, -20, 2.5, 10);
        }
        // Road wheels
        ctx.fillStyle = "#64748b";
        for (let w = -11; w <= 11; w += 7) {
          ctx.beginPath();
          ctx.arc(w - recoil, -15, 2.8, 0, Math.PI * 2);
          ctx.fill();
        }

        // Right Caterpillar Tread Assembly
        ctx.fillStyle = "#090d16";
        ctx.fillRect(-17 - recoil, 10, 34, 10);
        ctx.strokeStyle = "#475569";
        ctx.strokeRect(-17 - recoil, 10, 34, 10);
        // Track segments
        ctx.fillStyle = "#334155";
        for (let t = -15; t <= 13; t += 5) {
          const off = ((t + trackCycle) % 28) - 14;
          ctx.fillRect(off - recoil, 10, 2.5, 10);
        }
        // Road wheels
        ctx.fillStyle = "#64748b";
        for (let w = -11; w <= 11; w += 7) {
          ctx.beginPath();
          ctx.arc(w - recoil, 15, 2.8, 0, Math.PI * 2);
          ctx.fill();
        }

        // Armored Fortress Hull Chassis
        const hullGrad = ctx.createLinearGradient(-15, -12, 18, 12);
        hullGrad.addColorStop(0, "#475569");
        hullGrad.addColorStop(0.5, "#1e293b");
        hullGrad.addColorStop(1, "#0f172a");
        ctx.fillStyle = hullGrad;
        ctx.fillRect(-14 - recoil, -12, 28, 24);
        ctx.strokeStyle = "#ffd600";
        ctx.lineWidth = 2;
        ctx.strokeRect(-14 - recoil, -12, 28, 24);

        // Bolted Armor Plates & Warning Hazard Decals
        ctx.fillStyle = "#ffd600";
        ctx.fillRect(-12 - recoil, -10, 4, 20);
        ctx.fillStyle = "#000000";
        ctx.fillRect(-6 - recoil, -10, 4, 20);

        // Dual 120mm Heavy Siege Artillery Barrels
        ctx.fillStyle = "#334155";
        ctx.fillRect(10 - recoil, -7, 28, 5);
        ctx.fillRect(10 - recoil, 2, 28, 5);
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 1;
        ctx.strokeRect(10 - recoil, -7, 28, 5);
        ctx.strokeRect(10 - recoil, 2, 28, 5);

        // Slotted Heavy Muzzle Brakes
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(34 - recoil, -8, 5, 7);
        ctx.fillRect(34 - recoil, 1, 5, 7);
        // Barrel Heat Glow
        if (h.siegeRecoil > 0) {
          ctx.fillStyle = `rgba(255, 145, 0, ${h.siegeRecoil})`;
          ctx.fillRect(35 - recoil, -7, 3, 5);
          ctx.fillRect(35 - recoil, 2, 3, 5);
        }

        // Rotating Heavy Armored Commander Turret Cupola
        ctx.fillStyle = "#1e293b";
        ctx.beginPath();
        ctx.arc(-2 - recoil, 0, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffd600";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Glowing Amber Targeting Visor
        ctx.fillStyle = "#ffd600";
        ctx.fillRect(3 - recoil, -3, 3, 6);
      } else {
        // --- BIPED ASSAULT ROBOT: ARTICULATED LEGS & PLASMA KATANA ---
        // Articulated Hydraulic Legs with Knee Actuators & Footplates
        const legL_X = -10 + walkCycle * 4;
        const legR_X = -10 - walkCycle * 4;

        // Left Leg
        const legGrad = ctx.createLinearGradient(-12, -15, 0, -10);
        legGrad.addColorStop(0, "#334155");
        legGrad.addColorStop(1, "#0f172a");
        ctx.fillStyle = legGrad;
        ctx.fillRect(legL_X, -15, 9, 6);
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 1.2;
        ctx.strokeRect(legL_X, -15, 9, 6);
        // Piston rod
        ctx.fillStyle = "#94a3b8";
        ctx.fillRect(legL_X + 2, -13, 5, 2);

        // Right Leg
        ctx.fillStyle = legGrad;
        ctx.fillRect(legR_X, 9, 9, 6);
        ctx.strokeRect(legR_X, 9, 9, 6);
        ctx.fillStyle = "#94a3b8";
        ctx.fillRect(legR_X + 2, 11, 5, 2);

        // Dual Ion Thruster Backpack
        const thrusterGrad = ctx.createLinearGradient(-16, -9, -10, 9);
        thrusterGrad.addColorStop(0, "#1e293b");
        thrusterGrad.addColorStop(1, "#090d16");
        ctx.fillStyle = thrusterGrad;
        ctx.fillRect(-15, -9, 7, 18);
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 1;
        ctx.strokeRect(-15, -9, 7, 18);

        // Exhaust Nozzles & Blue Ion Flare
        ctx.fillStyle = "#00e5ff";
        ctx.fillRect(-17, -7, 2, 4);
        ctx.fillRect(-17, 3, 2, 4);

        // Armored Titanium Torso Chassis (Multi-Stop Gradient & Bevels)
        const torsoGrad = ctx.createLinearGradient(-12, -12, 14, 12);
        torsoGrad.addColorStop(0, "#475569"); // top-left specular highlight
        torsoGrad.addColorStop(0.4, "#1e293b"); // gunmetal armor plate
        torsoGrad.addColorStop(1, "#0f172a"); // shadow chamfer
        ctx.fillStyle = torsoGrad;
        ctx.beginPath();
        ctx.moveTo(-11, -11);
        ctx.lineTo(9, -9);
        ctx.lineTo(14, 0);
        ctx.lineTo(9, 9);
        ctx.lineTo(-11, 11);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 2;
        ctx.stroke();

        // Shoulder Pauldrons with Unit Marking
        ctx.fillStyle = "#334155";
        ctx.fillRect(-6, -15, 7, 5);
        ctx.fillRect(-6, 10, 7, 5);

        // Glowing Quantum Arc-Reactor Core
        const reactorGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, 5.5);
        reactorGrad.addColorStop(0, "#ffffff");
        reactorGrad.addColorStop(0.4, "#ffd600");
        reactorGrad.addColorStop(1, "#ff6d00");
        ctx.fillStyle = reactorGrad;
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // Rotating Brass Magnetic Confinement Ring
        ctx.save();
        ctx.rotate(performance.now() * 0.005);
        ctx.strokeStyle = "#ffd54f";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(0, 0, 7.5, 0, Math.PI * 1.5);
        ctx.stroke();
        ctx.restore();

        // Angular Cockpit / Helmet with Neon Cyan Glass Visor & Specular Glint
        ctx.fillStyle = "#090d16";
        ctx.beginPath();
        ctx.moveTo(3, -5);
        ctx.lineTo(14, -3);
        ctx.lineTo(16, 0);
        ctx.lineTo(14, 3);
        ctx.lineTo(3, 5);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Visor Glass Specular Glint
        const visorGrad = ctx.createLinearGradient(6, -3, 14, 0);
        visorGrad.addColorStop(0, "#ffffff");
        visorGrad.addColorStop(0.6, "#00e5ff");
        visorGrad.addColorStop(1, "#0091ea");
        ctx.strokeStyle = visorGrad;
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.moveTo(6, -3);
        ctx.lineTo(14, 0);
        ctx.lineTo(6, 3);
        ctx.stroke();

        // Tactical Left Arm Energy Buckler
        ctx.fillStyle = "#00b0ff";
        ctx.fillRect(0, -14, 7, 4);
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;
        ctx.strokeRect(0, -14, 7, 4);

        // High-Frequency Plasma Katana (Right Arm)
        const slashAngle = (h.slashAnim > 0) ? ((0.22 - h.slashAnim) / 0.22) * Math.PI : 0;
        ctx.save();
        ctx.translate(4, 10);
        ctx.rotate(slashAngle);

        // Katana Hilt
        ctx.fillStyle = "#475569";
        ctx.fillRect(-3, -2.5, 6, 5);
        ctx.fillStyle = "#94a3b8";
        ctx.fillRect(2, -4, 2, 8); // Tsuba guard

        // Curved Energy Wake Ribbon Trail when slashing
        if (h.slashAnim > 0) {
          ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
          ctx.lineWidth = 8;
          ctx.beginPath();
          ctx.arc(-4, 0, 26, -0.6, 0.6);
          ctx.stroke();
        }

        // Outer Ionized Plasma Envelope
        ctx.strokeStyle = "rgba(0, 229, 255, 0.85)";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(4, 0);
        ctx.lineTo(28, 0);
        ctx.stroke();

        // Inner White-Hot Tungsten Cutting Edge
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(4, 0);
        ctx.lineTo(27, 0);
        ctx.stroke();
        ctx.restore();
      }

      // Energy Shield Dome Hexagonal Forcefield Visual
      if (h.shieldDome && h.shieldDome.timer > 0) {
        ctx.save();
        const domeAngle = performance.now() * 0.002;
        ctx.rotate(domeAngle);
        const domeAlpha = 0.35 + Math.sin(performance.now() * 0.006) * 0.15;
        ctx.strokeStyle = `rgba(0, 229, 255, ${domeAlpha + 0.35})`;
        ctx.fillStyle = `rgba(0, 229, 255, ${domeAlpha * 0.22})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        const hr = 72;
        for (let i = 0; i < 6; i++) {
          const a = (Math.PI / 3) * i;
          const px = Math.cos(a) * hr;
          const py = Math.sin(a) * hr;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();

      // Floating Tactical Health Bar & Mode Badge
      const barW = 52;
      const bx = h.x - barW / 2;
      const by = h.y - 32;

      // Mode Badge Pill
      ctx.fillStyle = h.mode === 'SIEGE' ? "#ffd600" : "#00e5ff";
      ctx.beginPath();
      ctx.arc(bx - 10, by + 3, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#000";
      ctx.font = "bold 9px monospace";
      ctx.textAlign = "center";
      ctx.fillText(h.mode === 'SIEGE' ? "TNK" : "MECH", bx - 10, by + 6);

      // Shield Dome Bar if active
      if (h.shieldDome && h.shieldDome.timer > 0) {
        const shPct = Math.max(0, h.shieldDome.hp / h.shieldDome.maxHp);
        ctx.fillStyle = "#003366";
        ctx.fillRect(bx, by - 6, barW, 4);
        ctx.fillStyle = "#00e5ff";
        ctx.fillRect(bx, by - 6, barW * shPct, 4);
      }

      // Health Bar Chassis
      ctx.fillStyle = "#090e17";
      ctx.fillRect(bx, by, barW, 6);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.5)";
      ctx.lineWidth = 1;
      ctx.strokeRect(bx, by, barW, 6);

      const hpPct = Math.max(0, h.hp / h.maxHp);
      ctx.fillStyle = hpPct > 0.3 ? "#00e676" : "#ff1744";
      ctx.fillRect(bx, by, barW * hpPct, 6);
    }

    renderTowers() {
      const map = (this.gameMode === 'CUSTOM') ? { modifier: "none" } : MAPS[this.currentMapIndex];
      const ctx = this.ctx;

      for (const t of this.towers) {
        const def = TOWER_DEFS[t.type];
        const spec = t.branch ? def.branches[t.branch] : def.tiers[t.tier - 1];

        // 1. Selection Range Indicator
        if (this.selectedTower === t) {
          const mapFog = (map.modifier === 'fog') ? 0.85 : 1.0;
          const range = (spec.range || 130) * (t.buffRange || 1.0) * mapFog;
          ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
          ctx.fillStyle = "rgba(0, 229, 255, 0.08)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(t.x, t.y, range, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }

        // Overclock Aura
        if (this.skills.overclock.activeTime > 0) {
          ctx.strokeStyle = "rgba(255, 214, 0, 0.65)";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(t.x, t.y, 28, 0, Math.PI * 2);
          ctx.stroke();
        }

        // 2. Heavy Cast-Titanium Octagonal Pedestal Base
        const color = t.branch ? spec.color : def.color;
        const baseGrad = ctx.createLinearGradient(t.x - 24, t.y - 24, t.x + 24, t.y + 24);
        baseGrad.addColorStop(0, "#334155"); // specular top edge
        baseGrad.addColorStop(0.4, "#1e293b"); // gunmetal body
        baseGrad.addColorStop(1, "#090d16"); // dark shadow edge
        ctx.fillStyle = baseGrad;
        ctx.strokeStyle = color;
        ctx.lineWidth = t.branch ? 3 : 2;
        ctx.beginPath();
        const r = 24;
        for (let i = 0; i < 8; i++) {
          const a = (Math.PI / 4) * i;
          const px = t.x + Math.cos(a) * r;
          const py = t.y + Math.sin(a) * r;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // 45-degree Inner Bevel Ring
        ctx.strokeStyle = "rgba(100, 116, 139, 0.5)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let i = 0; i < 8; i++) {
          const a = (Math.PI / 4) * i;
          const px = t.x + Math.cos(a) * 19;
          const py = t.y + Math.sin(a) * 19;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();

        // Stainless Steel Mounting Hex Bolts
        ctx.fillStyle = "#cbd5e1";
        for (let i = 0; i < 4; i++) {
          const a = (Math.PI / 2) * i + Math.PI / 4;
          const bx = t.x + Math.cos(a) * 16;
          const by = t.y + Math.sin(a) * 16;
          ctx.fillRect(bx - 2, by - 2, 4, 4);
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(bx - 1, by - 1, 1.5, 1.5);
          ctx.fillStyle = "#cbd5e1";
        }

        // Turret Mounting Collar Ring
        ctx.fillStyle = "#090d16";
        ctx.beginPath();
        ctx.arc(t.x, t.y, 11, 0, Math.PI * 2);
        ctx.fill();

        // 3. Rotating Turret Head Assembly with Physical Recoil Kickback
        ctx.save();
        ctx.translate(t.x, t.y);
        ctx.rotate(t.angle);

        // Apply physical barrel recoil kickback
        const recoilKick = (t.recoil || 0) * 6;
        ctx.translate(-recoilKick, 0);

        ctx.fillStyle = color;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;

        if (t.type === 'pulse') {
          if (t.branch === 'A') {
            // Gatling Shredder: 6-Barrel Rotary Minigun with Heat Glow
            const spin = t.barrelSpin || 0;
            ctx.fillStyle = "#334155";
            ctx.fillRect(0, -7, 24, 14);
            ctx.strokeStyle = "#64748b";
            ctx.strokeRect(0, -7, 24, 14);

            // Brass ammunition feed chute
            ctx.fillStyle = "#ffd54f";
            ctx.fillRect(-6, -4, 6, 8);

            // 6 Rotating Fluted Barrels
            ctx.fillStyle = "#0f172a";
            for (let b = 0; b < 6; b++) {
              const ba = spin + (Math.PI / 3) * b;
              const by = Math.sin(ba) * 5;
              ctx.fillRect(24, by - 1.2, 8, 2.4);
              // Barrel tip heat glow
              if (t.heat > 0) {
                ctx.fillStyle = `rgba(255, 109, 0, ${t.heat})`;
                ctx.fillRect(30, by - 1.2, 2.5, 2.4);
                ctx.fillStyle = "#0f172a";
              }
            }
          } else if (t.branch === 'B') {
            // Sniper Rail-Pulse: Ultra-Long Anti-Materiel Rifle
            ctx.fillStyle = "#1e293b";
            ctx.fillRect(-7, -6, 16, 12);
            ctx.strokeRect(-7, -6, 16, 12);

            // Long fluted barrel
            ctx.fillStyle = "#00b0ff";
            ctx.fillRect(9, -2.5, 34, 5);
            // Heavy muzzle compensator
            ctx.fillStyle = "#334155";
            ctx.fillRect(40, -4, 5, 8);

            // Holographic Optic Scope with Specular Lens Glint
            ctx.fillStyle = "#ffd600";
            ctx.fillRect(14, -6, 12, 3.5);
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(24, -6, 2, 3.5);
          } else {
            // Dual Autocannon Barrels with Slotted Muzzle Brakes
            ctx.fillStyle = color;
            ctx.fillRect(2, -7, 22, 5);
            ctx.fillRect(2, 2, 22, 5);
            // Slotted muzzle brakes
            ctx.fillStyle = "#0f172a";
            ctx.fillRect(20, -8, 3, 7);
            ctx.fillRect(20, 1, 3, 7);

            // Receiver chassis
            ctx.fillStyle = "#1e293b";
            ctx.fillRect(-8, -8, 16, 16);
            ctx.strokeStyle = "#475569";
            ctx.strokeRect(-8, -8, 16, 16);
          }
        } else if (t.type === 'mortar') {
          if (t.branch === 'A') {
            // Cluster Bomb: Quad Rocket Pod with Warheads
            ctx.fillStyle = "#334155";
            ctx.fillRect(-8, -11, 24, 22);
            ctx.strokeStyle = "#ff9100";
            ctx.strokeRect(-8, -11, 24, 22);

            // 4 Armed Missile Cells with Red Warheads
            ctx.fillStyle = "#ff1744";
            ctx.fillRect(16, -9, 4, 5);
            ctx.fillRect(16, -2, 4, 5);
            ctx.fillRect(16, 5, 4, 5);
          } else if (t.branch === 'B') {
            // Napalm Cyber-Fire: Heavy Fuel Tanks & Pilot Flame Igniter
            ctx.fillStyle = "#334155";
            ctx.fillRect(-6, -10, 22, 20);
            // Pressurized dual fuel tanks
            ctx.fillStyle = "#ff3d00";
            ctx.fillRect(-11, -8, 6, 16);
            ctx.strokeStyle = "#ffd600";
            ctx.lineWidth = 1;
            ctx.strokeRect(-11, -8, 6, 16);

            // Pilot Igniter Nozzle
            ctx.fillStyle = "#ffd600";
            ctx.fillRect(16, -2.5, 9, 5);
          } else {
            // Heavy Howitzer Artillery Cannon with Hydraulic Recoil Dampers
            ctx.fillStyle = color;
            ctx.fillRect(-5, -8, 25, 16);
            // Bore cavity
            ctx.fillStyle = "#0a0a0f";
            ctx.fillRect(18, -6, 3, 12);

            // Hydraulic dampener cylinders
            ctx.fillStyle = "#1e293b";
            ctx.fillRect(-10, -10, 14, 20);
            ctx.fillStyle = "#94a3b8";
            ctx.fillRect(-2, -11, 8, 2);
            ctx.fillRect(-2, 9, 8, 2);
          }
        } else if (t.type === 'cryo') {
          if (t.branch === 'A') {
            // Blizzard Zero: Crystalline Faceted Spire
            const cryoGrad = ctx.createLinearGradient(18, 0, -8, 0);
            cryoGrad.addColorStop(0, "#ffffff");
            cryoGrad.addColorStop(0.5, "#00f0ff");
            cryoGrad.addColorStop(1, "#0066cc");
            ctx.fillStyle = cryoGrad;
            ctx.beginPath();
            ctx.moveTo(20, 0); ctx.lineTo(-8, -11); ctx.lineTo(-3, 0); ctx.lineTo(-8, 11);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 1.2;
            ctx.stroke();
          } else if (t.branch === 'B') {
            // Tesla Chain-Frost: Dual Copper Inductor Prongs
            ctx.fillStyle = "#334155";
            ctx.fillRect(-6, -9, 16, 18);
            ctx.strokeStyle = "#76ff03";
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(10, -7); ctx.lineTo(25, -4);
            ctx.moveTo(10, 7); ctx.lineTo(25, 4);
            ctx.stroke();
            // Ceramic insulators
            ctx.fillStyle = "#ffd600";
            ctx.fillRect(12, -8, 3, 3);
            ctx.fillRect(12, 5, 3, 3);
          } else {
            // Cryogenic Sphere with Liquid Nitrogen Core
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(0, 0, 13, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.fillStyle = "#ffffff";
            ctx.beginPath();
            ctx.arc(-3, -3, 3.5, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (t.type === 'railgun') {
          if (t.branch === 'A') {
            // Hyper Beam Laser: Optical Prism Array
            ctx.fillStyle = "#ff007f";
            ctx.fillRect(0, -4, 32, 8);
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(30, -6, 6, 12);
            ctx.strokeStyle = "#ff4081";
            ctx.strokeRect(0, -4, 32, 8);
          } else if (t.branch === 'B') {
            // Ion Disrupter: Triple Toroidal Rings
            ctx.fillStyle = "#d500f9";
            ctx.fillRect(0, -3, 28, 6);
            ctx.strokeStyle = "#e040fb";
            ctx.lineWidth = 2;
            for (let r = 8; r <= 24; r += 8) {
              ctx.strokeRect(r, -6, 3, 12);
            }
          } else {
            // Parallel Magnetic Acceleration Rails
            ctx.fillStyle = color;
            ctx.fillRect(0, -3.5, 32, 7);
            ctx.fillStyle = "#334155";
            ctx.fillRect(-8, -8, 14, 16);
            // Electromagnetic Induction Coils
            ctx.fillStyle = "#ffd600";
            ctx.fillRect(10, -6, 4, 12);
            ctx.fillRect(20, -6, 4, 12);
          }
        } else if (t.type === 'beacon') {
          if (t.branch === 'A') {
            // Overcharge Reactor: Arcing Lightning Sphere
            const spGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, 15);
            spGrad.addColorStop(0, "#ffffff");
            spGrad.addColorStop(0.5, "#b388ff");
            spGrad.addColorStop(1, "#651fff");
            ctx.fillStyle = spGrad;
            ctx.beginPath();
            ctx.arc(0, 0, 15, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#ffd600";
            ctx.lineWidth = 2;
            ctx.stroke();
          } else if (t.branch === 'B') {
            // Tactical Radar: 360-Degree Rotating Dish
            ctx.fillStyle = "#e040fb";
            ctx.beginPath();
            ctx.arc(0, 0, 15, -Math.PI / 3, Math.PI / 3);
            ctx.lineTo(0, 0);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.stroke();
          } else {
            // Satellite Power Crystal
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(0, 0, 14, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(-2, -2, 4, 4);
          }
        } else if (t.type === 'tesla') {
          if (t.branch === 'A') {
            // Overcharge Arc: Triple High-Frequency Induction Coils
            ctx.fillStyle = "#334155";
            ctx.fillRect(-8, -10, 16, 20);
            ctx.strokeStyle = "#ffd600";
            ctx.lineWidth = 2;
            ctx.strokeRect(-8, -10, 16, 20);
            for (let c = -6; c <= 6; c += 6) {
              ctx.fillStyle = "#ffb300";
              ctx.fillRect(-6, c - 2, 12, 4);
            }
            ctx.fillStyle = "#ffffff";
            ctx.beginPath();
            ctx.arc(10, 0, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#00e5ff";
            ctx.lineWidth = 2;
            ctx.stroke();
          } else if (t.branch === 'B') {
            // Tesla Storm Aura: Quad Corona Emitters
            const spinAura = performance.now() * 0.004;
            ctx.fillStyle = "#1e293b";
            ctx.beginPath();
            ctx.arc(0, 0, 12, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#76ff03";
            ctx.lineWidth = 2.2;
            ctx.stroke();
            for (let k = 0; k < 4; k++) {
              const a = spinAura + (Math.PI / 2) * k;
              ctx.strokeStyle = "#ffd600";
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.moveTo(0, 0);
              ctx.lineTo(Math.cos(a) * 18, Math.sin(a) * 18);
              ctx.stroke();
              ctx.fillStyle = "#ffffff";
              ctx.beginPath();
              ctx.arc(Math.cos(a) * 18, Math.sin(a) * 18, 3, 0, Math.PI * 2);
              ctx.fill();
            }
          } else {
            // Standard Tesla Coil: Porcelain Insulator & Copper Toroid
            ctx.fillStyle = "#e2e8f0";
            ctx.fillRect(-6, -8, 12, 16);
            ctx.strokeStyle = "#64748b";
            ctx.lineWidth = 1;
            ctx.strokeRect(-6, -8, 12, 16);
            ctx.fillStyle = "#d97706";
            ctx.fillRect(-5, -6, 10, 3);
            ctx.fillRect(-5, -1, 10, 3);
            ctx.fillRect(-5, 4, 10, 3);
            ctx.fillStyle = "#ffd600";
            ctx.beginPath();
            ctx.arc(6, 0, 8, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 1.5;
            ctx.stroke();
            if (Math.random() < 0.4) {
              ctx.strokeStyle = "#ffffff";
              ctx.lineWidth = 1.2;
              ctx.beginPath();
              ctx.moveTo(6, 0);
              ctx.lineTo(6 + (Math.random() * 14 - 7), (Math.random() * 14 - 7));
              ctx.stroke();
            }
          }
        } else if (t.type === 'flame') {
          if (t.branch === 'A') {
            // Napalm Inferno: Heavy Pressurized Fuel Cells
            ctx.fillStyle = "#1e293b";
            ctx.fillRect(-8, -12, 18, 24);
            ctx.strokeStyle = "#ff3d00";
            ctx.lineWidth = 2;
            ctx.strokeRect(-8, -12, 18, 24);
            ctx.fillStyle = "#ff1744";
            ctx.fillRect(-14, -10, 6, 6);
            ctx.fillRect(-14, -3, 6, 6);
            ctx.fillRect(-14, 4, 6, 6);
            ctx.fillStyle = "#0f172a";
            ctx.fillRect(10, -6, 16, 12);
            ctx.fillStyle = "#ff9100";
            ctx.fillRect(24, -4, 4, 8);
          } else if (t.branch === 'B') {
            // Plasma Blaze: Superconducting Magnetic Injector
            ctx.fillStyle = "#0f172a";
            ctx.fillRect(-6, -9, 16, 18);
            ctx.strokeStyle = "#00e5ff";
            ctx.lineWidth = 2;
            ctx.strokeRect(-6, -9, 16, 18);
            ctx.fillStyle = "#00e5ff";
            ctx.fillRect(10, -5, 18, 4);
            ctx.fillRect(10, 1, 18, 4);
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 1.5;
            ctx.strokeRect(16, -7, 4, 14);
          } else {
            // Twin Pressurized Fuel Cylinders & Combustion Nozzles
            ctx.fillStyle = "#334155";
            ctx.fillRect(-6, -9, 16, 18);
            ctx.fillStyle = "#ff3d00";
            ctx.fillRect(-12, -7, 6, 6);
            ctx.fillRect(-12, 1, 6, 6);
            ctx.fillStyle = "#1e293b";
            ctx.fillRect(10, -6, 14, 4);
            ctx.fillRect(10, 2, 14, 4);
            ctx.fillStyle = "#00e5ff";
            ctx.fillRect(22, -5.5, 3, 3);
            ctx.fillRect(22, 2.5, 3, 3);
          }
        }
        ctx.restore();

        // Render Active Tesla Chain Lightning Arcs
        if (t.lightningArcs && t.lightningArcs.points.length >= 2) {
          ctx.save();
          const pts = t.lightningArcs.points;
          ctx.strokeStyle = (t.branch === 'B') ? "#76ff03" : "#ffd600";
          ctx.lineWidth = 2.5;
          ctx.shadowColor = "#ffffff";
          ctx.shadowBlur = 8;
          for (let pIdx = 0; pIdx < pts.length - 1; pIdx++) {
            const p1 = pts[pIdx];
            const p2 = pts[pIdx + 1];
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            const midX1 = p1.x + (p2.x - p1.x) * 0.33 + (Math.random() * 16 - 8);
            const midY1 = p1.y + (p2.y - p1.y) * 0.33 + (Math.random() * 16 - 8);
            const midX2 = p1.x + (p2.x - p1.x) * 0.66 + (Math.random() * 16 - 8);
            const midY2 = p1.y + (p2.y - p1.y) * 0.66 + (Math.random() * 16 - 8);
            ctx.lineTo(midX1, midY1);
            ctx.lineTo(midX2, midY2);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
          ctx.restore();
        }

        // 4. Tier Markers (Stars)
        ctx.fillStyle = "#ffd600";
        for (let i = 0; i < t.tier; i++) {
          ctx.beginPath();
          ctx.arc(t.x - 12 + i * 12, t.y + 16, 3, 0, Math.PI * 2);
          ctx.fill();
        }

        // 5. Laser Beam FX
        if (t.laserTimer > 0 && t.targetPoint) {
          ctx.strokeStyle = (t.branch === 'A') ? "rgba(255, 0, 127, 0.9)" : `rgba(213, 0, 249, ${t.laserTimer / 0.25})`;
          ctx.lineWidth = (t.branch === 'A') ? 8 : 5;
          ctx.beginPath();
          ctx.moveTo(t.x, t.y);
          ctx.lineTo(t.targetPoint.x, t.targetPoint.y);
          ctx.stroke();
        }
      }
    }

    renderEnemies() {
      const ctx = this.ctx;

      for (const e of this.enemies) {
        ctx.save();
        ctx.translate(e.x, e.y);

        if (e.isFlyer) {
          if (e.type === 'gunship') {
            // VTOL Heavy Aerial Gunship
            ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
            ctx.beginPath();
            ctx.ellipse(4, 22, 18, 9, e.angle, 0, Math.PI * 2);
            ctx.fill();

            ctx.rotate(e.angle);
            const rotorSpin = performance.now() * 0.04;

            // Fuselage
            const gunGrad = ctx.createLinearGradient(-16, -10, 18, 10);
            gunGrad.addColorStop(0, "#334155");
            gunGrad.addColorStop(0.5, "#1e293b");
            gunGrad.addColorStop(1, "#0f172a");
            ctx.fillStyle = gunGrad;
            ctx.beginPath();
            ctx.moveTo(18, 0);
            ctx.lineTo(8, -9);
            ctx.lineTo(-14, -7);
            ctx.lineTo(-18, 0);
            ctx.lineTo(-14, 7);
            ctx.lineTo(8, 9);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = "#00e5ff";
            ctx.lineWidth = 1.8;
            ctx.stroke();

            // Wings & Tilt-Rotor Nacelles
            ctx.fillStyle = "#475569";
            ctx.fillRect(-4, -18, 6, 36);
            ctx.fillStyle = "#0f172a";
            ctx.fillRect(-2, -21, 6, 5);
            ctx.fillRect(-2, 16, 6, 5);

            // Spinning Rotors
            ctx.strokeStyle = "rgba(0, 229, 255, 0.85)";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(-2 + Math.cos(rotorSpin) * 12, -18 + Math.sin(rotorSpin) * 12);
            ctx.lineTo(-2 - Math.cos(rotorSpin) * 12, -18 - Math.sin(rotorSpin) * 12);
            ctx.moveTo(-2 + Math.cos(-rotorSpin) * 12, 18 + Math.sin(-rotorSpin) * 12);
            ctx.lineTo(-2 - Math.cos(-rotorSpin) * 12, 18 - Math.sin(-rotorSpin) * 12);
            ctx.stroke();

            // Chin nose cannon & cockpit
            ctx.fillStyle = "#ffd600";
            ctx.fillRect(16, -1.5, 7, 3);
            ctx.fillStyle = "#ffffff";
            ctx.beginPath(); ctx.arc(6, 0, 3, 0, Math.PI * 2); ctx.fill();

            // HP Bar & Shield Bar
            ctx.rotate(-e.angle);
            const fHpPct = Math.max(0, e.hp / e.maxHp);
            ctx.fillStyle = "#263238";
            ctx.fillRect(-16, -24, 32, 4);
            ctx.fillStyle = "#00e5ff";
            ctx.fillRect(-16, -24, 32 * fHpPct, 4);
            if (e.shield > 0) {
              const shPct = Math.max(0, e.shield / (e.maxShield || 100));
              ctx.fillStyle = "#00b0ff";
              ctx.fillRect(-16, -29, 32 * shPct, 3);
            }
            ctx.restore();
            continue;
          }

          // Aerial Jet Shadow
          ctx.fillStyle = "rgba(0, 0, 0, 0.25)";
          ctx.beginPath();
          ctx.ellipse(4, 18, 14, 7, e.angle, 0, Math.PI * 2);
          ctx.fill();

          // Aerial Jet Silhouette
          ctx.rotate(e.angle);
          ctx.fillStyle = e.color || "#00e5ff";
          ctx.beginPath();
          ctx.moveTo(14, 0);
          ctx.lineTo(-10, -11);
          ctx.lineTo(-6, 0);
          ctx.lineTo(-10, 11);
          ctx.closePath();
          ctx.fill();

          // Cockpit glow
          ctx.fillStyle = "#ffffff";
          ctx.beginPath();
          ctx.arc(2, 0, 3, 0, Math.PI * 2);
          ctx.fill();

          // HP Bar
          ctx.rotate(-e.angle);
          const fHpPct = Math.max(0, e.hp / e.maxHp);
          ctx.fillStyle = "#263238";
          ctx.fillRect(-14, -20, 28, 4);
          ctx.fillStyle = fHpPct > 0.4 ? "#00e5ff" : "#ff1744";
          ctx.fillRect(-14, -20, 28 * fHpPct, 4);
          ctx.restore();
          continue;
        }

        if (e.phased) ctx.globalAlpha = 0.25;

        // Slow Frost Field Aura
        if (e.slowTimer > 0) {
          ctx.strokeStyle = "#00f0ff";
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, 0, e.size + 6, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Energy Shield Dome
        if (e.shield > 0) {
          ctx.strokeStyle = "rgba(0, 176, 255, 0.85)";
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, 0, e.size + 8, 0, Math.PI * 2);
          ctx.stroke();
        }

        // --- HIGH-FIDELITY PROCEDURAL CHARACTER DESIGNS ---
        if (e.type === 'grunt') {
          // Cyborg Mercenary Infantry Trooper
          const walk = Math.sin(e.walkAnim || 0) * 3.5;
          ctx.rotate(e.angle);

          // Articulated combat boots
          ctx.fillStyle = "#0f172a";
          ctx.fillRect(-8 + walk, -7, 6, 4);
          ctx.fillRect(-8 - walk, 3, 6, 4);

          // Ballistic Kevlar Chest Rig
          const chestGrad = ctx.createLinearGradient(-6, -6, 6, 6);
          chestGrad.addColorStop(0, "#475569");
          chestGrad.addColorStop(1, "#1e293b");
          ctx.fillStyle = chestGrad;
          ctx.fillRect(-6, -6, 12, 12);
          ctx.strokeStyle = e.color;
          ctx.lineWidth = 1.8;
          ctx.strokeRect(-6, -6, 12, 12);

          // Tactical Helmet with Glowing Night-Vision Visor
          ctx.fillStyle = "#0f172a";
          ctx.beginPath();
          ctx.arc(4, 0, 4.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#00e5ff"; // glowing cyan NVG visor
          ctx.fillRect(4, -2.5, 3, 5);

          // Assault Carbine with Muzzle Compensator
          ctx.fillStyle = "#334155";
          ctx.fillRect(5, 3, 11, 2.5);
          ctx.fillStyle = "#64748b";
          ctx.fillRect(14, 2, 3, 4.5);
        } else if (e.type === 'sprinter') {
          // Cyber-Hound / Predatory Stalker Mech
          const run = Math.sin(e.walkAnim || 0) * 5.5;
          ctx.rotate(e.angle);

          // 4 Articulated Digitigrade Legs with Titanium Talons
          ctx.fillStyle = "#1e293b";
          ctx.fillRect(-9 + run, -9, 5, 3.5);
          ctx.fillRect(-9 - run, 6, 5, 3.5);
          ctx.fillRect(5 - run, -10, 5, 3.5);
          ctx.fillRect(5 + run, 7, 5, 3.5);

          // Sleek Aerodynamic Carbon-Fiber Hull
          const stalkerGrad = ctx.createLinearGradient(-11, -8, 14, 8);
          stalkerGrad.addColorStop(0, "#451a03");
          stalkerGrad.addColorStop(1, "#1c1917");
          ctx.fillStyle = stalkerGrad;
          ctx.beginPath();
          ctx.moveTo(14, 0); ctx.lineTo(-11, -8); ctx.lineTo(-7, 0); ctx.lineTo(-11, 8);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = e.color;
          ctx.lineWidth = 1.8;
          ctx.stroke();

          // Triple Glowing Crimson Sensor Cluster
          ctx.fillStyle = "#ff1744";
          ctx.fillRect(7, -2.5, 4, 5);

          // Dorsal Thruster Heat Vents
          ctx.fillStyle = "#ff9100";
          ctx.fillRect(-13, -5, 3, 3);
          ctx.fillRect(-13, 2, 3, 3);
        } else if (e.type === 'brute') {
          // Goliath Heavy War-Mech
          const stomp = Math.sin(e.walkAnim || 0) * 3.5;
          ctx.rotate(e.angle);

          // Heavy Hydraulic Stomping Legs
          ctx.fillStyle = "#0f172a";
          ctx.fillRect(-15 + stomp, -17, 9, 7);
          ctx.fillRect(-15 - stomp, 11, 9, 7);

          // Heavy Bolted Frontal Glacis Armor
          const bruteGrad = ctx.createLinearGradient(-13, -14, 13, 14);
          bruteGrad.addColorStop(0, "#334155");
          bruteGrad.addColorStop(0.5, "#1e293b");
          bruteGrad.addColorStop(1, "#090d16");
          ctx.fillStyle = bruteGrad;
          ctx.fillRect(-13, -14, 24, 28);
          ctx.strokeStyle = e.color;
          ctx.lineWidth = 2.8;
          ctx.strokeRect(-13, -14, 24, 28);

          // Yellow/Black Hazard Warning Chevron Stripes
          ctx.fillStyle = "#ffd600";
          ctx.fillRect(-11, -12, 4, 24);
          ctx.fillStyle = "#000000";
          ctx.fillRect(-5, -12, 4, 24);

          // Dual Vertical Exhaust Smokestacks
          ctx.fillStyle = "#475569";
          ctx.fillRect(-15, -13, 4, 6);
          ctx.fillRect(-15, 7, 4, 6);

          // Heavy Pneumatic Ram Arms
          ctx.fillStyle = "#64748b";
          ctx.fillRect(7, -18, 15, 6);
          ctx.fillRect(7, 13, 15, 6);

          // Glowing Thermal Intake Grille
          ctx.fillStyle = "#ff1744";
          ctx.fillRect(5, -3.5, 7, 7);
        } else if (e.type === 'swarmling') {
          // Nano-Drone Cyber-Arachnid
          ctx.rotate(e.angle);
          const walkS = Math.sin(performance.now() * 0.02) * 3;

          // 6 Articulated Chitinous Legs
          ctx.strokeStyle = "#ffab00";
          ctx.lineWidth = 1.5;
          for (let i = 0; i < 3; i++) {
            const legY = -7 + i * 7;
            ctx.beginPath();
            ctx.moveTo(-2, legY); ctx.lineTo(-8, legY + (i % 2 === 0 ? walkS : -walkS)); ctx.lineTo(-12, legY + (i % 2 === 0 ? walkS * 1.5 : -walkS * 1.5));
            ctx.moveTo(2, legY); ctx.lineTo(8, legY + (i % 2 === 0 ? -walkS : walkS)); ctx.lineTo(12, legY + (i % 2 === 0 ? -walkS * 1.5 : walkS * 1.5));
            ctx.stroke();
          }

          // Armored Chitin Carapace
          ctx.fillStyle = "#0f172a";
          ctx.beginPath();
          ctx.moveTo(9, 0); ctx.lineTo(0, -7); ctx.lineTo(-8, 0); ctx.lineTo(0, 7);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = e.color;
          ctx.lineWidth = 1.6;
          ctx.stroke();

          // Compound Crimson Eyes & Titanium Mandibles
          ctx.fillStyle = "#ff1744";
          ctx.fillRect(1, -2, 3.5, 4);
        } else if (e.type === 'shieldbearer') {
          // Aegis Paladin Android with Holographic Hex-Pavise Shield
          ctx.rotate(e.angle);

          // Heavy Titanium Android Chassis
          ctx.fillStyle = "#1e293b";
          ctx.fillRect(-11, -10, 15, 20);
          ctx.strokeStyle = "#00b0ff";
          ctx.lineWidth = 1.8;
          ctx.strokeRect(-11, -10, 15, 20);

          // Core Conduit
          ctx.fillStyle = "#00e5ff";
          ctx.fillRect(0, -2.5, 4, 5);

          // Massive Curved Holographic Hexagonal Shield Barrier
          ctx.strokeStyle = "rgba(0, 176, 255, 0.95)";
          ctx.fillStyle = "rgba(0, 229, 255, 0.28)";
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(11, 0, 20, -Math.PI / 2.2, Math.PI / 2.2);
          ctx.stroke();
          ctx.fill();

          // Titanium Shield Emitter Node
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(9, -2.5, 4, 5);
        } else if (e.type === 'medic') {
          // Nanite Bio-Synth Medical Drone
          ctx.rotate(e.angle);
          const bob = Math.sin(performance.now() * 0.005) * 2;

          // Composite Aerodynamic Hull
          ctx.fillStyle = "#064e3b";
          ctx.beginPath();
          ctx.arc(0, bob, 11, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = "#00e676";
          ctx.lineWidth = 2.2;
          ctx.stroke();

          // Illuminated Medical Cross Insignia
          ctx.fillStyle = "#00e676";
          ctx.fillRect(-2.5, bob - 7, 5, 14);
          ctx.fillRect(-7, bob - 2.5, 14, 5);

          // Orbiting Repair Nanite Spheres
          const orbit = performance.now() * 0.004;
          for (let i = 0; i < 4; i++) {
            const a = orbit + (Math.PI / 2) * i;
            ctx.fillStyle = "#69f0ae";
            ctx.beginPath();
            ctx.arc(Math.cos(a) * 16, Math.sin(a) * 16 + bob, 3, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (e.type === 'splitter') {
          // Fracture Crystal Incubator
          const pulse = Math.sin(performance.now() * 0.008) * 2;
          const spin = performance.now() * 0.003;

          // 4 Orbiting Crystalline Magnetic Shards
          ctx.fillStyle = "#1e1b4b";
          ctx.strokeStyle = "#e040fb";
          ctx.lineWidth = 1.8;
          for (let i = 0; i < 4; i++) {
            const a = spin + (Math.PI / 2) * i;
            const cx = Math.cos(a) * 17;
            const cy = Math.sin(a) * 17;
            ctx.fillRect(cx - 3.5, cy - 3.5, 7, 7);
            ctx.strokeRect(cx - 3.5, cy - 3.5, 7, 7);
          }

          // Glowing Volatile Core
          ctx.fillStyle = "#f43f5e";
          ctx.beginPath();
          ctx.arc(0, 0, 9 + pulse, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#ffd600";
          ctx.beginPath();
          ctx.arc(0, 0, 4.5, 0, Math.PI * 2);
          ctx.fill();
        } else if (e.type === 'phantom') {
          // Stealth Ghost Infiltrator with Optical Camouflage
          const shimmer = Math.sin(performance.now() * 0.01) * 3;
          ctx.rotate(e.angle);

          // Chromatic Aberration Silhouette
          ctx.fillStyle = "rgba(255, 0, 127, 0.4)";
          ctx.fillRect(-9 + shimmer, -7, 15, 14);
          ctx.fillStyle = "rgba(0, 229, 255, 0.4)";
          ctx.fillRect(-9 - shimmer, -7, 15, 14);

          // Sleek Stealth Cowl
          ctx.fillStyle = "rgba(124, 77, 255, 0.75)";
          ctx.beginPath();
          ctx.moveTo(11, 0); ctx.lineTo(-11, -8); ctx.lineTo(-7, 0); ctx.lineTo(-11, 8);
          ctx.closePath();
          ctx.fill();

          // Dual Vibro-Daggers with Electric Arc Tips
          ctx.strokeStyle = "#00e5ff";
          ctx.lineWidth = 2.2;
          ctx.beginPath();
          ctx.moveTo(9, -6); ctx.lineTo(18, -2.5);
          ctx.moveTo(9, 6); ctx.lineTo(18, 2.5);
          ctx.stroke();
        } else if (e.type === 'kamikaze') {
          // Volatile Spider Drone with Ticking LED Core
          ctx.rotate(e.angle);
          const kWalk = Math.sin(performance.now() * 0.035) * 4;
          const kPulse = Math.sin(performance.now() * 0.02) * 2;

          // 4 Skittering Legs
          ctx.strokeStyle = "#ff3d00";
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(-4, -6); ctx.lineTo(-10, -12 + kWalk);
          ctx.moveTo(4, -6); ctx.lineTo(10, -12 - kWalk);
          ctx.moveTo(-4, 6); ctx.lineTo(-10, 12 - kWalk);
          ctx.moveTo(4, 6); ctx.lineTo(10, 12 + kWalk);
          ctx.stroke();

          // High-Explosive Body Canister
          ctx.fillStyle = "#1e293b";
          ctx.beginPath();
          ctx.arc(0, 0, 7.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // Pulsing Crimson Detonator Sphere
          ctx.fillStyle = "#ff1744";
          ctx.beginPath();
          ctx.arc(0, 0, 4 + kPulse, 0, Math.PI * 2);
          ctx.fill();

          // Hazard Warning Cross
          ctx.fillStyle = "#ffd600";
          ctx.fillRect(-1, -3, 2, 6);
          ctx.fillRect(-3, -1, 6, 2);
        } else if (e.type === 'siege_breaker') {
          // Massive Mechanized Stone/Steel Golem
          ctx.rotate(e.angle);
          const gWalk = Math.sin(e.walkAnim || 0) * 3;

          // Heavy Granite Feet
          ctx.fillStyle = "#1e1b4b";
          ctx.fillRect(-16 + gWalk, -18, 11, 8);
          ctx.fillRect(-16 - gWalk, 10, 11, 8);

          // Massive Heavy Torso with Runic Plates
          const golemGrad = ctx.createLinearGradient(-14, -14, 16, 14);
          golemGrad.addColorStop(0, "#475569");
          golemGrad.addColorStop(0.5, "#2e1065");
          golemGrad.addColorStop(1, "#0f172a");
          ctx.fillStyle = golemGrad;
          ctx.fillRect(-14, -15, 28, 30);
          ctx.strokeStyle = "#7c4dff";
          ctx.lineWidth = 2.5;
          ctx.strokeRect(-14, -15, 28, 30);

          // Glowing Violet Runic Inscription Lines
          ctx.strokeStyle = "#e040fb";
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(-6, -10); ctx.lineTo(6, 0); ctx.lineTo(-6, 10);
          ctx.moveTo(0, -10); ctx.lineTo(0, 10);
          ctx.stroke();

          // Giant Spiked Boulder Fists
          ctx.fillStyle = "#334155";
          ctx.fillRect(8, -20, 16, 9);
          ctx.fillRect(8, 11, 16, 9);
          ctx.fillStyle = "#ffd600";
          ctx.fillRect(23, -19, 4, 3);
          ctx.fillRect(23, -14, 4, 3);
          ctx.fillRect(23, 12, 4, 3);
          ctx.fillRect(23, 17, 4, 3);

          // Glowing Eye Visor
          ctx.fillStyle = "#7c4dff";
          ctx.fillRect(4, -3, 5, 6);
        } else if (e.type === 'juggernaut') {
          // BOSS 1: Colossus MK-IV Siege Fortress
          const walkB = Math.sin(e.walkAnim || 0) * 4.5;
          ctx.rotate(e.angle);

          // Continuous Heavy Tank Tread Assemblies
          ctx.fillStyle = "#090d16";
          ctx.fillRect(-24 + walkB, -26, 14, 11);
          ctx.fillRect(-24 - walkB, 15, 14, 11);
          ctx.fillRect(11 - walkB, -26, 14, 11);
          ctx.fillRect(11 + walkB, 15, 14, 11);

          // Heavy Welded Steel Armor Hull
          const colossusGrad = ctx.createLinearGradient(-20, -20, 20, 20);
          colossusGrad.addColorStop(0, "#475569");
          colossusGrad.addColorStop(0.5, "#1e293b");
          colossusGrad.addColorStop(1, "#090d16");
          ctx.fillStyle = colossusGrad;
          ctx.fillRect(-20, -20, 40, 40);
          ctx.strokeStyle = "#ff1744";
          ctx.lineWidth = 3.5;
          ctx.strokeRect(-20, -20, 40, 40);

          // Massive Dual Heavy Siege Cannons with Recoil Dampers
          ctx.fillStyle = "#334155";
          ctx.fillRect(5, -23, 24, 7);
          ctx.fillRect(5, 16, 24, 7);

          // Rotating Command Cupola & Sweeping Red Laser Searchlight
          ctx.strokeStyle = "rgba(255, 23, 68, 0.65)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(28, -20); ctx.lineTo(130, -20);
          ctx.moveTo(28, 20); ctx.lineTo(130, 20);
          ctx.stroke();

          // Core Reactor
          ctx.fillStyle = "#ff1744";
          ctx.beginPath();
          ctx.arc(3, 0, 9, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#ffd600";
          ctx.beginPath();
          ctx.arc(3, 0, 4.5, 0, Math.PI * 2);
          ctx.fill();
        } else if (e.type === 'overseer') {
          // BOSS 2: Eye of Chronos Quantum AI
          const gyro1 = performance.now() * 0.002;
          const gyro2 = performance.now() * -0.003;

          // 3 Concentric Gimbaled Titanium Rings
          ctx.strokeStyle = "rgba(101, 31, 255, 0.85)";
          ctx.lineWidth = 2.8;
          ctx.beginPath();
          ctx.ellipse(0, 0, 34, 15, gyro1, 0, Math.PI * 2);
          ctx.stroke();

          ctx.strokeStyle = "rgba(224, 64, 251, 0.85)";
          ctx.beginPath();
          ctx.ellipse(0, 0, 27, 13, gyro2, 0, Math.PI * 2);
          ctx.stroke();

          // Central Quantum Singularity Orb
          ctx.fillStyle = "#1e1b4b";
          ctx.beginPath();
          ctx.arc(0, 0, 17, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = "#d500f9";
          ctx.lineWidth = 2.2;
          ctx.stroke();

          ctx.fillStyle = "#00e5ff";
          ctx.beginPath();
          ctx.arc(0, 0, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#ffffff";
          ctx.beginPath();
          ctx.arc(2, 0, 3.5, 0, Math.PI * 2);
          ctx.fill();
        } else if (e.type === 'hive_titan') {
          // BOSS 3: Leviathan Core Bio-Mechanical Centipede
          ctx.rotate(e.angle);

          // 6 Multi-Segmented Carapace Nodes
          for (let s = 4; s >= 0; s--) {
            const sx = -s * 10;
            const segW = 28 - s * 3;
            const segH = 26 - s * 3;
            ctx.fillStyle = s % 2 === 0 ? "#1e293b" : "#374151";
            ctx.fillRect(sx - segW / 2, -segH / 2, segW, segH);
            ctx.strokeStyle = "#f50057";
            ctx.lineWidth = 2.2;
            ctx.strokeRect(sx - segW / 2, -segH / 2, segW, segH);
            // Glowing crimson spine conduits
            ctx.fillStyle = "#ff1744";
            ctx.fillRect(sx - 2, -3.5, 4, 7);
          }

          // Armored Predatory Head & Hydraulic Mandibles
          ctx.fillStyle = "#0f172a";
          ctx.beginPath();
          ctx.moveTo(15, 0); ctx.lineTo(4, -13); ctx.lineTo(4, 13);
          ctx.closePath();
          ctx.fill();

          const snap = Math.sin(performance.now() * 0.008) * 3.5;
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 2.2;
          ctx.beginPath();
          ctx.moveTo(9, -11); ctx.lineTo(21 + snap, -5);
          ctx.moveTo(9, 11); ctx.lineTo(21 + snap, 5);
          ctx.stroke();
        } else if (e.type === 'void_titan') {
          // BOSS 4: Gravitational Singularity Core & Orbit Crystals
          const tNow = performance.now() * 0.003;
          ctx.strokeStyle = "rgba(156, 39, 176, 0.75)";
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.ellipse(0, 0, 38, 20, tNow, 0, Math.PI * 2);
          ctx.stroke();

          ctx.strokeStyle = "rgba(186, 104, 200, 0.9)";
          ctx.beginPath();
          ctx.ellipse(0, 0, 30, 14, -tNow * 1.5, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = "#000000";
          ctx.beginPath();
          ctx.arc(0, 0, 22, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = "#e040fb";
          ctx.lineWidth = 3;
          ctx.stroke();

          for (let c = 0; c < 4; c++) {
            const ang = tNow * 2 + (Math.PI / 2) * c;
            const cx = Math.cos(ang) * 34;
            const cy = Math.sin(ang) * 18;
            ctx.fillStyle = "#ba68c8";
            ctx.beginPath();
            ctx.arc(cx, cy, 4, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (e.type === 'chrono_phantom') {
          // BOSS 5: Chrono Phantom Temporal Clock & Prismatic Hologram
          const tNow = performance.now() * 0.004;
          ctx.rotate(e.angle);

          ctx.strokeStyle = "#00e5ff";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(0, 0, 26, 0, Math.PI * 2);
          ctx.stroke();

          for (let g = 0; g < 8; g++) {
            const ga = tNow + (Math.PI / 4) * g;
            ctx.fillStyle = "#00e5ff";
            ctx.fillRect(Math.cos(ga) * 26 - 2, Math.sin(ga) * 26 - 2, 4, 4);
          }

          ctx.fillStyle = "rgba(0, 229, 255, 0.3)";
          ctx.beginPath();
          ctx.arc(0, 0, 18, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#ffffff";
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
        } else if (e.type === 'mecha_colossus') {
          // BOSS 6: Apex Mecha Colossus (Heavy Golden-Titanium War Machine)
          ctx.rotate(e.angle);

          ctx.fillStyle = "#1e293b";
          ctx.fillRect(-22, -26, 44, 10);
          ctx.fillRect(-22, 16, 44, 10);
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 1.8;
          ctx.strokeRect(-22, -26, 44, 10);
          ctx.strokeRect(-22, 16, 44, 10);

          ctx.fillStyle = "#0f172a";
          ctx.beginPath();
          ctx.roundRect(-20, -18, 40, 36, 6);
          ctx.fill();
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 2.5;
          ctx.stroke();

          ctx.fillStyle = "#ff1744";
          ctx.fillRect(-18, -24, 10, 6);
          ctx.fillRect(-18, 18, 10, 6);

          ctx.fillStyle = "#475569";
          ctx.fillRect(14, -8, 18, 5);
          ctx.fillRect(14, 3, 18, 5);

          ctx.fillStyle = "#ffd600";
          ctx.fillRect(4, -4, 8, 8);
        } else {
          ctx.fillStyle = e.color;
          ctx.beginPath();
          ctx.arc(0, 0, e.size, 0, Math.PI * 2);
          ctx.fill();
        }

        // Colorblind Indicator Icon
        if (this.colorblind) {
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 12px monospace";
          ctx.textAlign = "center";
          ctx.fillText(e.marker, 0, 4);
        }

        ctx.restore();

        // Modern Floating Health Bar
        const barW = Math.max(30, e.size * 2.2);
        const barH = e.isBoss ? 6 : 4;
        const bx = e.x - barW / 2;
        const by = e.y - e.size - 12;

        ctx.fillStyle = "#0a0f1d";
        ctx.fillRect(bx, by, barW, barH);
        ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
        ctx.lineWidth = 1;
        ctx.strokeRect(bx, by, barW, barH);

        const hpPct = Math.max(0, e.hp / e.maxHp);
        ctx.fillStyle = e.isBoss ? "#ff1744" : "#00e676";
        ctx.fillRect(bx, by, barW * hpPct, barH);

        if (e.maxShield > 0) {
          const shPct = Math.max(0, e.shield / e.maxShield);
          ctx.fillStyle = "#00b0ff";
          ctx.fillRect(bx, by - 3, barW * shPct, 2);
        }
      }
    }
    // --- TACTICAL DRAG-AND-DROP & MOBILE TOUCH OVERLAYS ---

    renderTacticalDragVector() {
      const ctx = this.ctx;

      // 1. Hero Drag Tactical Vector Line
      if (this.touchState.dragging === 'HERO') {
        const cur = this.touchState.dragCurrent;
        ctx.strokeStyle = "#ffd600";
        ctx.lineWidth = 2.5;
        ctx.setLineDash([8, 6]);
        ctx.beginPath();
        ctx.moveTo(this.hero.x, this.hero.y);
        ctx.lineTo(cur.x, cur.y);
        ctx.stroke();
        ctx.setLineDash([]);

        // Animated destination target reticle
        ctx.strokeStyle = "#ffd600";
        ctx.fillStyle = "rgba(255, 214, 0, 0.2)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cur.x, cur.y, 22, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#ffd600";
        ctx.font = "bold 12px monospace";
        ctx.textAlign = "center";
        ctx.fillText("TARGET", cur.x, cur.y + 4);
      }

      // 2. Tower Hotbar Drag-to-Build Ghost
      if (this.touchState.dragging === 'TOWER_HOTBAR' && this.touchState.draggedTowerType) {
        const cur = this.touchState.dragCurrent;
        const def = TOWER_DEFS[this.touchState.draggedTowerType];

        // Draw floating turret under finger
        ctx.save();
        ctx.translate(cur.x, cur.y);
        ctx.fillStyle = def.color;
        ctx.globalAlpha = 0.8;
        ctx.beginPath();
        ctx.arc(0, 0, 20, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();

        // If hovering over grid, render placement range and tile box
        if (this.hoverCell && cur.y >= 60 && cur.y <= 620) {
          const px = this.hoverCell.gx * 64 + 32;
          const py = this.hoverCell.gy * 64 + 32;
          const valid = this.hoverCell.valid;

          ctx.strokeStyle = valid ? "rgba(0, 229, 255, 0.5)" : "rgba(255, 23, 68, 0.5)";
          ctx.fillStyle = valid ? "rgba(0, 229, 255, 0.1)" : "rgba(255, 23, 68, 0.1)";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(px, py, def.tiers[0].range, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          ctx.strokeStyle = valid ? "#00e676" : "#ff1744";
          ctx.fillStyle = valid ? "rgba(0, 230, 118, 0.3)" : "rgba(255, 23, 68, 0.3)";
          ctx.fillRect(this.hoverCell.gx * 64 + 2, this.hoverCell.gy * 64 + 2, 60, 60);
          ctx.strokeRect(this.hoverCell.gx * 64 + 2, this.hoverCell.gy * 64 + 2, 60, 60);
        }
      }
    }

    renderRadialBuildWheel() {
      if (!this.radialBuildCell) return;
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const rc = this.radialBuildCell;

      rc.anim = Math.min(1.0, (rc.anim || 0) + 0.14);
      const scale = rc.anim;

      // 1. Highlight selected cell
      ctx.save();
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 2.5;
      ctx.fillStyle = "rgba(0, 229, 255, 0.22)";
      ctx.fillRect(rc.gx * 64 + 2, rc.gy * 64 + 2, 60, 60);
      ctx.strokeRect(rc.gx * 64 + 2, rc.gy * 64 + 2, 60, 60);

      // Center close button at (rc.px, rc.py)
      ctx.fillStyle = "rgba(255, 23, 68, 0.85)";
      ctx.beginPath();
      ctx.arc(rc.px, rc.py, 16 * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "center";
      ctx.fillText("✕", rc.px, rc.py + 4);

      // Rotating dashed calibration ring
      const R = 84 * scale;
      const rot = t * 1.5;
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1.6;
      ctx.setLineDash([6, 8]);
      ctx.beginPath();
      ctx.arc(rc.px, rc.py, R, rot, rot + Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      const options = [
        { key: 'pulse', icon: "⚡", label: "PULSE" },
        { key: 'mortar', icon: "💣", label: "MORTAR" },
        { key: 'cryo', icon: "❄️", label: "CRYO" },
        { key: 'tesla', icon: "⚡", label: "TESLA" },
        { key: 'flame', icon: "🔥", label: "FLAME" },
        { key: 'railgun', icon: "🎯", label: "RAILGUN" },
        { key: 'beacon', icon: "📡", label: "BEACON" },
        { key: 'barricade', icon: "🛡️", label: "TO'SIQ" }
      ];

      for (let i = 0; i < 8; i++) {
        const opt = options[i];
        const def = (opt.key === 'barricade') ? { cost: 40, color: "#ffd600" } : TOWER_DEFS[opt.key];
        const canAfford = this.gold >= def.cost;
        const ang = -Math.PI / 2 + (Math.PI * 2 / 8) * i;
        const bx = rc.px + Math.cos(ang) * R;
        const by = rc.py + Math.sin(ang) * R;
        const br = 24 * scale;

        // Connecting spoke
        ctx.strokeStyle = canAfford ? "rgba(0, 229, 255, 0.4)" : "rgba(100, 116, 139, 0.25)";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(rc.px + Math.cos(ang) * 18, rc.py + Math.sin(ang) * 18);
        ctx.lineTo(bx - Math.cos(ang) * br, by - Math.sin(ang) * br);
        ctx.stroke();

        // Orb glassmorphic fill
        const grad = ctx.createRadialGradient(bx - br * 0.3, by - br * 0.3, 0, bx, by, br);
        if (canAfford) {
          grad.addColorStop(0, "rgba(255, 255, 255, 0.35)");
          grad.addColorStop(0.3, "rgba(20, 36, 62, 0.95)");
          grad.addColorStop(1, "rgba(8, 14, 26, 0.98)");
        } else {
          grad.addColorStop(0, "rgba(255, 255, 255, 0.12)");
          grad.addColorStop(0.4, "rgba(15, 20, 28, 0.92)");
          grad.addColorStop(1, "rgba(5, 8, 14, 0.98)");
        }
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(bx, by, br, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = canAfford ? def.color : "#455a64";
        ctx.lineWidth = canAfford ? 2.0 : 1.2;
        ctx.shadowColor = canAfford ? def.color : "transparent";
        ctx.shadowBlur = canAfford ? 8 : 0;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Icon & Cost Text
        ctx.textAlign = "center";
        ctx.fillStyle = canAfford ? def.color : "#78909c";
        ctx.font = "bold 13px 'Segoe UI', monospace";
        ctx.fillText(opt.icon, bx, by - 2);

        ctx.fillStyle = canAfford ? "#ffffff" : "#607d8b";
        ctx.font = "bold 9px monospace";
        ctx.fillText(`${def.cost}g`, bx, by + 12);
      }

      ctx.restore();
    }

    renderMinimapHUD() {
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const rx = 1118;
      const ry = 62;
      const rw = 148;
      const rh = 100;
      const cut = 8;

      ctx.save();

      // Collapsed pill badge if minimized
      if (!this.minimapExpanded) {
        this.renderMiniButton(rx + rw - 85, ry, 85, 28, "📡 RADAR", "#00e5ff");
        ctx.restore();
        return;
      }

      // Frosted Glassmorphism Radar Panel Frame
      ctx.beginPath();
      ctx.moveTo(rx + cut, ry);
      ctx.lineTo(rx + rw - cut, ry);
      ctx.lineTo(rx + rw, ry + cut);
      ctx.lineTo(rx + rw, ry + rh - cut);
      ctx.lineTo(rx + rw - cut, ry + rh);
      ctx.lineTo(rx + cut, ry + rh);
      ctx.lineTo(rx, ry + rh - cut);
      ctx.lineTo(rx, ry + cut);
      ctx.closePath();

      const bgGrad = ctx.createLinearGradient(rx, ry, rx, ry + rh);
      bgGrad.addColorStop(0, "rgba(10, 20, 36, 0.94)");
      bgGrad.addColorStop(1, "rgba(4, 8, 16, 0.98)");
      ctx.fillStyle = bgGrad;
      ctx.fill();

      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 1.4;
      ctx.shadowColor = "#00e5ff";
      ctx.shadowBlur = 6;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Header Bar: "RADAR // FEED" + rec dot + minimize toggle
      ctx.fillStyle = "rgba(0, 229, 255, 0.12)";
      ctx.fillRect(rx + 1, ry + 1, rw - 2, 18);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.3)";
      ctx.strokeRect(rx + 1, ry + 1, rw - 2, 18);

      ctx.textAlign = "left";
      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 9px monospace";
      ctx.fillText("📡 RADAR // FEED", rx + 8, ry + 13);

      const recBlink = Math.sin(t * 5) > 0;
      ctx.fillStyle = recBlink ? "#00e676" : "#ff1744";
      ctx.beginPath();
      ctx.arc(rx + rw - 28, ry + 10, 3, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#78909c";
      ctx.font = "bold 9px monospace";
      ctx.fillText("▾", rx + rw - 14, ry + 13);

      // Inner Display Area: maps 1280 x 704 to inner display
      const ix = rx + 6;
      const iy = ry + 22;
      const iw = rw - 12;
      const ih = rh - 26;
      const sx = iw / 1280;
      const sy = ih / 704;

      ctx.save();
      ctx.beginPath();
      ctx.rect(ix, iy, iw, ih);
      ctx.clip();

      // Faint cyber grid inside radar screen
      ctx.strokeStyle = "rgba(0, 229, 255, 0.08)";
      ctx.lineWidth = 1;
      for (let gx = ix; gx <= ix + iw; gx += 16) {
        ctx.beginPath(); ctx.moveTo(gx, iy); ctx.lineTo(gx, iy + ih); ctx.stroke();
      }
      for (let gy = iy; gy <= iy + ih; gy += 14) {
        ctx.beginPath(); ctx.moveTo(ix, gy); ctx.lineTo(ix + iw, gy); ctx.stroke();
      }

      // Draw map lanes in glowing faint cyan
      if (this.bakedLanes) {
        ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
        ctx.lineWidth = 1.5;
        for (const lane of this.bakedLanes) {
          if (!lane || lane.length === 0) continue;
          ctx.beginPath();
          ctx.moveTo(ix + lane[0].x * sx, iy + lane[0].y * sy);
          for (let p = 1; p < lane.length; p++) {
            ctx.lineTo(ix + lane[p].x * sx, iy + lane[p].y * sy);
          }
          ctx.stroke();
        }
      }

      // Draw Towers as colored dots
      for (const tow of this.towers) {
        const def = TOWER_DEFS[tow.type];
        ctx.fillStyle = def ? def.color : "#00e5ff";
        ctx.fillRect(ix + tow.x * sx - 1.5, iy + tow.y * sy - 1.5, 3, 3);
      }

      // Draw Core Base as glowing cyan diamond
      const map = (this.gameMode === 'CUSTOM') ? (this.customMap || { basePos: { x: 19, y: 5 } }) : MAPS[this.currentMapIndex];
      const coreX = (map.basePos ? map.basePos.x * 64 + 32 : 1248) * sx;
      const coreY = (map.basePos ? map.basePos.y * 64 + 32 : 352) * sy;
      ctx.fillStyle = "#00e5ff";
      ctx.beginPath();
      ctx.arc(ix + coreX, iy + coreY, 3.5, 0, Math.PI * 2);
      ctx.fill();

      // Draw Field Hero Mech as amber blip
      if (this.hero) {
        const hx = ix + this.hero.x * sx;
        const hy = iy + this.hero.y * sy;
        ctx.fillStyle = "#ffd600";
        ctx.beginPath();
        ctx.arc(hx, hy, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Draw Enemies as glowing red dots (Bosses as pulsing yellow/red diamond)
      for (const e of this.enemies) {
        const ex = ix + e.x * sx;
        const ey = iy + e.y * sy;
        if (e.isBoss) {
          ctx.fillStyle = "#ff1744";
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(ex, ey, 4.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        } else {
          ctx.fillStyle = e.type === 'swarmling' ? "#ffab00" : (e.type === 'brute' ? "#ff007f" : "#ff5252");
          ctx.fillRect(ex - 1, ey - 1, 2.5, 2.5);
        }
      }

      // Rotating Radar Phosphor Sweep
      const sweepAng = (t * 2.8) % (Math.PI * 2);
      const sweepLen = Math.hypot(iw, ih);
      const sweepX = ix + iw * 0.5 + Math.cos(sweepAng) * sweepLen;
      const sweepY = iy + ih * 0.5 + Math.sin(sweepAng) * sweepLen;

      ctx.strokeStyle = "rgba(0, 229, 255, 0.75)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(ix + iw * 0.5, iy + ih * 0.5);
      ctx.lineTo(sweepX, sweepY);
      ctx.stroke();

      ctx.restore(); // end clip
      ctx.restore(); // end save
    }

    renderCinematicBanner() {
      if (!this.cinematicBanner || this.cinematicBanner.timer <= 0) return;
      const b = this.cinematicBanner;
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const progress = b.timer / b.duration; // 1 down to 0

      let alpha = 1.0;
      if (progress > 0.85) alpha = (1.0 - progress) / 0.15;
      else if (progress < 0.2) alpha = progress / 0.2;
      alpha = Math.max(0, Math.min(1, alpha));

      ctx.save();
      ctx.globalAlpha = alpha;

      // Red vignette on screen edges if Boss
      if (b.isBoss) {
        const pulse = Math.sin(t * 8) * 0.5 + 0.5;
        const vigGrad = ctx.createRadialGradient(640, 360, 300, 640, 360, 720);
        vigGrad.addColorStop(0, "rgba(255, 0, 0, 0)");
        vigGrad.addColorStop(1, `rgba(255, 23, 68, ${0.25 + pulse * 0.2})`);
        ctx.fillStyle = vigGrad;
        ctx.fillRect(0, 0, this.width, this.height);
      }

      // Center Banner Background (y: 205 to 300)
      const by = 205;
      const bh = 95;
      const bgGrad = ctx.createLinearGradient(0, by, 0, by + bh);
      bgGrad.addColorStop(0, "rgba(8, 14, 25, 0.94)");
      bgGrad.addColorStop(0.5, b.isBoss ? "rgba(45, 10, 20, 0.96)" : "rgba(12, 28, 48, 0.96)");
      bgGrad.addColorStop(1, "rgba(4, 7, 14, 0.98)");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, by, this.width, bh);

      // Top and Bottom Glowing Neon Hazard Borders
      ctx.strokeStyle = b.color;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.moveTo(0, by);
      ctx.lineTo(this.width, by);
      ctx.moveTo(0, by + bh);
      ctx.lineTo(this.width, by + bh);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Animated Chevron Hazard Stripes along borders
      ctx.fillStyle = b.color;
      const offset = (t * 80) % 40;
      ctx.save();
      ctx.globalAlpha = alpha * 0.45;
      for (let x = -40 + offset; x < this.width + 40; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, by);
        ctx.lineTo(x + 15, by);
        ctx.lineTo(x + 5, by + 8);
        ctx.lineTo(x - 10, by + 8);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(x, by + bh - 8);
        ctx.lineTo(x + 15, by + bh - 8);
        ctx.lineTo(x + 5, by + bh);
        ctx.lineTo(x - 10, by + bh);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      // Title Typography
      ctx.textAlign = "center";
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 16;
      ctx.fillStyle = b.isBoss ? "#ff1744" : "#ffffff";
      ctx.font = "900 28px 'Segoe UI', monospace";
      ctx.fillText(b.title, 640, by + 42);

      // Subtitle
      ctx.shadowBlur = 0;
      ctx.fillStyle = b.isBoss ? "#ffd600" : "#00e5ff";
      ctx.font = "bold 13px monospace";
      ctx.fillText(b.subtitle, 640, by + 72);

      ctx.restore();
    }

    renderMobileFloatingButtons() {
      const ctx = this.ctx;

      // 1. Floating Hero Ult Thumb Action Button (Bottom Right)
      const isUltReady = this.hero.currentUltCd <= 0;
      const ux = 1210;
      const uy = 540;
      const ur = 36;

      ctx.save();
      ctx.fillStyle = isUltReady ? "#1c355e" : "#131a29";
      ctx.beginPath();
      ctx.arc(ux, uy, ur, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = isUltReady ? "#ffd600" : "#455a64";
      ctx.lineWidth = 2.5;
      ctx.stroke();

      if (isUltReady) {
        ctx.strokeStyle = "rgba(255, 214, 0, 0.4)";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(ux, uy, ur + 4, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        // Cooldown sweep arc
        const pct = this.hero.currentUltCd / this.hero.ultCd;
        ctx.fillStyle = "rgba(255, 23, 68, 0.35)";
        ctx.beginPath();
        ctx.moveTo(ux, uy);
        ctx.arc(ux, uy, ur, -Math.PI / 2, -Math.PI / 2 + pct * Math.PI * 2);
        ctx.closePath();
        ctx.fill();
      }

      ctx.fillStyle = isUltReady ? "#ffd600" : "#90a4ae";
      ctx.font = "bold 13px monospace";
      ctx.textAlign = "center";
      ctx.fillText("⚡ ULT", ux, uy + 4);
      if (!isUltReady) {
        ctx.fillStyle = "#ff1744";
        ctx.font = "bold 10px monospace";
        ctx.fillText(`${Math.ceil(this.hero.currentUltCd)}s`, ux, uy + 17);
      }
      ctx.restore();

      // 2. Floating Wave / Speed Thumb Action Button (Bottom Right, above Ult)
      const wx = 1210;
      const wy = 450;
      const wr = 30;

      ctx.save();
      ctx.fillStyle = this.waveActive ? "#162b47" : "#00e5ff";
      ctx.beginPath();
      ctx.arc(wx, wy, wr, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = this.waveActive ? "#00e5ff" : "#05070d";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      if (!this.waveActive) {
        ctx.fillText("▶ START", wx, wy + 4);
      } else {
        ctx.fillText(`${this.speed}x SPD`, wx, wy + 4);
      }
      ctx.restore();
    }

    renderProjectiles() {
      for (const p of this.projectiles) {
        if (p.type === 'pulse') {
          // Elongated Hypervelocity Sabot Dart with Tungsten Core
          const pAngle = p.target ? Math.atan2(p.target.y - p.y, p.target.x - p.x) : 0;
          this.ctx.save();
          this.ctx.translate(p.x, p.y);
          this.ctx.rotate(pAngle);

          // Burning plasma wake trail
          this.ctx.fillStyle = "rgba(255, 214, 0, 0.4)";
          this.ctx.fillRect(-10, -2, 10, 4);

          // Outer glowing sabot sheath
          this.ctx.fillStyle = (p.branch === 'B') ? "#00e5ff" : "#ffd600";
          this.ctx.fillRect(-4, -2, 10, 4);

          // Inner white-hot kinetic core
          this.ctx.fillStyle = "#ffffff";
          this.ctx.fillRect(-2, -1, 8, 2);

          this.ctx.restore();
        } else if (p.type === 'mortar') {
          // Artillery Shell with Shadow & Fiery Rocket Exhaust
          const shadowY = p.startY + (p.targetY - p.startY) * p.t;
          const sGrad = this.ctx.createRadialGradient(p.x, shadowY, 2, p.x, shadowY, 8);
          sGrad.addColorStop(0, "rgba(0, 0, 0, 0.5)");
          sGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
          this.ctx.fillStyle = sGrad;
          this.ctx.beginPath();
          this.ctx.arc(p.x, shadowY, 8, 0, Math.PI * 2);
          this.ctx.fill();

          // Fin-stabilized mortar bomb
          this.ctx.fillStyle = "#ff9100";
          this.ctx.beginPath();
          this.ctx.arc(p.x, p.y, 6.5, 0, Math.PI * 2);
          this.ctx.fill();
          this.ctx.fillStyle = "#ffffff";
          this.ctx.fillRect(p.x - 2, p.y - 2, 4, 4);
        } else if (p.type === 'siege_shell') {
          // Heavy 120mm High-Explosive Siege Shell with Glowing Tracer
          this.ctx.save();
          this.ctx.translate(p.x, p.y);
          const sAngle = Math.atan2(p.targetY - p.startY, p.targetX - p.startX);
          this.ctx.rotate(sAngle);
          this.ctx.fillStyle = "rgba(255, 145, 0, 0.6)";
          this.ctx.fillRect(-14, -3, 14, 6);
          this.ctx.fillStyle = "#ffd600";
          this.ctx.fillRect(-6, -3, 12, 6);
          this.ctx.fillStyle = "#ffffff";
          this.ctx.fillRect(2, -1.5, 4, 3);
          this.ctx.restore();
        } else if (p.type === 'missile') {
          // Micro-Missile with Rocket Exhaust Flame
          this.ctx.save();
          this.ctx.translate(p.x, p.y);
          this.ctx.rotate(p.angle || 0);
          this.ctx.fillStyle = "#ff3d00";
          this.ctx.fillRect(-8, -1.5, 6, 3);
          this.ctx.fillStyle = "#eceff1";
          this.ctx.fillRect(-3, -2, 8, 4);
          this.ctx.fillStyle = "#ff1744";
          this.ctx.fillRect(4, -1.5, 3, 3);
          this.ctx.restore();
        }
      }
    }

    renderParticles() {
      for (const pt of this.particles) {
        if (pt.beam) {
          const alpha = Math.max(0, pt.life / pt.maxLife);
          this.ctx.fillStyle = `rgba(255, 0, 127, ${alpha * 0.7})`;
          this.ctx.fillRect(pt.x - 20, 0, 40, this.height);
          this.ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
          this.ctx.fillRect(pt.x - 6, 0, 12, this.height);
        } else {
          this.ctx.fillStyle = pt.color;
          this.ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
          this.ctx.beginPath();
          this.ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
          this.ctx.fill();
        }
      }
      this.ctx.globalAlpha = 1.0;
    }

    renderDynamicLightingLayer() {
      const ctx = this.ctx;
      const map = (this.gameMode === 'CUSTOM') ? { lanes: [this.editorWaypoints] } : MAPS[this.currentMapIndex];
      const base = map.lanes[0][map.lanes[0].length - 1];
      const time = performance.now() * 0.002;

      ctx.save();
      ctx.globalCompositeOperation = "lighter";

      // 1. Base Core Additive Light Bloom
      const hpPct = Math.max(0, this.baseHp / this.maxBaseHp);
      const coreLightGrad = ctx.createRadialGradient(base.x, base.y, 4, base.x, base.y, 90 + Math.sin(time * 3) * 10);
      const coreColor = hpPct < 0.3 ? "255, 23, 68" : "0, 229, 255";
      coreLightGrad.addColorStop(0, `rgba(${coreColor}, 0.5)`);
      coreLightGrad.addColorStop(0.4, `rgba(${coreColor}, 0.18)`);
      coreLightGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = coreLightGrad;
      ctx.beginPath();
      ctx.arc(base.x, base.y, 100, 0, Math.PI * 2);
      ctx.fill();

      // 2. Hero Arc-Reactor & Katana Light
      const h = this.hero;
      const heroLightGrad = ctx.createRadialGradient(h.x, h.y, 2, h.x, h.y, 50);
      heroLightGrad.addColorStop(0, "rgba(0, 229, 255, 0.45)");
      heroLightGrad.addColorStop(0.4, "rgba(0, 140, 255, 0.15)");
      heroLightGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = heroLightGrad;
      ctx.beginPath();
      ctx.arc(h.x, h.y, 50, 0, Math.PI * 2);
      ctx.fill();

      if (h.slashAnim > 0) {
        const bladeTipX = h.x + Math.cos(h.angle) * 32;
        const bladeTipY = h.y + Math.sin(h.angle) * 32;
        const slashLight = ctx.createRadialGradient(bladeTipX, bladeTipY, 2, bladeTipX, bladeTipY, 50);
        slashLight.addColorStop(0, "rgba(255, 255, 255, 0.75)");
        slashLight.addColorStop(0.4, "rgba(0, 229, 255, 0.4)");
        slashLight.addColorStop(1, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = slashLight;
        ctx.beginPath();
        ctx.arc(bladeTipX, bladeTipY, 50, 0, Math.PI * 2);
        ctx.fill();
      }

      // 3. Dynamic Muzzle Flashes
      for (const mf of this.muzzleFlashes) {
        const alpha = Math.min(1.0, mf.life / mf.maxLife);
        const flashGrad = ctx.createRadialGradient(mf.x, mf.y, 2, mf.x, mf.y, mf.radius);
        flashGrad.addColorStop(0, `rgba(255, 255, 255, ${alpha * 0.9})`);
        flashGrad.addColorStop(0.35, `rgba(255, 214, 0, ${alpha * 0.6})`);
        flashGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = flashGrad;
        ctx.beginPath();
        ctx.arc(mf.x, mf.y, mf.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. Flying Projectile Halos
      for (const p of this.projectiles) {
        if (p.type === 'pulse') {
          const pLight = ctx.createRadialGradient(p.x, p.y, 1, p.x, p.y, 20);
          pLight.addColorStop(0, "rgba(255, 255, 220, 0.85)");
          pLight.addColorStop(0.4, "rgba(255, 214, 0, 0.4)");
          pLight.addColorStop(1, "rgba(0, 0, 0, 0)");
          ctx.fillStyle = pLight;
          ctx.beginPath();
          ctx.arc(p.x, p.y, 20, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.type === 'mortar') {
          const mLight = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, 26);
          mLight.addColorStop(0, "rgba(255, 200, 100, 0.9)");
          mLight.addColorStop(0.5, "rgba(255, 100, 0, 0.35)");
          mLight.addColorStop(1, "rgba(0, 0, 0, 0)");
          ctx.fillStyle = mLight;
          ctx.beginPath();
          ctx.arc(p.x, p.y, 26, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 5. Cryo Aura Light
      for (const t of this.towers) {
        if (t.type === 'cryo') {
          const cryoGrad = ctx.createRadialGradient(t.x, t.y, 4, t.x, t.y, 38);
          cryoGrad.addColorStop(0, "rgba(0, 240, 255, 0.28)");
          cryoGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
          ctx.fillStyle = cryoGrad;
          ctx.beginPath();
          ctx.arc(t.x, t.y, 38, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      ctx.restore();
    }
    renderFloatingText() {
      for (const ft of this.floatingTexts) {
        this.ctx.fillStyle = ft.color;
        this.ctx.font = `bold ${ft.size}px monospace`;
        this.ctx.textAlign = "center";
        this.ctx.globalAlpha = Math.max(0, ft.life);
        this.ctx.fillText(ft.text, ft.x, ft.y);
      }
      this.ctx.globalAlpha = 1.0;
    }

    renderPlacementGhost() {
      if (this.aimingSkill) {
        this.ctx.strokeStyle = "#00e5ff";
        this.ctx.fillStyle = "rgba(0, 229, 255, 0.15)";
        this.ctx.beginPath();
        const rad = this.aimingSkill === 'emp' ? 200 : 140;
        this.ctx.arc(this.mousePos.x, this.mousePos.y, rad, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.stroke();
        return;
      }

      if (!this.selectedBuildType || !this.hoverCell) return;
      const def = TOWER_DEFS[this.selectedBuildType];
      const gx = this.hoverCell.gx;
      const gy = this.hoverCell.gy;
      const px = gx * 64 + 32;
      const py = gy * 64 + 32;

      this.ctx.strokeStyle = this.hoverCell.valid ? "rgba(0, 229, 255, 0.4)" : "rgba(255, 23, 68, 0.4)";
      this.ctx.fillStyle = this.hoverCell.valid ? "rgba(0, 229, 255, 0.08)" : "rgba(255, 23, 68, 0.08)";
      this.ctx.lineWidth = 1.5;
      this.ctx.beginPath();
      this.ctx.arc(px, py, def.tiers[0].range || 130, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.stroke();

      this.ctx.fillStyle = this.hoverCell.valid ? "rgba(0, 230, 118, 0.3)" : "rgba(255, 23, 68, 0.3)";
      this.ctx.strokeStyle = this.hoverCell.valid ? "#00e676" : "#ff1744";
      this.ctx.lineWidth = 2;
      this.ctx.fillRect(gx * 64 + 2, gy * 64 + 2, 60, 60);
      this.ctx.strokeRect(gx * 64 + 2, gy * 64 + 2, 60, 60);
    }

    renderTopHUD() {
      const ctx = this.ctx;
      // Frosted Glassmorphism Top Bar
      const topGrad = ctx.createLinearGradient(0, 0, 0, 60);
      topGrad.addColorStop(0, "rgba(12, 20, 36, 0.98)");
      topGrad.addColorStop(1, "rgba(6, 11, 20, 0.95)");
      ctx.fillStyle = topGrad;
      ctx.fillRect(0, 0, this.width, 60);

      // Glowing Neon Bottom Border
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, 60);
      ctx.lineTo(this.width, 60);
      ctx.stroke();

      // Core Health Meter with Segmented Armor Pips
      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`⬢ ${this.t("core").toUpperCase()}: ${this.baseHp}/${this.maxBaseHp}`, 16, 22);

      const hpPct = Math.max(0, this.baseHp / this.maxBaseHp);
      const barW = 125;
      const pips = 10;
      ctx.fillStyle = "rgba(10, 18, 30, 0.9)";
      ctx.fillRect(16, 30, barW, 14);
      ctx.strokeStyle = "#37474f";
      ctx.lineWidth = 1;
      ctx.strokeRect(16, 30, barW, 14);

      const fillPips = Math.round(hpPct * pips);
      const pipW = (barW - 4 - (pips - 1) * 2) / pips;
      for (let p = 0; p < pips; p++) {
        const px = 18 + p * (pipW + 2);
        if (p < fillPips) {
          ctx.fillStyle = hpPct > 0.4 ? "#00e5ff" : (hpPct > 0.2 ? "#ffd600" : "#ff1744");
        } else {
          ctx.fillStyle = "rgba(40, 55, 75, 0.4)";
        }
        ctx.fillRect(px, 32, pipW, 10);
      }

      // Currency / Tactical Gold
      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 16px monospace";
      ctx.fillText(`⚡ ${this.gold}G`, 155, 36);

      // Score
      ctx.fillStyle = "#90a4ae";
      ctx.font = "11px monospace";
      ctx.fillText(`PTS: ${this.score}`, 240, 36);

      // Wave Meter
      ctx.textAlign = "center";
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 14px monospace";
      const maxWStr = (this.maxWaves > 50) ? "∞" : this.maxWaves;
      ctx.fillText(`WAVE ${this.wave}/${maxWStr}`, 380, 36);

      // Start / Wave Action Cyber Button
      const isWaveActive = this.waveActive;
      const waveLabel = isWaveActive ? `⚔ JANGDA (${this.enemies.length})` : `▶ JANG [${Math.ceil(this.waveCountdown)}s]`;
      this.drawCyberButton(450, 10, 160, 40, waveLabel, isWaveActive ? "#ff1744" : "#00e676", isWaveActive ? "HOSTILES IN BOUND" : "ENGAGE WAVE", "", !isWaveActive);

      // Mode & Map Name displayed cleanly above action button
      ctx.fillStyle = "#546e7a";
      ctx.font = "9px monospace";
      ctx.textAlign = "left";
      const mapName = (this.gameMode === 'CUSTOM') ? "CUSTOM MAP" : MAPS[this.currentMapIndex].name.toUpperCase();
      ctx.fillText(`${mapName}`, 240, 48);

      // Ergonomic Wide Action Cyber Buttons
      this.drawCyberButton(625, 9, 90, 42, `${this.speed}x SPEED`, this.speed > 1 ? "#ffd600" : "#00e5ff", "TEMPO", "⏩", this.speed > 1);
      this.drawCyberButton(725, 9, 125, 42, "SOZLAMALAR", "#00e5ff", "SETTINGS", "⚙️", false);
      this.drawCyberButton(860, 9, 105, 42, this.state === 'PAUSED' ? "DAVOM" : "PAUZA", this.state === 'PAUSED' ? "#ffd600" : "#00e5ff", "PAUSE", "⏸", false);
      this.drawCyberButton(975, 9, 110, 42, "← MENYU", "#ff1744", "ABORT", "🚪", false);
      this.drawCyberButton(1095, 9, 165, 42, "🕹️ 3D PILOT", "#e040fb", "TPS BATTLE", "🎮", false);
    }

    renderMiniButton(x, y, w, h, text, color = "#00e5ff") {
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const ptr = this.mousePos;
      const isHovered = !!(ptr && ptr.x >= x && ptr.x <= x + w && ptr.y >= y && ptr.y <= y + h);
      const isPressed = isHovered && this.isPointerDown;

      const pressOffset = isPressed ? 1.5 : 0;
      const bx = x;
      const by = y + pressOffset;
      const bw = w;
      const bh = h - pressOffset;
      const cut = Math.min(6, Math.floor(bh * 0.25));

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(bx + cut, by);
      ctx.lineTo(bx + bw, by);
      ctx.lineTo(bx + bw, by + bh - cut);
      ctx.lineTo(bx + bw - cut, by + bh);
      ctx.lineTo(bx, by + bh);
      ctx.lineTo(bx, by + cut);
      ctx.closePath();

      // Frosted Glassmorphism Gradient
      const grad = ctx.createLinearGradient(bx, by, bx, by + bh);
      if (isPressed) {
        grad.addColorStop(0, "rgba(32, 54, 90, 0.98)");
        grad.addColorStop(1, "rgba(14, 24, 40, 0.99)");
      } else if (isHovered) {
        grad.addColorStop(0, "rgba(24, 44, 76, 0.96)");
        grad.addColorStop(1, "rgba(9, 18, 32, 0.98)");
      } else {
        grad.addColorStop(0, "rgba(16, 28, 48, 0.92)");
        grad.addColorStop(1, "rgba(7, 12, 22, 0.97)");
      }
      ctx.fillStyle = grad;
      ctx.fill();

      // Animated Neon Pulse Glow on hover
      const pulse = Math.sin(t * 3.8) * 0.5 + 0.5;
      if (isHovered) {
        ctx.shadowColor = color;
        ctx.shadowBlur = 10 + pulse * 6;
      }

      ctx.strokeStyle = color;
      ctx.lineWidth = isHovered ? 1.8 : 1.2;
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.shadowColor = "transparent";

      // Top Specular Highlight Line
      ctx.strokeStyle = "rgba(255, 255, 255, 0.38)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(bx + cut, by + 1);
      ctx.lineTo(bx + bw - 1, by + 1);
      ctx.stroke();

      ctx.fillStyle = isHovered ? "#ffffff" : color;
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.shadowColor = "rgba(0,0,0,0.9)";
      ctx.shadowBlur = 3;
      ctx.fillText(text, bx + bw / 2, by + bh / 2 + 4);
      ctx.restore();
    }

    drawCyberButton(x, y, w, h, text, color = "#00e5ff", subtext = "", icon = "", isHighlighted = false) {
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const ptr = this.mousePos;
      const isHovered = !!(ptr && ptr.x >= x && ptr.x <= x + w && ptr.y >= y && ptr.y <= y + h);
      const isPressed = isHovered && this.isPointerDown;

      const pressOffset = isPressed ? 2 : 0;
      const bx = x;
      const by = y + pressOffset;
      const bw = w;
      const bh = h - pressOffset;
      const cut = Math.min(10, Math.floor(bh * 0.22));

      ctx.save();

      // Chamfered 45-degree tactical polygon
      ctx.beginPath();
      ctx.moveTo(bx + cut, by);
      ctx.lineTo(bx + bw, by);
      ctx.lineTo(bx + bw, by + bh - cut);
      ctx.lineTo(bx + bw - cut, by + bh);
      ctx.lineTo(bx, by + bh);
      ctx.lineTo(bx, by + cut);
      ctx.closePath();

      // 1. Frosted Glassmorphism Multi-layer Gradient Fill
      const grad = ctx.createLinearGradient(bx, by, bx, by + bh);
      if (isPressed) {
        grad.addColorStop(0, "rgba(35, 68, 115, 0.98)");
        grad.addColorStop(0.5, "rgba(20, 42, 74, 0.98)");
        grad.addColorStop(1, "rgba(10, 22, 42, 0.99)");
      } else if (isHovered || isHighlighted) {
        grad.addColorStop(0, "rgba(25, 52, 92, 0.96)");
        grad.addColorStop(0.35, "rgba(18, 38, 68, 0.94)");
        grad.addColorStop(0.75, "rgba(11, 24, 44, 0.97)");
        grad.addColorStop(1, "rgba(6, 13, 24, 0.99)");
      } else {
        grad.addColorStop(0, "rgba(16, 27, 46, 0.93)");
        grad.addColorStop(0.4, "rgba(12, 20, 35, 0.95)");
        grad.addColorStop(1, "rgba(6, 10, 18, 0.98)");
      }
      ctx.fillStyle = grad;
      ctx.fill();

      // 2. Animated Pulse Neon Outer Glow
      const pulse = Math.sin(t * 3.8) * 0.5 + 0.5;
      if (isHighlighted || isHovered) {
        ctx.shadowColor = color;
        ctx.shadowBlur = isPressed ? 18 : (11 + pulse * 8);
      } else {
        ctx.shadowColor = "rgba(0, 0, 0, 0.65)";
        ctx.shadowBlur = 4;
      }

      // 3. Glowing Neon Tactical Border
      ctx.strokeStyle = color;
      ctx.lineWidth = (isHighlighted || isHovered) ? 2.0 : 1.3;
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.shadowColor = "transparent";

      // 4. Frosted Glass Specular Sheen (Clipped to button)
      ctx.save();
      ctx.clip();

      const sheenGrad = ctx.createLinearGradient(bx, by, bx, by + bh * 0.48);
      sheenGrad.addColorStop(0, "rgba(255, 255, 255, 0.24)");
      sheenGrad.addColorStop(1, "rgba(255, 255, 255, 0.02)");
      ctx.fillStyle = sheenGrad;
      ctx.fillRect(bx, by, bw, bh * 0.48);

      // 5. Holographic Light Scanline Sweep across face (Every ~2.8s)
      if (isHighlighted || isHovered) {
        const sweepProgress = ((t * 0.42) % 1.5) - 0.25;
        const sweepX = bx + bw * sweepProgress;
        const beamGrad = ctx.createLinearGradient(sweepX - 25, by, sweepX + 25, by + bh);
        beamGrad.addColorStop(0, "rgba(255, 255, 255, 0)");
        beamGrad.addColorStop(0.5, "rgba(255, 255, 255, 0.28)");
        beamGrad.addColorStop(1, "rgba(255, 255, 255, 0)");
        ctx.fillStyle = beamGrad;
        ctx.fillRect(bx, by, bw, bh);
      }

      // 6. Expanding Click/Tap Shockwave Ripples inside button
      if (this.buttonRipples && this.buttonRipples.length > 0) {
        for (const rip of this.buttonRipples) {
          if (rip.x >= bx - 30 && rip.x <= bx + bw + 30 && rip.y >= by - 30 && rip.y <= by + bh + 30) {
            ctx.strokeStyle = `rgba(255, 255, 255, ${rip.alpha * 0.65})`;
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.arc(rip.x, rip.y, rip.r, 0, Math.PI * 2);
            ctx.stroke();
          }
        }
      }

      ctx.restore(); // end clip

      // 7. Tactical Cyber Accents: Left Vertical Glow Strip
      ctx.fillStyle = color;
      ctx.fillRect(bx, by + cut, 3.5, Math.max(2, bh - cut * 2));

      // 8. Corner Sci-Fi L-Brackets
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(bx + bw - 10, by);
      ctx.lineTo(bx + bw, by);
      ctx.lineTo(bx + bw, by + 8);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(bx, by + bh - 8);
      ctx.lineTo(bx, by + bh);
      ctx.lineTo(bx + 10, by + bh);
      ctx.stroke();

      // Top specular highlight edge line
      ctx.strokeStyle = "rgba(255, 255, 255, 0.38)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(bx + cut + 2, by + 1);
      ctx.lineTo(bx + bw - 2, by + 1);
      ctx.stroke();

      // 9. Technical micro-status dot on top left
      ctx.fillStyle = (isHighlighted || isHovered) ? color : "rgba(255, 255, 255, 0.4)";
      ctx.beginPath();
      ctx.arc(bx + cut + 5, by + 5, 2.0, 0, Math.PI * 2);
      ctx.fill();

      // 10. High-contrast Typography with Drop Shadow
      ctx.shadowColor = "rgba(0, 0, 0, 0.95)";
      ctx.shadowBlur = 5;
      ctx.shadowOffsetY = 1;

      const hasSub = !!subtext;
      const titleY = hasSub ? by + bh * 0.42 : by + bh * 0.5 + 4;

      ctx.fillStyle = (isHighlighted || isHovered) ? "#ffffff" : color;
      ctx.font = "bold 13px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      const fullTitle = icon ? `${icon} ${text}` : text;
      ctx.fillText(fullTitle, bx + bw / 2, titleY);

      if (hasSub) {
        ctx.fillStyle = (isHighlighted || isHovered) ? "#cfd8dc" : "#78909c";
        ctx.font = "bold 9px 'Segoe UI', monospace";
        ctx.fillText(subtext, bx + bw / 2, by + bh * 0.78);
      }

      ctx.restore();
    }

    renderAbilitySlot(x, y, w, h, icon, label, subtext, color = "#00e5ff", isReady = true, cdRatio = 0) {
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const ptr = this.mousePos;
      const isHovered = !!(ptr && ptr.x >= x && ptr.x <= x + w && ptr.y >= y && ptr.y <= y + h);
      const isPressed = isHovered && this.isPointerDown;

      const pressOffset = (isPressed && isReady) ? 2 : 0;
      const bx = x;
      const by = y + pressOffset;
      const bw = w;
      const bh = h - pressOffset;
      const cut = 6;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(bx + cut, by);
      ctx.lineTo(bx + bw, by);
      ctx.lineTo(bx + bw, by + bh - cut);
      ctx.lineTo(bx + bw - cut, by + bh);
      ctx.lineTo(bx, by + bh);
      ctx.lineTo(bx, by + cut);
      ctx.closePath();

      // Frosted Glassmorphism Background
      const grad = ctx.createLinearGradient(bx, by, bx, by + bh);
      if (isReady) {
        if (isPressed) {
          grad.addColorStop(0, "rgba(30, 56, 95, 0.98)");
          grad.addColorStop(1, "rgba(12, 22, 38, 0.99)");
        } else if (isHovered) {
          grad.addColorStop(0, "rgba(24, 48, 82, 0.96)");
          grad.addColorStop(1, "rgba(9, 18, 32, 0.98)");
        } else {
          grad.addColorStop(0, "rgba(16, 30, 52, 0.94)");
          grad.addColorStop(1, "rgba(7, 13, 24, 0.98)");
        }
      } else {
        grad.addColorStop(0, "rgba(10, 15, 24, 0.95)");
        grad.addColorStop(1, "rgba(5, 8, 14, 0.98)");
      }
      ctx.fillStyle = grad;
      ctx.fill();

      // Neon glowing border when ready
      const pulse = Math.sin(t * 4.5) * 0.5 + 0.5;
      if (isReady) {
        ctx.shadowColor = color;
        ctx.shadowBlur = isHovered ? (14 + pulse * 6) : (8 + pulse * 4);
      } else {
        ctx.shadowColor = "transparent";
        ctx.shadowBlur = 0;
      }

      ctx.strokeStyle = color;
      ctx.lineWidth = isReady ? (isHovered ? 2.2 : 1.6) : 1.0;
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.shadowColor = "transparent";

      // Frosted Glass Sheen & Holographic scan
      ctx.save();
      ctx.clip(); // clip to slot polygon

      const sheen = ctx.createLinearGradient(bx, by, bx, by + bh * 0.45);
      sheen.addColorStop(0, "rgba(255, 255, 255, 0.22)");
      sheen.addColorStop(1, "rgba(255, 255, 255, 0.02)");
      ctx.fillStyle = sheen;
      ctx.fillRect(bx, by, bw, bh * 0.45);

      // Cooldown Sweep Overlay
      if (cdRatio > 0) {
        const sweepH = bh * cdRatio;
        const sweepY = by + bh - sweepH;
        const cdGrad = ctx.createLinearGradient(bx, sweepY, bx, by + bh);
        cdGrad.addColorStop(0, "rgba(255, 23, 68, 0.78)");
        cdGrad.addColorStop(1, "rgba(180, 10, 40, 0.90)");
        ctx.fillStyle = cdGrad;
        ctx.fillRect(bx, sweepY, bw, sweepH);

        // Glowing wave line at the cooldown boundary
        ctx.strokeStyle = "#ff5252";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(bx, sweepY);
        ctx.lineTo(bx + bw, sweepY);
        ctx.stroke();
      }

      // Ready Scanline Sweep
      if (isReady) {
        const sweepProg = ((t * 0.5) % 1.5) - 0.25;
        const sweepX = bx + bw * sweepProg;
        const beamGrad = ctx.createLinearGradient(sweepX - 12, by, sweepX + 12, by + bh);
        beamGrad.addColorStop(0, "rgba(255, 255, 255, 0)");
        beamGrad.addColorStop(0.5, "rgba(255, 255, 255, 0.25)");
        beamGrad.addColorStop(1, "rgba(255, 255, 255, 0)");
        ctx.fillStyle = beamGrad;
        ctx.fillRect(bx, sweepY || by, bw, bh);
      }

      ctx.restore(); // end clip

      // Top specular highlight line
      ctx.strokeStyle = "rgba(255, 255, 255, 0.38)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(bx + cut, by + 1);
      ctx.lineTo(bx + bw - 1, by + 1);
      ctx.stroke();

      // Icon on top
      ctx.fillStyle = isReady ? color : "#78909c";
      ctx.font = "15px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.shadowColor = isReady ? color : "transparent";
      ctx.shadowBlur = isReady ? 6 : 0;
      ctx.fillText(icon, bx + bw / 2, by + 26);
      ctx.shadowBlur = 0;

      // Label below
      ctx.fillStyle = isReady ? "#ffffff" : "#78909c";
      ctx.font = "bold 11px monospace";
      ctx.shadowColor = "rgba(0,0,0,0.95)";
      ctx.shadowBlur = 4;
      ctx.fillText(label, bx + bw / 2, by + 47);

      // Subtext / Cost below
      ctx.fillStyle = isReady ? color : "#546e7a";
      ctx.font = "bold 9px monospace";
      ctx.fillText(subtext, bx + bw / 2, by + 67);

      ctx.restore();
    }

    render3DCircularButton(cx, cy, radius, label, sublabel, color = "#00e5ff", isActive = false) {
      const ctx = this.ctx;
      const t = this.uiTime || 0;
      const ptr = this.mousePos;
      const isHovered = !!(ptr && Math.hypot(ptr.x - cx, ptr.y - cy) <= radius);
      const isPressed = isHovered && this.isPointerDown;

      const r = (isPressed ? radius * 0.92 : (isHovered ? radius * 1.05 : radius));
      ctx.save();

      // Outer animated rotating radar calibration notches
      const ringAngle = t * (isActive ? 2.5 : 1.2);
      ctx.strokeStyle = isActive ? color : "rgba(255, 255, 255, 0.35)";
      ctx.lineWidth = 1.6;
      ctx.setLineDash([6, 12]);
      ctx.beginPath();
      ctx.arc(cx, cy, r + 4, ringAngle, ringAngle + Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Multi-layer Radial Frosted Glass Glow
      const radGrad = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, 0, cx, cy, r);
      if (isActive) {
        radGrad.addColorStop(0, "rgba(255, 255, 255, 0.45)");
        radGrad.addColorStop(0.3, color);
        radGrad.addColorStop(0.85, "rgba(10, 20, 36, 0.95)");
        radGrad.addColorStop(1, "rgba(5, 10, 20, 0.99)");
      } else if (isHovered) {
        radGrad.addColorStop(0, "rgba(255, 255, 255, 0.28)");
        radGrad.addColorStop(0.4, "rgba(30, 50, 85, 0.85)");
        radGrad.addColorStop(1, "rgba(10, 16, 28, 0.95)");
      } else {
        radGrad.addColorStop(0, "rgba(255, 255, 255, 0.15)");
        radGrad.addColorStop(0.4, "rgba(18, 28, 48, 0.80)");
        radGrad.addColorStop(1, "rgba(6, 10, 18, 0.95)");
      }

      // Neon Pulsing Outer Glow
      const pulse = Math.sin(t * 4.0) * 0.5 + 0.5;
      ctx.shadowColor = color;
      ctx.shadowBlur = isActive ? (16 + pulse * 8) : (isHovered ? 12 : 5);

      ctx.fillStyle = radGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Solid Rim Stroke
      ctx.strokeStyle = isActive ? "#ffffff" : color;
      ctx.lineWidth = isActive ? 2.5 : (isHovered ? 2.0 : 1.4);
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.shadowColor = "transparent";

      // Top Crescent Specular Glass Reflection
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, r - 2, 0, Math.PI * 2);
      ctx.clip();

      const crescentGrad = ctx.createLinearGradient(cx, cy - r, cx, cy);
      crescentGrad.addColorStop(0, "rgba(255, 255, 255, 0.35)");
      crescentGrad.addColorStop(1, "rgba(255, 255, 255, 0.02)");
      ctx.fillStyle = crescentGrad;
      ctx.fillRect(cx - r, cy - r, r * 2, r);
      ctx.restore();

      // Icon & Label Typography
      ctx.shadowColor = "rgba(0, 0, 0, 0.95)";
      ctx.shadowBlur = 5;
      ctx.textAlign = "center";
      ctx.fillStyle = isActive ? "#ffffff" : (isHovered ? "#ffffff" : color);
      ctx.font = `bold ${Math.round(r * 0.34)}px 'Segoe UI', monospace`;
      const textY = sublabel ? cy + 1 : cy + 5;
      ctx.fillText(label, cx, textY);

      if (sublabel) {
        ctx.fillStyle = isActive ? "#ffffff" : "#b0bec5";
        ctx.font = `bold ${Math.round(r * 0.22)}px monospace`;
        ctx.fillText(sublabel, cx, cy + r * 0.52);
      }

      ctx.restore();
    }

    renderBottomBar() {
      const ctx = this.ctx;
      // Frosted Glassmorphism Panel
      const botGrad = ctx.createLinearGradient(0, 620, 0, 720);
      botGrad.addColorStop(0, "rgba(9, 15, 27, 0.98)");
      botGrad.addColorStop(1, "rgba(5, 8, 16, 0.99)");
      ctx.fillStyle = botGrad;
      ctx.fillRect(0, 620, this.width, 100);

      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, 620);
      ctx.lineTo(this.width, 620);
      ctx.stroke();

      // 1. Hero Mech Ult Button (x: 6, w: 42, h: 78)
      const isHeroUltReady = this.hero.currentUltCd <= 0;
      this.renderAbilitySlot(6, 628, 42, 78, "⚡", "MECH", isHeroUltReady ? "ULT" : `${Math.ceil(this.hero.currentUltCd)}s`, isHeroUltReady ? "#ffd600" : "#455a64", isHeroUltReady, this.hero.currentUltCd / this.hero.ultCd);

      // 2. Hero Mech Mode Toggle Button (x: 52, w: 42, h: 78)
      const isSiege = this.hero.mode === 'SIEGE';
      this.renderAbilitySlot(52, 628, 42, 78, isSiege ? "🚜" : "🤖", "MODE", isSiege ? "TANK" : "ROBOT", isSiege ? "#ffd600" : "#00e5ff", true, 0);

      // 3. 4 Commander Super Skills Panel (Clean Stacked Slots: w: 40, h: 78)
      const skillMeta = {
        emp:       { icon: "⚡", label: "EMP",  color: "#00e5ff", sub: `${this.skills.emp.cost}g` },
        missiles:  { icon: "🚀", label: "MSL",  color: "#ff9100", sub: `${this.skills.missiles.cost}g` },
        shield:    { icon: "🛡️", label: "SHD",  color: "#00b0ff", sub: `${this.skills.shield.cost}g` },
        overclock: { icon: "⚙️", label: "ROF",  color: "#ffd600", sub: `${this.skills.overclock.cost}g` }
      };
      const skillList = ['emp', 'missiles', 'shield', 'overclock'];
      for (let i = 0; i < 4; i++) {
        const k = skillList[i];
        const s = this.skills[k];
        const meta = skillMeta[k];
        const sx = 98 + i * 44;
        const isReady = s.currentCd <= 0 && this.gold >= s.cost;
        const isAiming = (this.aimingSkill === k);
        const color = isAiming ? "#ffeb3b" : (isReady ? meta.color : "#37474f");

        this.renderAbilitySlot(sx, 628, 40, 78, meta.icon, meta.label, meta.sub, color, isReady || isAiming, s.currentCd / s.cd);

        // Active Aiming Highlight Ring
        if (isAiming) {
          ctx.save();
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 2.5;
          ctx.shadowColor = "#ffd600";
          ctx.shadowBlur = 8;
          ctx.strokeRect(sx, 628, 40, 78);
          ctx.restore();
        }

        // Active Cooldown Countdown Text
        if (s.currentCd > 0) {
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 11px monospace";
          ctx.textAlign = "center";
          ctx.shadowColor = "rgba(0,0,0,0.9)";
          ctx.shadowBlur = 4;
          ctx.fillText(`${Math.ceil(s.currentCd)}s`, sx + 20, 696);
        }
      }

      // 4. Selection vs Hotbar
      if (this.selectedTower) {
        const t = this.selectedTower;
        const def = TOWER_DEFS[t.type];
        const spec = t.branch ? def.branches[t.branch] : def.tiers[t.tier - 1];

        // Tower info box
        ctx.fillStyle = spec.color || def.color;
        ctx.font = "bold 14px monospace";
        ctx.textAlign = "left";
        const titleStr = t.branch ? spec.name.toUpperCase() : `${def.name.toUpperCase()} (T${t.tier})`;
        ctx.fillText(titleStr, 280, 652);

        ctx.fillStyle = "#cfd8dc";
        ctx.font = "11px monospace";
        const stats = t.type === 'beacon' ?
          `Aura: +${(spec.dmgBuff || 0.35) * 100}% Dmg | Radius: ${spec.range}px` :
          `Dmg: ${spec.dmg} | Rate: ${spec.rate}/s | Kills: ${t.kills} | Deal: ${t.damageDealt}`;
        ctx.fillText(stats, 280, 674);

        // Branching upgrade at Tier 2
        if (t.tier === 2) {
          const bA = def.branches.A;
          const bB = def.branches.B;
          const canA = this.gold >= bA.cost;
          const canB = this.gold >= bB.cost;
          this.drawCyberButton(490, 632, 140, 72, `[A] ${bA.name}`, canA ? bA.color : "#455a64", `${bA.cost}g • ${bA.perk.toUpperCase()}`, "", canA);
          this.drawCyberButton(645, 632, 140, 72, `[B] ${bB.name}`, canB ? bB.color : "#455a64", `${bB.cost}g • ${bB.perk.toUpperCase()}`, "", canB);
        } else if (t.tier === 1) {
          const upCost = spec.upCost;
          const canUpgrade = this.gold >= upCost;
          this.drawCyberButton(520, 636, 140, 62, `[U] ${this.t("upgrade")}`, canUpgrade ? "#00e676" : "#455a64", `NARXI: ${upCost}g`, "⚡", canUpgrade);
        } else {
          this.drawCyberButton(520, 636, 140, 62, "MAX TIER 3", "#ffd600", "MAX SPECIALIZED", "★", false);
        }

        // Sell button
        const refund = Math.floor(t.totalInvested * 0.70);
        this.drawCyberButton(800, 636, 110, 62, `SOTISH`, "#ff1744", `+${refund}g QAYTADI`, "🗑", true);

        // Priority button
        this.drawCyberButton(925, 636, 115, 62, `NISHON`, "#00e5ff", t.priority.toUpperCase(), "🎯", false);

        // Close button
        this.drawCyberButton(1055, 636, 45, 62, "✕", "#90a4ae", "YOPISH", "", false);
      } else {
        // 8 Tower Hotbar Slots: 7 Towers + Barricade Wall
        const hotbarItems = [
          { key: 'pulse', label: '[1] PULSE' },
          { key: 'mortar', label: '[2] MORTAR' },
          { key: 'cryo', label: '[3] CRYO' },
          { key: 'tesla', label: '[4] TESLA' },
          { key: 'flame', label: '[5] FLAME' },
          { key: 'railgun', label: '[6] RAILGUN' },
          { key: 'beacon', label: '[7] BEACON' },
          { key: 'barricade', label: "[8] TO'SIQ" }
        ];

        for (let i = 0; i < 8; i++) {
          const item = hotbarItems[i];
          const bx = 276 + i * 125;
          const isSelected = this.selectedBuildType === item.key;
          let cost = 40;
          let color = "#ffd600";
          let subText = "40g • DEVOR";

          if (item.key !== 'barricade') {
            const def = TOWER_DEFS[item.key];
            cost = def.cost;
            color = def.color;
            subText = `${cost}g • ${def.type}`;
          }

          const canAfford = this.gold >= cost;
          const cardColor = isSelected ? "#00e5ff" : (canAfford ? color : "#455a64");

          this.drawCyberButton(bx, 628, 120, 78, item.label, cardColor, subText, isSelected ? "▶" : "⬢", isSelected);
        }
      }
    }

    renderDraftModal() {
      const ctx = this.ctx;
      const bgGrad = ctx.createLinearGradient(0, 0, 0, this.height);
      bgGrad.addColorStop(0, "rgba(4, 7, 14, 0.97)");
      bgGrad.addColorStop(1, "rgba(8, 14, 25, 0.98)");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, this.width, this.height);

      ctx.save();
      ctx.shadowColor = "rgba(255, 214, 0, 0.7)";
      ctx.shadowBlur = 15;
      ctx.textAlign = "center";
      ctx.fillStyle = "#ffd600";
      ctx.font = "900 34px 'Segoe UI', monospace";
      ctx.fillText(this.t("draftTitle"), 640, 110);
      ctx.restore();

      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 13px monospace";
      ctx.textAlign = "center";
      ctx.fillText(this.t("draftSub"), 640, 148);

      for (let i = 0; i < this.draftCards.length; i++) {
        const c = this.draftCards[i];
        const x = 180 + i * 320;
        const y = 195;
        const w = 280;
        const h = 330;
        const cut = 10;

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(x + cut, y);
        ctx.lineTo(x + w, y);
        ctx.lineTo(x + w, y + h - cut);
        ctx.lineTo(x + w - cut, y + h);
        ctx.lineTo(x, y + h);
        ctx.lineTo(x, y + cut);
        ctx.closePath();

        const cardGrad = ctx.createLinearGradient(x, y, x, y + h);
        cardGrad.addColorStop(0, "rgba(16, 26, 46, 0.98)");
        cardGrad.addColorStop(1, "rgba(8, 14, 25, 0.99)");
        ctx.fillStyle = cardGrad;
        ctx.fill();

        ctx.strokeStyle = c.color;
        ctx.lineWidth = 1.8;
        ctx.stroke();

        ctx.fillStyle = c.color;
        ctx.fillRect(x, y + cut, 4, 35);

        ctx.font = "42px monospace";
        ctx.textAlign = "center";
        ctx.fillText(c.icon, x + w / 2, y + 62);

        ctx.fillStyle = c.color;
        ctx.font = "bold 16px 'Segoe UI', monospace";
        ctx.fillText(c.title, x + w / 2, y + 112);

        ctx.fillStyle = "#b0bec5";
        ctx.font = "12px 'Segoe UI', monospace";
        this.wrapText(c.desc, x + 20, y + 155, 240, 18);

        this.drawCyberButton(x + 20, y + 255, 240, 48, "PERKNI TANLASH", c.color, c.title.toUpperCase(), "⚡", true);
        ctx.restore();
      }
    }

    renderAnalyticsScreen() {
      this.ctx.fillStyle = "#05070d";
      this.ctx.fillRect(0, 0, this.width, this.height);

      this.ctx.textAlign = "center";
      this.ctx.fillStyle = "#00e5ff";
      this.ctx.font = "bold 30px 'Segoe UI', monospace";
      this.ctx.fillText(this.t("analyticsTitle"), 640, 80);

      this.ctx.fillStyle = "#ffd600";
      this.ctx.font = "bold 16px monospace";
      this.ctx.fillText(`MVP UNIT: ${this.analytics.mvpName}`, 640, 120);

      // Bar Charts for Damage
      const dmg = this.analytics.damageByTower;
      const categories = [
        { label: "PULSE", val: dmg.pulse, color: "#00e5ff" },
        { label: "MORTAR", val: dmg.mortar, color: "#ff9100" },
        { label: "CRYO", val: dmg.cryo, color: "#00f0ff" },
        { label: "RAILGUN", val: dmg.railgun, color: "#ff007f" },
        { label: "HERO MECH", val: dmg.hero, color: "#ffd600" },
        { label: "COMMANDER", val: dmg.skills, color: "#76ff03" }
      ];

      const maxVal = Math.max(1, ...categories.map(c => c.val));
      for (let i = 0; i < categories.length; i++) {
        const c = categories[i];
        const y = 170 + i * 55;

        this.ctx.textAlign = "left";
        this.ctx.fillStyle = c.color;
        this.ctx.font = "bold 13px monospace";
        this.ctx.fillText(c.label, 120, y + 18);

        // Bar background
        this.ctx.fillStyle = "#101624";
        this.ctx.fillRect(260, y, 700, 26);

        // Bar fill
        const barW = (c.val / maxVal) * 696;
        this.ctx.fillStyle = c.color;
        this.ctx.fillRect(262, y + 2, barW, 22);

        this.ctx.fillStyle = "#fff";
        this.ctx.fillText(`${c.val.toLocaleString()} DMG`, 980, y + 18);
      }

      // Summary Stats
      this.ctx.textAlign = "center";
      this.ctx.fillStyle = "#cfd8dc";
      this.ctx.font = "14px monospace";
      this.ctx.fillText(`Total Hostiles Defeated: ${this.analytics.totalKills} | Total Gold Processed: ${this.analytics.totalGold}g`, 640, 560);

      this.renderMenuButton(540, 630, 200, 50, "BACK TO MENU", "#00e5ff", "#000");
    }

    renderMainMenu() {
      const ctx = this.ctx;
      const time = performance.now() * 0.002;

      // 1. Deep Space Atmospheric Gradient Background
      const bgGrad = ctx.createLinearGradient(0, 0, this.width, this.height);
      bgGrad.addColorStop(0, "#040711");
      bgGrad.addColorStop(0.4, "#070e20");
      bgGrad.addColorStop(1, "#03050b");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, this.width, this.height);

      // Cyber Grid Lines
      ctx.strokeStyle = "rgba(0, 229, 255, 0.05)";
      ctx.lineWidth = 1;
      for (let x = 0; x <= this.width; x += 50) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.height); ctx.stroke();
      }
      for (let y = 0; y <= this.height; y += 50) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.width, y); ctx.stroke();
      }

      // 2. Top Header Bar (Commander Profile & Global Status)
      ctx.fillStyle = "rgba(8, 15, 28, 0.92)";
      ctx.fillRect(0, 0, this.width, 68);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(0, 0, this.width, 68);

      // Game Title (Strictly non-overlapping)
      ctx.save();
      ctx.shadowColor = "rgba(0, 229, 255, 0.8)";
      ctx.shadowBlur = 12;
      ctx.fillStyle = "#00e5ff";
      ctx.font = "900 21px 'Segoe UI', monospace";
      ctx.textAlign = "left";
      ctx.fillText("⚡ TOWER DEFENSE: LAST GRID", 35, 42);
      ctx.restore();

      // Version in separate pill badge
      this.renderMiniButton(390, 24, 75, 24, "v4.1.0", "#ff007f");

      // Commander Name & Status Badge
      ctx.fillStyle = "#cfd8dc";
      ctx.font = "bold 13px monospace";
      ctx.textAlign = "right";
      ctx.fillText(`KOMANDIR: ${this.playerName.toUpperCase()}  |  HQ STATUS: ONLINE`, 1110, 42);

      // Lang Button
      this.renderMiniButton(1130, 18, 110, 34, `LANG: ${this.lang.toUpperCase()}`, "#ffd600");

      // =========================================================================
      // 3. LEFT HERO SHOWCASE HANGAR (x: 40 to 420, y: 88 to 680)
      // =========================================================================
      const hx = 40, hy = 88, hw = 390, hh = 590;
      ctx.save();
      const cut = 12;
      ctx.beginPath();
      ctx.moveTo(hx + cut, hy);
      ctx.lineTo(hx + hw, hy);
      ctx.lineTo(hx + hw, hy + hh - cut);
      ctx.lineTo(hx + hw - cut, hy + hh);
      ctx.lineTo(hx, hy + hh);
      ctx.lineTo(hx, hy + cut);
      ctx.closePath();

      const hGrad = ctx.createLinearGradient(hx, hy, hx, hy + hh);
      hGrad.addColorStop(0, "rgba(12, 22, 40, 0.94)");
      hGrad.addColorStop(1, "rgba(6, 11, 20, 0.96)");
      ctx.fillStyle = hGrad;
      ctx.fill();

      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Hangar Header
      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 14px 'Segoe UI', monospace";
      ctx.textAlign = "left";
      ctx.fillText("🛡️ JANGOVAR MECH: APEX-01", hx + 20, hy + 32);

      ctx.fillStyle = "#00e676";
      ctx.font = "11px monospace";
      ctx.fillText("STATUS: TAYYOR (COMBAT READY)", hx + 20, hy + 50);

      // Rotating Hologram Base Plate on Floor
      const px = hx + hw / 2;
      const py = hy + 285;
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(px, py + 95, 120, 36, 0, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = "rgba(255, 214, 0, 0.25)";
      ctx.beginPath();
      ctx.ellipse(px, py + 95, 85, 26, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Animated 3D Mech Torso & Chassis
      const breathe = Math.sin(time * 3) * 4;
      const my = py + breathe;

      // Legs / Hydraulics
      ctx.strokeStyle = "#37474f";
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(px - 35, my + 30); ctx.lineTo(px - 50, py + 85);
      ctx.moveTo(px + 35, my + 30); ctx.lineTo(px + 50, py + 85);
      ctx.stroke();

      // Foot Pads
      ctx.fillStyle = "#263238";
      ctx.fillRect(px - 65, py + 82, 30, 10);
      ctx.fillRect(px + 35, py + 82, 30, 10);

      // Heavy Torso
      ctx.fillStyle = "#1e3a5f";
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(px - 45, my - 40);
      ctx.lineTo(px + 45, my - 40);
      ctx.lineTo(px + 35, my + 35);
      ctx.lineTo(px - 35, my + 35);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Pulsing Plasmatic Core Reactor
      const corePulse = (Math.sin(time * 5) + 1) * 0.5;
      ctx.shadowColor = "#00e5ff";
      ctx.shadowBlur = 15 + corePulse * 10;
      ctx.fillStyle = corePulse > 0.5 ? "#ffffff" : "#00e5ff";
      ctx.beginPath();
      ctx.arc(px, my - 5, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Shoulder Armor & Heavy Missile Pods
      ctx.fillStyle = "#ff007f";
      ctx.fillRect(px - 72, my - 50, 24, 30);
      ctx.fillRect(px + 48, my - 50, 24, 30);

      // Head Visor (Glowing Cyan)
      ctx.fillStyle = "#00e5ff";
      ctx.fillRect(px - 18, my - 62, 36, 12);

      // Hero Dossier Stats at Hangar Bottom
      ctx.fillStyle = "rgba(10, 18, 32, 0.85)";
      ctx.fillRect(hx + 15, hy + 415, hw - 30, 150);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.25)";
      ctx.strokeRect(hx + 15, hy + 415, hw - 30, 150);

      ctx.fillStyle = "#cfd8dc";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "left";
      ctx.fillText("⚔️ ASOSIY QUROL: Dual Kinetic Tracer", hx + 28, hy + 440);
      ctx.fillText("⚡ ULT: Orbital Titan Death Beam", hx + 28, hy + 465);
      ctx.fillText("🚀 HARAKAT: Reaktiv Kinetik Dash", hx + 28, hy + 490);
      ctx.fillText("🛡️ ZIRH: Nanite Composite (Level 5)", hx + 28, hy + 515);

      ctx.fillStyle = "#ffd600";
      ctx.font = "11px monospace";
      ctx.fillText("▶ Qahramon jangda to'liq boshqariladi!", hx + 28, hy + 540);

      // 3D Mech Studio Button
      this.renderMenuButton(hx + 20, hy + 520, hw - 40, 48, "🤖 3D MECH STUDIYA (360°)", "#00e5ff", "#000");

      ctx.restore();

      // =========================================================================
      // 4. RIGHT TACTICAL MISSION MATRIX (x: 455 to 1240, y: 88 to 680)
      // =========================================================================
      // Primary Action Card 1: KAMPANIYA (x: 455, y: 88, w: 380, h: 95)
      this.drawCyberButton(455, 88, 380, 95, this.t("campaign"), "#00e5ff", "10 PROGRESSIV SEKTOR • 3 TA BIOM", "🚀", true);

      // Primary Action Card 2: CHEKSIZ OMON QOLISH (x: 855, y: 88, w: 385, h: 95)
      const record = localStorage.getItem('lg_endless_wave') || "0";
      this.drawCyberButton(855, 88, 385, 95, this.t("endless"), "#e040fb", `CHEKSIZ TO'LQINLAR • ENG YAXSHI: W${record}`, "⚡", true);

      // Secondary Action Card 3: 3D TPS ARENA (x: 455, y: 195, w: 380, h: 72)
      this.drawCyberButton(455, 195, 380, 72, "3D TPS ARENA REJIMI", "#ff007f", "UCHINCHI SHAXS O'TISHMA ARENASI", "🎮", true);

      // Secondary Action Card 4: SEKTORLAR XARITASI (x: 855, y: 195, w: 385, h: 72)
      this.drawCyberButton(855, 195, 385, 72, this.t("sectorSelect"), "#00e5ff", "XARITA VA BIOM TANLASH", "🗺️", false);

      // Quick Ops Grid (Row 3: 4 buttons, y: 278)
      this.drawCyberButton(455, 278, 185, 62, this.t("bossRush"), "#ff1744", "TITANLAR", "💀", false);
      this.drawCyberButton(650, 278, 185, 62, this.t("mapEditor"), "#00e676", "TAHRIRLASH", "🛠️", false);
      this.drawCyberButton(855, 278, 185, 62, this.t("leaderboard"), "#ffd600", "REKORDLAR", "🏆", false);
      this.drawCyberButton(1055, 278, 185, 62, this.t("fieldManual"), "#00e5ff", "QO'LLANMA", "📖", false);

      // System Controls (Row 4: y: 350)
      this.drawCyberButton(455, 350, 255, 58, "SOZLAMALAR", "#00e5ff", "AUDIO & GRAFIKA", "⚙️", true);
      this.drawCyberButton(720, 350, 255, 58, "ANDROID APK", "#00e676", "OFLAYN APK (44MB)", "📲", true);
      this.drawCyberButton(985, 350, 255, 58, this.t("downloadOffline"), "#ffd600", "ZIP ARXIV (40MB)", "📦", false);

      // Commander Tactical Report & Dossier Panel (Bottom Right: y: 420 to 678)
      ctx.save();
      const dx = 455, dy = 420, dw = 785, dh = 258;
      ctx.fillStyle = "rgba(10, 18, 32, 0.92)";
      ctx.fillRect(dx, dy, dw, dh);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(dx, dy, dw, dh);

      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 15px 'Segoe UI', monospace";
      ctx.textAlign = "left";
      ctx.fillText("📊 KOMANDIR STRATEGIK HISOBOTI", dx + 24, dy + 32);

      // Stats 4-box grid
      const totalStars = Object.values(this.saveData.stars || {}).reduce((a, b) => a + b, 0);
      const boxes = [
        { label: "QO'LGA KIRITILGAN YULDUZLAR", val: `★ ${totalStars} / 30`, col: "#ffd600" },
        { label: "CHEKSIZ REKORD TO'LQINI", val: `Wave ${record}`, col: "#e040fb" },
        { label: "LIDERLIK BALLI", val: `${this.saveData.highScores?.campaign || 0} PTS`, col: "#00e5ff" },
        { label: "STANDALONE APK TIZIMI", val: "100% OFFLINE TAYYOR", col: "#00e676" }
      ];

      for (let i = 0; i < 4; i++) {
        const bx = dx + 20 + (i % 2) * 375;
        const by = dy + 50 + Math.floor(i / 2) * 72;
        ctx.fillStyle = "rgba(16, 28, 48, 0.85)";
        ctx.fillRect(bx, by, 360, 60);
        ctx.strokeStyle = "rgba(0, 229, 255, 0.25)";
        ctx.strokeRect(bx, by, 360, 60);

        ctx.fillStyle = "#90a4ae";
        ctx.font = "11px monospace";
        ctx.fillText(boxes[i].label, bx + 16, by + 22);

        ctx.fillStyle = boxes[i].col;
        ctx.font = "bold 18px 'Segoe UI', monospace";
        ctx.fillText(boxes[i].val, bx + 16, by + 47);
      }

      ctx.fillStyle = "#78909c";
      ctx.font = "11px monospace";
      ctx.fillText("💡 MASLAHAT: Jang paytida minora ustiga bosing — to'g'ridan-to'g'ri golografik taktik halqa ochiladi!", dx + 24, dy + 232);

      ctx.restore();
    }

    renderMenuButton(x, y, w, h, text, bg, fg, border) {
      const color = border || fg || "#00e5ff";
      const isHigh = (border === "#ffd600" || bg === "#00e5ff" || bg === "#ff007f" || border === "#00e676");
      this.drawCyberButton(x, y, w, h, text, color, "", "", isHigh);
    }

    renderFieldManual() {
      const ctx = this.ctx;
      const t = this.uiTime || 0;

      // 1. Deep space cyber grid background
      ctx.fillStyle = "#050813";
      ctx.fillRect(0, 0, this.width, this.height);

      ctx.strokeStyle = "rgba(0, 229, 255, 0.05)";
      ctx.lineWidth = 1;
      for (let x = 0; x <= this.width; x += 40) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.height); ctx.stroke();
      }
      for (let y = 0; y <= this.height; y += 40) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.width, y); ctx.stroke();
      }

      // 2. Top Header Bar with Tabs
      ctx.fillStyle = "rgba(10, 18, 32, 0.94)";
      ctx.fillRect(0, 0, this.width, 68);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(0, 0, this.width, 68);

      this.renderMiniButton(30, 16, 110, 36, "← MENYU", "#ff1744");

      ctx.fillStyle = "#00e5ff";
      ctx.font = "900 18px 'Segoe UI', monospace";
      ctx.textAlign = "left";
      ctx.fillText("⚡ KIBER-KODEX // INTEL", 160, 40);

      const tab = this.codexTab || 'TOWERS';
      this.drawCyberButton(440, 15, 165, 38, "⚡ MINORALAR", tab === 'TOWERS' ? "#00e5ff" : "#455a64", "TOWERS", "", tab === 'TOWERS');
      this.drawCyberButton(620, 15, 175, 38, "👾 DUSHMANLAR", tab === 'ENEMIES' ? "#00e676" : "#455a64", "HOSTILES", "", tab === 'ENEMIES');
      this.drawCyberButton(810, 15, 195, 38, "💀 GIGANT BOSSLAR", tab === 'BOSSES' ? "#ff1744" : "#455a64", "TITANS", "", tab === 'BOSSES');
      this.drawCyberButton(1020, 15, 185, 38, "🤖 APEX-01 MECH", tab === 'MECH' ? "#ffd600" : "#455a64", "FIELD HERO", "", tab === 'MECH');

      // 3. Codex Database
      const codexData = {
        TOWERS: [
          { id: 'pulse', name: 'Pulse Turret', icon: '⚡', role: 'Rapid Energy Blaster', type: 'ENERGY', cost: '100g', hp: 'N/A', dmg: '22 (High DPS)', rate: '3.5/s', range: '140px', armor: 'N/A', desc: "Yuqori chastotali lazer zarbalari beruvchi asosiy kiber-minora. Standart va tezkor dushmanlarga qarshi juda samarali.", branchA: "Plasma Overcharge (+55% DMG, Plazma portlashi)", branchB: "Gatling Overdrive (+85% O'q tezligi, 2x dps)", col: "#00e5ff" },
          { id: 'mortar', name: 'Heavy Mortar', icon: '💣', role: 'Artillery Blast', type: 'EXPLOSIVE', cost: '150g', hp: 'N/A', dmg: '85 (AoE Splash)', rate: '0.7/s', range: '220px', armor: 'N/A', desc: "Katta radiusda maydoniy portlash (AoE) beruvchi og'ir artilleriya. Zirhli dushmanlar va to'dalar uchun ideal.", branchA: "Cluster Munitions (4 ta qo'shimcha kassetali bomba)", branchB: "Napalm Fire (4 soniya davom etuvchi olov krateri)", col: "#ff9100" },
          { id: 'cryo', name: 'Cryo Emitter', icon: '❄️', role: 'Frost Field Slow', type: 'COLD', cost: '120g', hp: 'N/A', dmg: '14 (Slow 60%)', rate: '2.0/s', range: '130px', armor: 'N/A', desc: "Dushmanlarni 60% gacha muzlatuvchi va sekinlashtiruvchi kriogen nurlar emitteri. Tezkor dushmanlarni to'xtatadi.", branchA: "Deep Freeze (1.5 soniyaga to'liq muzlatish)", branchB: "Cryo Nova (360° to'lqinli muz portlashi)", col: "#00f0ff" },
          { id: 'tesla', name: 'Tesla Coil', icon: '⚡', role: 'Chain Lightning', type: 'ENERGY', cost: '180g', hp: 'N/A', dmg: '48 (Chain x4)', rate: '1.4/s', range: '150px', armor: 'N/A', desc: "Bir vaqtning o'zida 4-7 ta yaqin atrofdagi dushmanga zanjirsimon elektr toki ulovchi qurol.", branchA: "EMP Disruption (1.2 soniya falaj qiluvchi shok)", branchB: "Overload Burst (Har zarbada qo'shimcha to'lqin)", col: "#ffd600" },
          { id: 'flame', name: 'Flame Thrower', icon: '🔥', role: 'Conical Napalm Burn', type: 'FIRE', cost: '160g', hp: 'N/A', dmg: '32 (Burn DoT)', rate: '2.8/s', range: '135px', armor: 'N/A', desc: "Konus shaklidagi olov purkab, dushmanlarga 3 soniya uzluksiz yonish zarari (DoT) beradi.", branchA: "Napalm Puddle (Zaminni yoqib qoldirish)", branchB: "Armor Melt (Zirhni 70% eritib yuborish)", col: "#ff3d00" },
          { id: 'railgun', name: 'Railgun Sniper', icon: '🎯', role: 'Kinetic Piercer', type: 'PIERCE', cost: '240g', hp: 'N/A', dmg: '210 (Pierce)', rate: '0.5/s', range: '300px', armor: 'N/A', desc: "Butun xarita bo'ylab dushmanlarni teshib o'tuvchi gipertovushli magnit to'p.", branchA: "Hyper-Velocity (Cheksiz nishonlarni teshib o'tish)", branchB: "Shield Stripper (100% qalqonlarni sindirish)", col: "#ff007f" },
          { id: 'beacon', name: 'Radar Beacon', icon: '📡', role: 'Buff & Stealth Reveal', type: 'SUPPORT', cost: '200g', hp: 'N/A', dmg: '0 (Buff +35%)', rate: 'Aura', range: '160px', armor: 'N/A', desc: "Yaqin atrofdagi minoralarga +35% zarar beruvchi va ko'rinmas dushmanlarni fosh qiluvchi radar.", branchA: "Hyper Overclock (+50% minora tezligi)", branchB: "Sensor Jammer (Dushmanlarni sarosimaga solish)", col: "#76ff03" },
          { id: 'barricade', name: 'Cyber Barricade', icon: '🛡️', role: 'Defensive Barrier', type: 'BARRIER', cost: '40g', hp: '500 HP', dmg: '0', rate: 'Static', range: '0px', armor: '15 Armor', desc: "Dushmanlar harakatini to'sib, ularni aylanma yo'lga buruvchi mustahkam himoya to'sig'i.", branchA: "Reinforced Plating (1200 HP)", branchB: "Shock Spikes (Urilgan dushmanga 40 zarar)", col: "#ffd600" }
        ],
        ENEMIES: [
          { id: 'grunt', name: 'Cyber Grunt', icon: '◆', role: 'Basic Infantry', hp: '75 HP', dmg: 'Low', speed: '75 px/s', armor: '0', bounty: '8g', desc: "Standart kiber-piyoda dushman. Kuchli emas, ammo to'da bo'lib hujum qiladi.", col: "#00e5ff" },
          { id: 'sprinter', name: 'Sprinter Drone', icon: '▲', role: 'Fast Infiltrator', hp: '45 HP', dmg: 'Low', speed: '135 px/s', armor: '0', bounty: '10g', desc: "Juda yuqori tezlikka ega engil dron. Cryo yoki Tesla bilan sekinlashtirish zarur.", col: "#ffd600" },
          { id: 'brute', name: 'Armored Brute', icon: '■', role: 'Heavy Ground Breaker', hp: '280 HP', dmg: 'High', speed: '45 px/s', armor: '8 Armor', bounty: '22g', desc: "Qalin zirh bilan qoplangan og'ir robot. Railgun va Mortar zarbalariga zaif.", col: "#ff007f" },
          { id: 'shieldbearer', name: 'Shieldbearer', icon: '⬢', role: 'Energy Shielded', hp: '160 HP', dmg: 'Medium', speed: '60 px/s', armor: '120 Shield', bounty: '25g', desc: "O'zini va ittifoqchilarini energiya qalqoni bilan himoya qiladi. EMP orqali qalqoni buziladi.", col: "#00b0ff" },
          { id: 'medic', name: 'Nanite Medic', icon: '✚', role: 'Field Healer', hp: '140 HP', dmg: 'Heal 25/s', speed: '65 px/s', armor: '0', bounty: '28g', desc: "Yaqin atrofdagi dushmanlarni soniyasiga +25 HP bilan davolaydi. Birinchi bo'lib yo'q qilinishi kerak.", col: "#00e676" },
          { id: 'splitter', name: 'Splitter Organism', icon: '❖', role: 'Dividing Menace', hp: '190 HP', dmg: 'Medium', speed: '55 px/s', armor: '2 Armor', bounty: '18g', desc: "O'ldirilganda ikkita kichik tezkor Swarmlingga bo'linadi.", col: "#ffab00" },
          { id: 'phantom', name: 'Phantom Ghost', icon: '◌', role: 'Phase Shifter', hp: '120 HP', dmg: 'Medium', speed: '80 px/s', armor: 'Phasing', bounty: '30g', desc: "Har 4 soniyada fazoviy g'oyib bo'ladi. Radar Beacon orqali ko'rinadigan qilinadi.", col: "#b388ff" },
          { id: 'kamikaze_drone', name: 'Kamikaze Drone', icon: '💥', role: 'Suicide Flyer', hp: '60 HP', dmg: '120 AoE', speed: '160 px/s', armor: '0', bounty: '15g', desc: "Uchuvchi havo dushmani. Baza yoki qahramon tomon uchib kelib portlaydi.", col: "#ff1744" },
          { id: 'gunship', name: 'Heavy Gunship', icon: '🚁', role: 'Aerial Corvette', hp: '480 HP', dmg: 'Laser Salvo', speed: '50 px/s', armor: '6 Armor', bounty: '45g', desc: "Havodan minoralarni o'qqa tutuvchi og'ir uchuvchi kiber-korvet.", col: "#ff5252" }
        ],
        BOSSES: [
          { id: 'juggernaut', name: 'Goliath Juggernaut', icon: '💀', role: 'Wave 10 Titan', hp: '6,000 HP', armor: '20 Armor', speed: '38 px/s', bounty: '150g', desc: "Super og'ir toshdek mustahkam titan. Zirhni teshuvchi Railgun va Flame minoralariga zaif.", col: "#ff1744" },
          { id: 'overseer', name: 'Cyber Overseer', icon: '👁️', role: 'Wave 20 Titan', hp: '9,000 HP', armor: '14 Armor', speed: '42 px/s', bounty: '250g', desc: "Doimiy ravishda Sprinter dronlarni maydonga chiqaradi va energiya to'lqinlari sochadi.", col: "#e040fb" },
          { id: 'hive_titan', name: 'Hive Titan', icon: '👑', role: 'Wave 30 Titan', hp: '20,000 HP', armor: '22 Armor', speed: '40 px/s', bounty: '500g', desc: "3 ta jangga bo'lingan faza va enrage paytida +40% tezlanishga ega bosh titan.", col: "#ffd600" },
          { id: 'void_titan', name: 'Void Titan', icon: '🌀', role: 'Singularity Colossus', hp: '8,500 HP', armor: '18 Armor', speed: '36 px/s', bounty: '320g', desc: "Atrofidagi narsalarni tortib oluvchi qora tuynuk gravitatsion voronkasini yaratadi.", col: "#7c4dff" },
          { id: 'chrono_phantom', name: 'Chrono Phantom', icon: '⌛', role: 'Temporal Anomaly', hp: '7,200 HP', armor: '12 Armor', speed: '46 px/s', bounty: '300g', desc: "Minoralarni 50% vaqt to'lqini bilan sekinlashtiradi va 4 soniyada 120px oldinga sakraydi.", col: "#00e5ff" },
          { id: 'mecha_colossus', name: 'Mecha Colossus', icon: '🤖', role: 'Mobile Fortress', hp: '11,000 HP', armor: '26 Armor', speed: '32 px/s', bounty: '400g', desc: "Qo'shaloq raketalar salvosi va 120mm to'p bilan minoralarga javob zarbasi beruvchi devqomat.", col: "#ff9100" }
        ],
        MECH: [
          { id: 'biped', name: 'Apex-01 (Assault Biped)', icon: '🤖', role: 'Field Commander Mech', hp: '400 HP', speed: '130 px/s', dmg: '40 Kinetic', ultDmg: '400 Cyber-Slash', desc: "Manyovrli yuruvchi robot. 2 ta aylanuvchi lazer Gatling pulemyoti, kinetik tezlanish (Dash) va 400 zarbali Cyber-Slash ultisi bor.", col: "#00e5ff" },
          { id: 'siege', name: 'Apex-01 (Siege Tank)', icon: '🚜', role: 'Heavy Dual Artillery', hp: '400 HP', speed: '90 px/s', dmg: '140 Explosive', splash: '70px AoE', desc: "O'rnatiladigan og'ir tank. Qabul qiluvchi zarbalarni 50% kamaytiradi (og'ir zirh) va 70px maydonda portlovchi qo'shaloq 120mm artilleriya otadi.", col: "#ffd600" }
        ]
      };

      const list = codexData[tab] || codexData.TOWERS;
      let activeItem = list.find(i => i.id === this.codexSelectedId);
      if (!activeItem) {
        activeItem = list[0];
        this.codexSelectedId = activeItem.id;
      }

      // 4. Left List Column (x: 30, y: 78, w: 290, h: 625)
      ctx.fillStyle = "rgba(10, 18, 32, 0.92)";
      ctx.fillRect(30, 78, 290, 625);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(30, 78, 290, 625);

      const itemH = Math.min(68, Math.floor(590 / list.length));
      for (let i = 0; i < list.length; i++) {
        const item = list[i];
        const iy = 88 + i * (itemH + 4);
        const isSel = (item.id === activeItem.id);

        this.drawCyberButton(38, iy, 274, itemH, `${item.icon} ${item.name}`, isSel ? (item.col || "#00e5ff") : "#455a64", item.role, "", isSel);
      }

      // 5. Right Holographic Bay (x: 335, y: 78, w: 915, h: 625)
      ctx.fillStyle = "rgba(8, 14, 26, 0.95)";
      ctx.fillRect(335, 78, 915, 625);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(335, 78, 915, 625);

      // Left Sub-bay: 3D Turntable Hologram Pedestal (x: 350, y: 90, w: 400, h: 600)
      const px = 550;
      const py = 390;

      // Holographic Turntable Base
      ctx.strokeStyle = "rgba(0, 229, 255, 0.5)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.ellipse(px, py + 120, 140, 45, 0, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = activeItem.col || "#00e5ff";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(px, py + 120, 110, 35, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Rotating Scanner Rings
      const ringAng = t * 1.5;
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1.2;
      ctx.setLineDash([8, 12]);
      ctx.beginPath();
      ctx.ellipse(px, py + 120, 160, 52, ringAng, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Vertical Laser Scanner Line
      const scanY = py - 80 + Math.sin(t * 3) * 110;
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(px - 100, scanY);
      ctx.lineTo(px + 100, scanY);
      ctx.stroke();

      // Procedural Live Visual Model in Hologram Center
      ctx.save();
      ctx.translate(px, py + 30);
      const rotAng = t * 1.2;

      if (tab === 'TOWERS') {
        // Tower Base Hexagon
        ctx.fillStyle = "#1e293b";
        ctx.strokeStyle = activeItem.col || "#00e5ff";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        for (let a = 0; a < 6; a++) {
          const ang = (Math.PI / 3) * a;
          const hx = Math.cos(ang) * 45;
          const hy = Math.sin(ang) * 45;
          if (a === 0) ctx.moveTo(hx, hy); else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Rotating Turret Barrels
        ctx.rotate(rotAng);
        ctx.fillStyle = activeItem.col || "#00e5ff";
        ctx.fillRect(-8, -48, 16, 48);
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(0, 0, 20, 0, Math.PI * 2);
        ctx.fill();
      } else if (tab === 'BOSSES') {
        // Giant Boss Hologram
        ctx.fillStyle = activeItem.col || "#ff1744";
        ctx.shadowColor = activeItem.col || "#ff1744";
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.arc(0, 0, 55, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 3;
        ctx.stroke();

        ctx.rotate(rotAng);
        ctx.strokeStyle = "#ffd600";
        ctx.lineWidth = 2;
        ctx.strokeRect(-45, -45, 90, 90);
      } else if (tab === 'MECH') {
        // Apex-01 Mech Chassis
        ctx.fillStyle = activeItem.col || "#00e5ff";
        ctx.shadowColor = activeItem.col || "#00e5ff";
        ctx.shadowBlur = 15;
        ctx.fillRect(-35, -45, 70, 75);
        ctx.shadowBlur = 0;

        ctx.fillStyle = "#ffffff";
        ctx.fillRect(-20, -25, 40, 10);
        ctx.fillStyle = "#455a64";
        ctx.fillRect(-45, -20, 10, 45);
        ctx.fillRect(35, -20, 10, 45);
      } else {
        // Enemy Hologram
        ctx.fillStyle = activeItem.col || "#00e676";
        ctx.shadowColor = activeItem.col || "#00e676";
        ctx.shadowBlur = 14;
        ctx.beginPath();
        ctx.arc(0, 0, 40, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      ctx.restore();

      // Telemetry Label below pedestal
      ctx.fillStyle = "#78909c";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("HOLO-FEED // 360° TURNTABLE // ACTIVE", px, py + 185);

      // Right Sub-bay: Tactical Dossier & Specs (x: 770, y: 90, w: 460, h: 600)
      const tx = 770;
      ctx.textAlign = "left";
      ctx.fillStyle = activeItem.col || "#00e5ff";
      ctx.font = "900 24px 'Segoe UI', monospace";
      ctx.shadowColor = activeItem.col || "#00e5ff";
      ctx.shadowBlur = 10;
      ctx.fillText(activeItem.name.toUpperCase(), tx, 125);
      ctx.shadowBlur = 0;

      ctx.fillStyle = "#b0bec5";
      ctx.font = "bold 13px monospace";
      ctx.fillText(`KLASSIFIKATSIYA: ${activeItem.role.toUpperCase()}`, tx, 150);

      // Spec Meters Grid
      const specs = [
        { label: "XARAJAT / NARXI", val: activeItem.cost || activeItem.bounty || 'N/A' },
        { label: "HAYOTIY KUCH (HP)", val: activeItem.hp || 'N/A' },
        { label: "ZARBA / DPS", val: activeItem.dmg || activeItem.ultDmg || 'N/A' },
        { label: "HUJUM RADIUSI", val: activeItem.range || 'N/A' },
        { label: "HARAKAT TEZLIGI", val: activeItem.speed || activeItem.rate || 'N/A' },
        { label: "ZIRH / RESISTANCE", val: activeItem.armor || '0' }
      ];

      for (let s = 0; s < specs.length; s++) {
        const sy = 185 + s * 48;
        ctx.fillStyle = "rgba(16, 28, 48, 0.85)";
        ctx.fillRect(tx, sy, 450, 40);
        ctx.strokeStyle = "rgba(0, 229, 255, 0.25)";
        ctx.strokeRect(tx, sy, 450, 40);

        ctx.fillStyle = "#90a4ae";
        ctx.font = "bold 11px monospace";
        ctx.fillText(specs[s].label, tx + 14, sy + 25);

        ctx.fillStyle = "#ffd600";
        ctx.font = "bold 13px monospace";
        ctx.textAlign = "right";
        ctx.fillText(specs[s].val, tx + 436, sy + 25);
        ctx.textAlign = "left";
      }

      // Branch Perks or Description Box
      const boxY = 490;
      ctx.fillStyle = "rgba(14, 24, 42, 0.95)";
      ctx.fillRect(tx, boxY, 450, 185);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
      ctx.strokeRect(tx, boxY, 450, 185);

      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 13px monospace";
      ctx.fillText("TACTICAL INTEL & BLUEPRINT:", tx + 14, boxY + 26);

      ctx.fillStyle = "#cfd8dc";
      ctx.font = "11px monospace";
      this.wrapText(activeItem.desc, tx + 14, boxY + 50, 422, 16);

      if (activeItem.branchA) {
        ctx.fillStyle = "#00e676";
        ctx.font = "bold 11px monospace";
        ctx.fillText(`[A] ${activeItem.branchA}`, tx + 14, boxY + 120);
        ctx.fillStyle = "#ffd600";
        ctx.fillText(`[B] ${activeItem.branchB}`, tx + 14, boxY + 146);
      }
    }

    renderMapSelect() {
      const ctx = this.ctx;
      const bgGrad = ctx.createLinearGradient(0, 0, 0, this.height);
      bgGrad.addColorStop(0, "#050811");
      bgGrad.addColorStop(1, "#03050a");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, this.width, this.height);

      ctx.textAlign = "left";
      ctx.fillStyle = "#00e5ff";
      ctx.font = "900 26px 'Segoe UI', monospace";
      ctx.fillText(this.t("sectorSelect"), 170, 48);

      // Total campaign stars display
      let totalStars = 0;
      for (const m of MAPS) totalStars += (this.saveData.stars[m.id] || 0);
      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 15px monospace";
      ctx.textAlign = "right";
      ctx.fillText(`KAMPANIYA: ${totalStars} / 30 ★`, 1240, 45);

      // Difficulty Selector Pill (CASUAL / NORMAL / HEROIC)
      const diffs = ['CASUAL', 'NORMAL', 'HEROIC'];
      ctx.fillStyle = "rgba(10, 25, 47, 0.9)";
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(580, 20, 335, 34, 6);
      ctx.fill();
      ctx.stroke();
      diffs.forEach((d, idx) => {
        const dx = 584 + idx * 110;
        const isCur = this.difficulty === d;
        if (isCur) {
          ctx.fillStyle = "#00e5ff";
          ctx.beginPath();
          ctx.roundRect(dx, 23, 105, 28, 4);
          ctx.fill();
        }
        ctx.fillStyle = isCur ? "#030712" : "#94a3b8";
        ctx.font = "900 12px monospace";
        ctx.textAlign = "center";
        ctx.fillText(d, dx + 52, 42);
      });

      this.renderMiniButton(40, 20, 110, 36, "← MENYU", "#ff1744");

      for (let i = 0; i < MAPS.length; i++) {
        const m = MAPS[i];
        const col = i % 5;
        const row = Math.floor(i / 5);
        const x = 40 + col * 242;
        const y = 75 + row * 245;
        const starsEarned = this.saveData.stars[m.id] || 0;
        const isCompleted = starsEarned > 0;

        ctx.save();
        const cut = 8;
        ctx.beginPath();
        ctx.moveTo(x + cut, y);
        ctx.lineTo(x + 230, y);
        ctx.lineTo(x + 230, y + 230 - cut);
        ctx.lineTo(x + 230 - cut, y + 230);
        ctx.lineTo(x, y + 230);
        ctx.lineTo(x, y + cut);
        ctx.closePath();

        const cardGrad = ctx.createLinearGradient(x, y, x, y + 230);
        cardGrad.addColorStop(0, "rgba(16, 26, 44, 0.96)");
        cardGrad.addColorStop(1, "rgba(8, 14, 24, 0.98)");
        ctx.fillStyle = cardGrad;
        ctx.fill();

        ctx.strokeStyle = isCompleted ? "#00e676" : "#00e5ff";
        ctx.lineWidth = 1.3;
        ctx.stroke();

        ctx.fillStyle = isCompleted ? "#00e676" : "#00e5ff";
        ctx.fillRect(x, y + cut, 4, 30);

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 13px 'Segoe UI', monospace";
        ctx.textAlign = "left";
        ctx.fillText(`0${i + 1}. ${m.name.toUpperCase()}`, x + 14, y + 24);

        ctx.fillStyle = "#90a4ae";
        ctx.font = "11px 'Segoe UI', monospace";
        this.wrapText(m.desc, x + 14, y + 48, 202, 16);

        ctx.fillStyle = "#ffd600";
        ctx.font = "bold 12px monospace";
        const starStr = "★".repeat(starsEarned) + "☆".repeat(3 - starsEarned);
        ctx.fillText(`${starStr} (${starsEarned}/3)`, x + 14, y + 140);

        ctx.fillStyle = "#00e5ff";
        ctx.font = "11px monospace";
        const biomeTag = (m.biome === 'lava') ? "🌋 LAVA" : (m.biome === 'cryo' ? "❄️ CRYO" : "⚡ CYBER");
        const biomeColor = (m.biome === 'lava') ? "#ff5722" : (m.biome === 'cryo' ? "#80deea" : "#00e5ff");
        ctx.fillText(`WAVES: ${m.wave_count}`, x + 14, y + 160);
        ctx.fillStyle = biomeColor;
        ctx.fillText(biomeTag, x + 105, y + 160);

        this.drawCyberButton(x + 12, y + 176, 206, 42, "JANGGA KIRISH", isCompleted ? "#00e676" : "#00e5ff", `SECTOR 0${i + 1}`, "▶", true);

        ctx.restore();
      }

      // 11. Custom Created Map Card (y: 565, w: 1200, h: 135)
      const savedCustom = localStorage.getItem('lg_custom_map');
      let customData = null;
      if (savedCustom) {
        try { customData = JSON.parse(savedCustom); } catch(e) {}
      }
      const cWaypoints = (customData && customData.waypoints) ? customData.waypoints : this.editorWaypoints;
      const cBiome = (customData && customData.biome) ? customData.biome : (this.editorBiome || 'cyber');
      const cGold = (customData && customData.gold) ? customData.gold : (this.editorGold || 350);
      const cWaves = (customData && customData.waves) ? customData.waves : (this.editorWaves || 20);

      const cx = 40, cy = 565, cw = 1200, ch = 135;
      ctx.save();
      ctx.fillStyle = "rgba(12, 22, 38, 0.95)";
      ctx.beginPath();
      ctx.roundRect(cx, cy, cw, ch, 8);
      ctx.fill();
      ctx.strokeStyle = "#ffd600";
      ctx.lineWidth = 1.8;
      ctx.stroke();

      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 16px 'Segoe UI', monospace";
      ctx.textAlign = "left";
      ctx.fillText("🛠️ SHAXSIY XARITA (CUSTOM LEVEL)", cx + 24, cy + 32);

      ctx.fillStyle = "#94a3b8";
      ctx.font = "12px monospace";
      ctx.fillText(`Nuqtalar: ${cWaypoints.length} ta  |  Biom: ${cBiome.toUpperCase()}  |  Boshlang'ich Oltin: ${cGold}G  |  To'lqinlar: ${cWaves}`, cx + 24, cy + 58);
      ctx.fillText("Xarita muharririda o'zingiz chizgan maxsus xaritani darhol sinab ko'ring yoki qayta tahrirlang!", cx + 24, cy + 82);

      this.drawCyberButton(cx + 780, cy + 32, 220, 70, "▶ MAXSUS O'YIN", "#00e676", "PLAY CUSTOM", "🚀", true);
      this.drawCyberButton(cx + 1020, cy + 32, 160, 70, "✏️ TAHRIRLASH", "#00e5ff", "EDIT MAP", "🛠️", false);
      ctx.restore();
    }

    renderEditor() {
      const ctx = this.ctx;
      const bColor = (this.editorBiome === 'lava') ? "#1a0808" : (this.editorBiome === 'cryo' ? "#05131e" : "#070b14");
      ctx.fillStyle = bColor;
      ctx.fillRect(0, 0, this.width, this.height);

      // Top Toolbar Header
      ctx.fillStyle = "#0c1527";
      ctx.fillRect(0, 0, this.width, 65);
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(0, 0, this.width, 65);

      this.renderMiniButton(20, 15, 90, 36, "← MENYU", "#ff1744");
      this.renderMiniButton(120, 15, 125, 36, "▶ TEST O'YNASH", "#00e676");
      this.renderMiniButton(255, 15, 95, 36, "💾 SAQLASH", "#ffd600");
      this.renderMiniButton(360, 15, 95, 36, "🗑️ TOZALASH", "#ff5252");
      this.renderMiniButton(465, 15, 95, 36, "📋 EXPORT", "#00e5ff");
      this.renderMiniButton(570, 15, 95, 36, "📥 IMPORT", "#00e5ff");
      this.renderMiniButton(675, 15, 125, 36, `BIOM: ${(this.editorBiome || 'CYBER').toUpperCase()}`, (this.editorBiome === 'lava' ? "#ff5722" : (this.editorBiome === 'cryo' ? "#80deea" : "#00e5ff")));
      this.renderMiniButton(810, 15, 105, 36, `WAVES: ${this.editorWaves || 20}`, "#e040fb");
      this.renderMiniButton(925, 15, 110, 36, `GOLD: ${this.editorGold || 350}G`, "#ffd600");
      this.renderMiniButton(1045, 15, 85, 36, "UNDO ↩️", "#cfd8dc");

      // Subheader guide banner
      ctx.fillStyle = "rgba(12, 21, 39, 0.85)";
      ctx.fillRect(0, 65, this.width, 24);
      ctx.fillStyle = "#94a3b8";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("🎯 Kataklarni bosing: 1-nuqta = [SPAWN 🚪 Dushman kirishi], Oxirgi = [CORE 💎 Baza]. Nuqtani qayta bosish uni o'chiradi.", this.width / 2, 81);

      // Grid Lines
      const gridColor = (this.editorBiome === 'lava') ? "rgba(255, 61, 0, 0.12)" : (this.editorBiome === 'cryo' ? "rgba(0, 240, 255, 0.12)" : "rgba(0, 229, 255, 0.12)");
      ctx.strokeStyle = gridColor;
      ctx.lineWidth = 1;
      for (let x = 0; x <= this.width; x += 64) {
        ctx.beginPath(); ctx.moveTo(x, 90); ctx.lineTo(x, 700); ctx.stroke();
      }
      for (let y = 96; y <= 700; y += 64) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.width, y); ctx.stroke();
      }

      // Connecting Laser Path Highway
      if (this.editorWaypoints.length >= 2) {
        ctx.beginPath();
        ctx.moveTo(this.editorWaypoints[0].x, this.editorWaypoints[0].y);
        for (let i = 1; i < this.editorWaypoints.length; i++) {
          ctx.lineTo(this.editorWaypoints[i].x, this.editorWaypoints[i].y);
        }
        ctx.strokeStyle = "rgba(0, 229, 255, 0.35)";
        ctx.lineWidth = 42;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.stroke();

        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 6;
        ctx.stroke();

        // Directional arrows along path
        for (let i = 0; i < this.editorWaypoints.length - 1; i++) {
          const p1 = this.editorWaypoints[i];
          const p2 = this.editorWaypoints[i + 1];
          const mx = (p1.x + p2.x) / 2;
          const my = (p1.y + p2.y) / 2;
          const ang = Math.atan2(p2.y - p1.y, p2.x - p1.x);

          ctx.save();
          ctx.translate(mx, my);
          ctx.rotate(ang);
          ctx.fillStyle = "#ffd600";
          ctx.beginPath();
          ctx.moveTo(8, 0); ctx.lineTo(-6, -6); ctx.lineTo(-3, 0); ctx.lineTo(-6, 6);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        }
      }

      // Waypoint Nodes
      for (let i = 0; i < this.editorWaypoints.length; i++) {
        const pt = this.editorWaypoints[i];
        const isStart = (i === 0);
        const isEnd = (i === this.editorWaypoints.length - 1 && this.editorWaypoints.length >= 2);

        ctx.save();
        ctx.translate(pt.x, pt.y);

        if (isStart) {
          // Pulsing Red Portal Spawn
          ctx.fillStyle = "rgba(255, 23, 68, 0.25)";
          ctx.beginPath(); ctx.arc(0, 0, 24, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = "#ff1744";
          ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 2; ctx.stroke();
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 9px monospace";
          ctx.textAlign = "center";
          ctx.fillText("SPAWN 🚪", 0, -22);
          ctx.fillText("1", 0, 3);
        } else if (isEnd) {
          // Pulsing Cyan Base Core
          ctx.fillStyle = "rgba(0, 229, 255, 0.25)";
          ctx.beginPath(); ctx.arc(0, 0, 26, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = "#00e5ff";
          ctx.beginPath();
          ctx.moveTo(0, -16); ctx.lineTo(16, 0); ctx.lineTo(0, 16); ctx.lineTo(-16, 0);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 2; ctx.stroke();
          ctx.fillStyle = "#ffd600";
          ctx.font = "bold 9px monospace";
          ctx.textAlign = "center";
          ctx.fillText("CORE 💎", 0, -22);
          ctx.fillStyle = "#000";
          ctx.fillText(`${i + 1}`, 0, 3);
        } else {
          // Intermediate Amber Waypoint
          ctx.fillStyle = "#ffd600";
          ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = "#000000"; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.fillStyle = "#000";
          ctx.font = "bold 10px monospace";
          ctx.textAlign = "center";
          ctx.fillText(`${i + 1}`, 0, 4);
        }
        ctx.restore();
      }
    }

    renderLeaderboardModal() {
      this.ctx.fillStyle = "#05070d";
      this.ctx.fillRect(0, 0, this.width, this.height);

      this.ctx.textAlign = "left";
      this.ctx.fillStyle = "#00e5ff";
      this.ctx.font = "bold 26px 'Segoe UI', monospace";
      this.ctx.fillText(this.t("leaderboard"), 60, 55);

      this.renderMiniButton(60, 20, 90, 32, "← MENU");
      this.renderMiniButton(1050, 20, 170, 32, `HANDLE: ${this.playerName}`);

      this.ctx.fillStyle = "#162238";
      this.ctx.fillRect(60, 90, 1160, 40);
      this.ctx.fillStyle = "#ffd600";
      this.ctx.font = "bold 14px monospace";
      this.ctx.fillText("RANK", 80, 115);
      this.ctx.fillText("COMMANDER", 180, 115);
      this.ctx.fillText("SECTOR", 460, 115);
      this.ctx.fillText("WAVE REACHED", 760, 115);
      this.ctx.fillText("TACTICAL SCORE", 1000, 115);

      const rows = this.saveData.leaderboard.slice(0, 11);
      for (let i = 0; i < rows.length; i++) {
        const r = rows[i];
        const y = 150 + i * 44;
        this.ctx.fillStyle = i % 2 === 0 ? "rgba(12, 21, 39, 0.7)" : "rgba(22, 34, 56, 0.4)";
        this.ctx.fillRect(60, y - 22, 1160, 40);

        this.ctx.fillStyle = i === 0 ? "#ffd600" : (i === 1 ? "#00e5ff" : "#cfd8dc");
        this.ctx.font = "bold 14px monospace";
        this.ctx.fillText(`#${i + 1}`, 80, y);
        this.ctx.fillText(r.player_name, 180, y);
        this.ctx.fillText(r.map_id.toUpperCase(), 460, y);
        this.ctx.fillText(`Wave ${r.wave_reached}`, 760, y);
        this.ctx.fillText(`${r.score} PTS`, 1000, y);
      }
    }

    wrapText(text, x, y, maxWidth, lineHeight) {
      const words = text.split(' ');
      let line = '';
      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = this.ctx.measureText(testLine);
        if (metrics.width > maxWidth && n > 0) {
          this.ctx.fillText(line, x, y);
          line = words[n] + ' ';
          y += lineHeight;
        } else {
          line = testLine;
        }
      }
      this.ctx.fillText(line, x, y);
    }

    renderPauseModal() {
      const ctx = this.ctx;
      ctx.fillStyle = "rgba(4, 7, 14, 0.92)";
      ctx.fillRect(0, 0, this.width, this.height);

      ctx.save();
      ctx.shadowColor = "rgba(0, 229, 255, 0.7)";
      ctx.shadowBlur = 18;
      ctx.fillStyle = "#00e5ff";
      ctx.font = "900 42px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.fillText("TAKTIK PAUZA", 640, 270);
      ctx.restore();

      ctx.fillStyle = "#b0bec5";
      ctx.font = "14px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.fillText("Jang to'xtatildi. Qaytish yoki menyuga chiqish uchun tugmani bosing:", 640, 320);

      this.drawCyberButton(440, 340, 400, 50, "DAVOM ETISH", "#00e676", "RESUME COMBAT", "▶", true);
      this.drawCyberButton(440, 405, 400, 50, "SOZLAMALAR", "#00e5ff", "AUDIO & SCREEN SETTINGS", "⚙️", false);
      this.drawCyberButton(440, 470, 400, 50, "ASOSIY MENYUGA QAYTISH", "#ff1744", "ABORT MISSION", "←", false);
    }

    renderVictoryModal() {
      const ctx = this.ctx;
      ctx.fillStyle = "rgba(4, 7, 14, 0.94)";
      ctx.fillRect(0, 0, this.width, this.height);

      ctx.save();
      ctx.shadowColor = "rgba(0, 230, 118, 0.8)";
      ctx.shadowBlur = 24;
      ctx.fillStyle = "#00e676";
      ctx.font = "900 46px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.fillText("🏆 G'ALABA! SEKTOR HIMOYALANDI", 640, 210);
      ctx.restore();

      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 22px monospace";
      ctx.textAlign = "center";
      ctx.fillText(this.t("missionSuccess"), 640, 265);

      ctx.fillStyle = "rgba(18, 30, 50, 0.9)";
      ctx.fillRect(360, 295, 560, 42);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.strokeRect(360, 295, 560, 42);
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 14px monospace";
      ctx.fillText(`TAKTIK BALL: ${this.score} PTS  |  MVP MINORA: ${this.analytics.mvpName.toUpperCase()}`, 640, 322);

      this.drawCyberButton(340, 410, 180, 52, this.t("playAgain"), "#00e676", "RETRY SECTOR", "▶", true);
      this.drawCyberButton(550, 410, 180, 52, "STATISTIKA", "#ffd600", "BATTLE REPORT", "📊", false);
      this.drawCyberButton(760, 410, 180, 52, this.t("mainMenu"), "#00e5ff", "COMMAND HQ", "←", false);

      this.drawCyberButton(340, 475, 600, 50, "♾️ CHEKSIZ REJIMDA DAVOM ETISH", "#e040fb", "KEEP TOWERS & FACE INFINITE HORDE", "⚡", true);
    }

    renderDefeatModal() {
      const ctx = this.ctx;
      ctx.fillStyle = "rgba(4, 7, 14, 0.94)";
      ctx.fillRect(0, 0, this.width, this.height);

      ctx.save();
      const isEndless = (this.gameMode === 'ENDLESS');
      ctx.shadowColor = isEndless ? "rgba(224, 64, 251, 0.85)" : "rgba(255, 23, 68, 0.85)";
      ctx.shadowBlur = 24;
      ctx.fillStyle = isEndless ? "#e040fb" : "#ff1744";
      ctx.font = "900 44px 'Segoe UI', monospace";
      ctx.textAlign = "center";
      ctx.fillText(isEndless ? "♾️ CHEKSIZ REJIM YAKUNLANDI" : "💀 SEKTOR VAYRON BO'LDI", 640, 210);
      ctx.restore();

      ctx.fillStyle = "#b0bec5";
      ctx.font = "bold 17px monospace";
      ctx.textAlign = "center";
      const record = localStorage.getItem('lg_endless_wave') || this.wave;
      const descStr = isEndless
        ? `Erishilgan to'lqin: Wave ${this.wave}  |  Shaxsiy rekord: Wave ${record}  |  Ball: ${this.score} PTS`
        : `Dushmanlar ${this.wave}-to'lqinda bazani yorib o'tdi. To'plangan ball: ${this.score} PTS`;
      ctx.fillText(descStr, 640, 270);

      this.drawCyberButton(340, 410, 180, 52, this.t("retry"), isEndless ? "#e040fb" : "#ff1744", "RESTART", "🔄", true);
      this.drawCyberButton(550, 410, 180, 52, "STATISTIKA", "#ffd600", "BATTLE REPORT", "📊", false);
      this.drawCyberButton(760, 410, 180, 52, this.t("mainMenu"), "#00e5ff", "COMMAND HQ", "←", false);
    }

    // =========================================================================
    // --- 3D THIRD-PERSON SHOOTER & BASE DEFENSE ARENA ENGINE (v3.4 3D) ---
    // =========================================================================

    start3DTPSMode() {
      this.state = 'TPS_3D';
      audio.victory();
      this.tps3D = {
        player: {
          x: 0, y: 0, z: 12,
          yaw: 0,
          pitch: 0.08,
          speed: 14.0,
          isAiming: false,
          health: 100, maxHealth: 100,
          ammo: 30, maxAmmo: 30, reserveAmmo: 120,
          isReloading: false, reloadTimer: 0,
          fireCd: 0,
          walkAnim: 0,
          recoil: 0,
          hasRedDot: true,
          hasLaser: true
        },
        core: { x: 0, y: 0, z: -35, health: 500, maxHealth: 500, radius: 4 },
        enemies: [],
        towers: [],
        bullets: [],
        particles: [],
        score: 0,
        wave: 1,
        waveTimer: 4.0,
        waveActive: false,
        spawnQueue: 0,
        spawnInterval: 0,
        isBuilding: false,
        keys: { w: false, a: false, s: false, d: false, shift: false },
        touch: {
          moveId: null,
          moveStart: { x: 0, y: 0 },
          moveVec: { x: 0, y: 0 },
          lookId: null,
          lookLast: { x: 0, y: 0 }
        }
      };
      this.addFloatingText("3D TPS ARENA: WELCOME COMMANDER!", 640, 180, "#00e5ff", 24);
      this.startWave3DTPS();
    }

    startWave3DTPS() {
      const t = this.tps3D;
      t.waveActive = true;
      t.spawnQueue = 6 + t.wave * 4;
      t.spawnInterval = 1.0;
      this.addFloatingText(`WAVE ${t.wave} INCOMING!`, 640, 220, "#ff1744", 26);
    }

    update3DTPS(dt) {
      const t = this.tps3D;
      const p = t.player;

      // 1. Player Movement along Camera Yaw
      let moveX = 0;
      let moveZ = 0;
      if (t.keys.w) moveZ -= 1;
      if (t.keys.s) moveZ += 1;
      if (t.keys.a) moveX -= 1;
      if (t.keys.d) moveX += 1;

      // Mobile Touch Joystick Input
      if (t.touch.moveId !== null) {
        moveX += t.touch.moveVec.x;
        moveZ += t.touch.moveVec.y;
      }

      const inputLen = Math.hypot(moveX, moveZ);
      if (inputLen > 0.05) {
        const normX = moveX / inputLen;
        const normZ = moveZ / inputLen;
        const effSpeed = p.speed * (t.keys.shift ? 1.5 : 1.0) * (p.isAiming ? 0.6 : 1.0);

        // Transform movement relative to camera yaw
        const worldMoveX = Math.cos(p.yaw) * normX + Math.sin(p.yaw) * normZ;
        const worldMoveZ = -Math.sin(p.yaw) * normX + Math.cos(p.yaw) * normZ;

        p.x += worldMoveX * effSpeed * dt;
        p.z += worldMoveZ * effSpeed * dt;
        p.walkAnim += dt * (t.keys.shift ? 14 : 9);

        // Clamp to 500x500m arena boundaries
        p.x = Math.max(-55, Math.min(55, p.x));
        p.z = Math.max(-65, Math.min(45, p.z));
      } else {
        p.walkAnim = 0;
      }

      // Gun Fire Cooldown, Skills & Recoil Decay
      if (p.fireCd > 0) p.fireCd = Math.max(0, p.fireCd - dt);
      if (p.missileCd > 0) p.missileCd = Math.max(0, p.missileCd - dt);
      if (p.empCd > 0) p.empCd = Math.max(0, p.empCd - dt);
      if (p.recoil > 0) p.recoil = Math.max(0, p.recoil - dt * 10);

      // Reloading
      if (p.isReloading) {
        p.reloadTimer -= dt;
        if (p.reloadTimer <= 0) {
          const needed = p.maxAmmo - p.ammo;
          const load = Math.min(needed, p.reserveAmmo);
          p.ammo += load;
          p.reserveAmmo -= load;
          p.isReloading = false;
          audio.upgrade();
        }
      }

      // 2. Wave Spawning
      if (t.waveActive) {
        t.spawnInterval -= dt;
        if (t.spawnInterval <= 0 && t.spawnQueue > 0) {
          t.spawnQueue--;
          t.spawnInterval = 1.1;
          const ang = Math.random() * Math.PI - Math.PI / 2;
          const dist = 75;
          const ex = Math.sin(ang) * dist;
          const ez = -35 - Math.cos(ang) * (dist * 0.7);
          const randType = Math.random();
          const eType = randType < 0.20 ? 'kamikaze' : (randType < 0.40 ? 'gunship' : (randType < 0.65 ? 'brute' : (randType < 0.85 ? 'sprinter' : 'grunt')));
          t.enemies.push({
            type: eType,
            x: ex, y: (eType === 'gunship' ? 3.5 : 0), z: ez,
            hp: eType === 'brute' ? 350 : (eType === 'gunship' ? 240 : (eType === 'kamikaze' ? 65 : (eType === 'sprinter' ? 60 : 120))),
            maxHp: eType === 'brute' ? 350 : (eType === 'gunship' ? 240 : (eType === 'kamikaze' ? 65 : (eType === 'sprinter' ? 60 : 120))),
            speed: eType === 'kamikaze' ? 16 : (eType === 'sprinter' ? 12 : (eType === 'gunship' ? 8.5 : (eType === 'brute' ? 4.5 : 7.0))),
            size: eType === 'brute' ? 1.8 : (eType === 'gunship' ? 1.4 : 1.1),
            color: eType === 'kamikaze' ? '#ff3d00' : (eType === 'gunship' ? '#00e5ff' : (eType === 'brute' ? '#ffd600' : (eType === 'sprinter' ? '#ff9100' : '#ff1744'))),
            atkCd: 0,
            stunTimer: 0
          });
        }
        if (t.spawnQueue <= 0 && t.enemies.length === 0) {
          t.waveActive = false;
          t.wave++;
          t.waveTimer = 6.0;
          this.addFloatingText(`WAVE COMPLETE! +${t.wave * 100} PTS`, 640, 220, "#00e676", 24);
        }
      } else {
        t.waveTimer -= dt;
        if (t.waveTimer <= 0) this.startWave3DTPS();
      }

      // 3. Enemies Update
      for (let i = t.enemies.length - 1; i >= 0; i--) {
        const e = t.enemies[i];
        if (e.stunTimer > 0) {
          e.stunTimer -= dt;
          continue;
        }

        const distToPlayer = Math.hypot(p.x - e.x, p.z - e.z);
        let targetX = t.core.x;
        let targetZ = t.core.z;

        if (distToPlayer < 14) {
          targetX = p.x;
          targetZ = p.z;
        }

        const angleToTarget = Math.atan2(targetX - e.x, targetZ - e.z);
        e.x += Math.sin(angleToTarget) * e.speed * dt;
        e.z += Math.cos(angleToTarget) * e.speed * dt;

        // Attack core
        if (Math.hypot(e.x - t.core.x, e.z - t.core.z) < 4.5) {
          e.atkCd = (e.atkCd || 0) - dt;
          if (e.atkCd <= 0) {
            e.atkCd = 1.0;
            const dmg = (e.type === 'kamikaze') ? 60 : 25;
            t.core.health = Math.max(0, t.core.health - dmg);
            this.screenShake = 6;
            audio.leak();
            if (e.type === 'kamikaze') {
              t.enemies.splice(i, 1);
              continue;
            }
          }
        }
        // Attack player
        if (distToPlayer < 2.2) {
          e.atkCd = (e.atkCd || 0) - dt;
          if (e.atkCd <= 0) {
            e.atkCd = 1.2;
            const rawDmg = (e.type === 'kamikaze') ? 45 : 15;
            const armorRed = (p.mode === 'SIEGE') ? 0.50 : 1.0;
            p.health = Math.max(0, p.health - Math.round(rawDmg * armorRed));
            this.screenShake = 6;
            this.vibrate([60, 40, 60]);
            audio.leak();
            if (e.type === 'kamikaze') {
              t.enemies.splice(i, 1);
              continue;
            }
          }
        }
      }

      // 4. Towers Update
      for (const tw of t.towers) {
        tw.fireCd = (tw.fireCd || 0) - dt;
        let nearest = null;
        let minDist = 30;
        for (const e of t.enemies) {
          const d = Math.hypot(e.x - tw.x, e.z - tw.z);
          if (d < minDist) { minDist = d; nearest = e; }
        }
        if (nearest) {
          tw.angle = Math.atan2(nearest.x - tw.x, nearest.z - tw.z);
          if (tw.fireCd <= 0) {
            tw.fireCd = 0.2;
            nearest.hp -= 20;
            audio.shootPulse();
            t.particles.push({
              x: nearest.x, y: 1.0, z: nearest.z,
              life: 0.25, maxLife: 0.25, color: "#ffd600"
            });
            if (nearest.hp <= 0) {
              const idx = t.enemies.indexOf(nearest);
              if (idx !== -1) t.enemies.splice(idx, 1);
              t.score += 80;
            }
          }
        }
      }

      // 5. Bullets Update
      for (let i = t.bullets.length - 1; i >= 0; i--) {
        const b = t.bullets[i];
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.z += b.vz * dt;
        b.life -= dt;

        for (let j = t.enemies.length - 1; j >= 0; j--) {
          const e = t.enemies[j];
          if (Math.hypot(b.x - e.x, b.z - e.z) < e.size && Math.abs(b.y - 1.0) < 1.5) {
            // Valorant Ballistics: Distance Falloff
            const distFromPlayer = Math.hypot(b.x - t.player.x, b.z - t.player.z);
            let falloff = 1.0;
            if (distFromPlayer > 30) falloff = 0.70;
            else if (distFromPlayer > 15) falloff = 0.85;

            // Headshot Detection (upper body / head hit)
            const isHeadshot = (b.y > 1.3);
            const critMult = isHeadshot ? 2.2 : 1.0;
            const finalDmg = Math.round(b.damage * falloff * critMult);

            e.hp -= finalDmg;
            b.life = 0;
            this.screenShake = isHeadshot ? 5 : 2;
            const pColor = isHeadshot ? "#ffd600" : "#ff1744";
            t.particles.push({ x: e.x, y: 1.2, z: e.z, life: 0.3, maxLife: 0.3, color: pColor });

            if (b.splashRadius > 0) {
              for (const other of t.enemies) {
                if (other !== e && Math.hypot(other.x - b.x, other.z - b.z) <= b.splashRadius) {
                  other.hp -= Math.round(finalDmg * 0.7);
                }
              }
              for (let k = 0; k < 12; k++) {
                t.particles.push({ x: b.x + (Math.random() - 0.5) * 4, y: 0.5 + Math.random() * 2, z: b.z + (Math.random() - 0.5) * 4, life: 0.4, maxLife: 0.4, color: "#ff9100" });
              }
            }

            if (isHeadshot) {
              this.addFloatingText("CRIT 2.2x!", 640, 300, "#ffd600", 22);
            }
            if (e.hp <= 0) {
              t.enemies.splice(j, 1);
              t.score += isHeadshot ? 200 : 100;
              audio.hit();
            }
            break;
          }
        }
        if (b.life <= 0) t.bullets.splice(i, 1);
      }

      // 6. Particles Update
      for (let i = t.particles.length - 1; i >= 0; i--) {
        const pt = t.particles[i];
        pt.life -= dt;
        if (pt.life <= 0) t.particles.splice(i, 1);
      }
    }

    shoot3DTPS() {
      const t = this.tps3D;
      const p = t.player;
      if (p.isReloading || p.fireCd > 0) return;
      if (p.ammo <= 0) { this.reload3DTPS(); return; }

      const isSiege = (p.mode === 'SIEGE');
      p.ammo -= (isSiege ? 2 : 1);
      p.fireCd = (isSiege ? 0.45 : 0.12);
      p.recoil = (isSiege ? 2.2 : 1.0);
      this.screenShake = (isSiege ? 7 : 2);

      if (isSiege) audio.explosion();
      else audio.shootPulse();

      const speed = isSiege ? 95 : 120;
      const spread = p.hasRedDot ? 0.02 : 0.05;
      const yawSpread = (Math.random() * 2 - 1) * spread;
      const pitchSpread = (Math.random() * 2 - 1) * spread;

      const aimYaw = p.yaw + yawSpread;
      const aimPitch = p.pitch + pitchSpread;

      t.bullets.push({
        x: p.x + Math.sin(p.yaw) * 0.8,
        y: 1.4,
        z: p.z - Math.cos(p.yaw) * 0.8,
        vx: Math.sin(aimYaw) * speed,
        vy: -Math.sin(aimPitch) * speed,
        vz: -Math.cos(aimYaw) * speed,
        damage: isSiege ? 160 : 45,
        isSiege: isSiege,
        splashRadius: isSiege ? 7.0 : 0,
        life: 0.85
      });
    }

    fire3DMissiles() {
      const t = this.tps3D;
      const p = t.player;
      if (p.missileCd > 0) return;
      p.missileCd = 8.0;
      audio.missileLaunch();
      this.screenShake = 6;
      this.addFloatingText("🚀 3D MISSILE SALVO!", 640, 260, "#ffd600", 22);

      for (let i = 0; i < 6; i++) {
        setTimeout(() => {
          if (!this.tps3D) return;
          const target = t.enemies[i % t.enemies.length] || null;
          const a = p.yaw + (Math.random() - 0.5) * 0.8;
          t.bullets.push({
            x: p.x + (i % 2 === 0 ? -1.0 : 1.0),
            y: 2.2,
            z: p.z,
            vx: Math.sin(a) * 45,
            vy: 8.0 + Math.random() * 6,
            vz: -Math.cos(a) * 45,
            damage: 95,
            isMissile: true,
            splashRadius: 5.0,
            target: target,
            life: 1.8
          });
        }, i * 90);
      }
    }

    fire3DEMP() {
      const t = this.tps3D;
      const p = t.player;
      if (p.empCd > 0) return;
      p.empCd = 12.0;
      audio.zap();
      this.screenShake = 12;
      this.addFloatingText("⚡ 3D EMP SHOCKWAVE DISCHARGED!", 640, 240, "#00e5ff", 24);

      for (const e of t.enemies) {
        e.stunTimer = 4.0;
        e.hp -= 40;
      }
      for (let i = 0; i < 30; i++) {
        const ang = Math.random() * Math.PI * 2;
        const dist = 5 + Math.random() * 30;
        t.particles.push({
          x: p.x + Math.cos(ang) * dist,
          y: 0.5 + Math.random() * 2.5,
          z: p.z + Math.sin(ang) * dist,
          life: 0.6, maxLife: 0.6,
          color: "#00e5ff"
        });
      }
    }

    toggle3DMechMode() {
      const p = this.tps3D.player;
      p.mode = (p.mode === 'SIEGE') ? 'BIPED' : 'SIEGE';
      p.speed = (p.mode === 'SIEGE') ? 8.0 : 14.0;
      audio.mechTransform();
      this.screenShake = 8;
      const modeStr = (p.mode === 'SIEGE') ? "🚜 SIEGE TANK FAOL! 120MM GAUBITSA" : "🤖 ASSAULT ROBOT! TEZKOR HARAKAT";
      const modeCol = (p.mode === 'SIEGE') ? "#ffd600" : "#00e5ff";
      this.addFloatingText(modeStr, 640, 200, modeCol, 22);
      this.triggerRadioComm("APEX-01 AI", modeStr, 3.5, "hero_dash");
    }

    reload3DTPS() {
      const p = this.tps3D.player;
      if (p.isReloading || p.ammo === p.maxAmmo || p.reserveAmmo <= 0) return;
      p.isReloading = true;
      p.reloadTimer = 1.8;
      audio.sell();
    }

    place3DTower() {
      const t = this.tps3D;
      const p = t.player;
      const tx = p.x + Math.sin(p.yaw) * 4.5;
      const tz = p.z - Math.cos(p.yaw) * 4.5;
      t.towers.push({ x: tx, y: 0, z: tz, angle: 0, fireCd: 0 });
      t.isBuilding = false;
      audio.upgrade();
      this.addFloatingText("3D GATLING TURRET DEPLOYED!", 640, 240, "#00e5ff", 22);
    }

    project3DPoint(wx, wy, wz, camX, camY, camZ, yaw, pitch, fov = 460) {
      const dx = wx - camX;
      const dy = wy - camY;
      const dz = wz - camZ;

      const cosY = Math.cos(-yaw);
      const sinY = Math.sin(-yaw);
      const x1 = dx * cosY - dz * sinY;
      const z1 = dx * sinY + dz * cosY;

      const cosP = Math.cos(-pitch);
      const sinP = Math.sin(-pitch);
      const y2 = dy * cosP - z1 * sinP;
      const z2 = dy * sinP + z1 * cosP;

      if (z2 <= 0.4) return null;

      const scale = fov / z2;
      return {
        x: 640 + x1 * scale,
        y: 360 - y2 * scale,
        z: z2,
        scale: scale
      };
    }

    render3DTPS() {
      if (!this.tps3D) this.start3DTPSMode();
      const ctx = this.ctx;
      const t = this.tps3D;
      const p = t.player;

      // 1. Cyber Skybox & Atmosphere
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 720);
      skyGrad.addColorStop(0, "#030712");
      skyGrad.addColorStop(0.5, "#0b1329");
      skyGrad.addColorStop(1, "#111827");
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, this.width, this.height);

      const camDist = p.isAiming ? 2.0 : 3.8;
      const shoulderX = p.isAiming ? 0.35 : 0.75;
      const camX = p.x - Math.sin(p.yaw) * camDist + Math.cos(p.yaw) * shoulderX;
      const camZ = p.z + Math.cos(p.yaw) * camDist + Math.sin(p.yaw) * shoulderX;
      const camY = 1.9 + Math.sin(p.pitch) * camDist;

      // 2. 3D Perspective Ground Grid
      ctx.lineWidth = 1;
      for (let x = -50; x <= 50; x += 10) {
        const p1 = this.project3DPoint(x, 0, -80, camX, camY, camZ, p.yaw, p.pitch);
        const p2 = this.project3DPoint(x, 0, 40, camX, camY, camZ, p.yaw, p.pitch);
        if (p1 && p2) {
          ctx.strokeStyle = (x === 0) ? "rgba(0, 229, 255, 0.4)" : "rgba(0, 229, 255, 0.12)";
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }
      for (let z = -80; z <= 40; z += 10) {
        const p1 = this.project3DPoint(-50, 0, z, camX, camY, camZ, p.yaw, p.pitch);
        const p2 = this.project3DPoint(50, 0, z, camX, camY, camZ, p.yaw, p.pitch);
        if (p1 && p2) {
          ctx.strokeStyle = (z === -35) ? "rgba(255, 23, 68, 0.5)" : "rgba(0, 229, 255, 0.12)";
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }

      // 3. Central Base Core in 3D
      const coreProj = this.project3DPoint(t.core.x, 0, t.core.z, camX, camY, camZ, p.yaw, p.pitch);
      if (coreProj) {
        const cr = 4.0 * coreProj.scale;
        ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
        ctx.beginPath();
        ctx.ellipse(coreProj.x, coreProj.y, cr * 1.4, cr * 0.6, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#0c1527";
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (Math.PI / 3) * i;
          const px = coreProj.x + Math.cos(a) * cr;
          const py = coreProj.y + Math.sin(a) * cr * 0.6;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        const orbY = coreProj.y - 2.5 * coreProj.scale;
        const orbGrad = ctx.createRadialGradient(coreProj.x, orbY, 2, coreProj.x, orbY, cr * 0.6);
        orbGrad.addColorStop(0, "#ffffff");
        orbGrad.addColorStop(0.5, "#00e5ff");
        orbGrad.addColorStop(1, "rgba(0, 110, 255, 0)");
        ctx.fillStyle = orbGrad;
        ctx.beginPath();
        ctx.arc(coreProj.x, orbY, cr * 0.6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#00e5ff";
        ctx.font = `bold ${Math.max(10, Math.round(12 * coreProj.scale / 20))}px monospace`;
        ctx.textAlign = "center";
        ctx.fillText(`BASE CORE [${t.core.health}/${t.core.maxHealth}]`, coreProj.x, orbY - cr * 0.7);
      }

      // 4. 3D Defense Towers
      for (const tw of t.towers) {
        const tp = this.project3DPoint(tw.x, 0, tw.z, camX, camY, camZ, p.yaw, p.pitch);
        if (tp) {
          const sz = 2.0 * tp.scale;
          ctx.fillStyle = "#1e293b";
          ctx.strokeStyle = "#00e5ff";
          ctx.lineWidth = 1.5;
          ctx.fillRect(tp.x - sz / 2, tp.y - sz, sz, sz);
          ctx.strokeRect(tp.x - sz / 2, tp.y - sz, sz, sz);
          ctx.fillStyle = "#ffd600";
          ctx.beginPath();
          ctx.arc(tp.x, tp.y - sz * 1.1, sz * 0.4, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 5. 3D Enemies (Sorted back to front)
      const renderList = [];
      for (const e of t.enemies) {
        const ep = this.project3DPoint(e.x, 0, e.z, camX, camY, camZ, p.yaw, p.pitch);
        if (ep) renderList.push({ type: 'enemy', e: e, proj: ep, z: ep.z });
      }
      renderList.sort((a, b) => b.z - a.z);

      for (const item of renderList) {
        const e = item.e;
        const ep = item.proj;
        const eh = e.size * 1.8 * ep.scale;
        const ew = e.size * 0.9 * ep.scale;

        ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
        ctx.beginPath();
        ctx.ellipse(ep.x, ep.y, ew * 0.9, ew * 0.45, 0, 0, Math.PI * 2);
        ctx.fill();

        const eGrad = ctx.createLinearGradient(ep.x - ew / 2, ep.y - eh, ep.x + ew / 2, ep.y);
        eGrad.addColorStop(0, "#475569");
        eGrad.addColorStop(0.5, e.color);
        eGrad.addColorStop(1, "#0f172a");
        ctx.fillStyle = eGrad;
        ctx.beginPath();
        ctx.roundRect(ep.x - ew / 2, ep.y - eh, ew, eh, [ew * 0.3]);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.fillStyle = "#ff1744";
        ctx.fillRect(ep.x - ew * 0.35, ep.y - eh * 0.85, ew * 0.7, eh * 0.15);

        const barW = Math.max(24, ew * 1.4);
        ctx.fillStyle = "#090d16";
        ctx.fillRect(ep.x - barW / 2, ep.y - eh - 8, barW, 4);
        ctx.fillStyle = e.color;
        ctx.fillRect(ep.x - barW / 2, ep.y - eh - 8, barW * (e.hp / e.maxHp), 4);
      }

      // 6. 3D Bullets
      for (const b of t.bullets) {
        const bp = this.project3DPoint(b.x, b.y, b.z, camX, camY, camZ, p.yaw, p.pitch);
        if (bp) {
          ctx.fillStyle = "#ffd600";
          ctx.beginPath();
          ctx.arc(bp.x, bp.y, Math.max(2, 2.5 * bp.scale / 20), 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 7. 3D Player Mech (Over-The-Shoulder TPS Character)
      const pp = this.project3DPoint(p.x, 0, p.z, camX, camY, camZ, p.yaw, p.pitch);
      if (pp) {
        const pw = 1.3 * pp.scale;
        const ph = 2.4 * pp.scale;

        ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
        ctx.beginPath();
        ctx.ellipse(pp.x, pp.y, pw * 0.8, pw * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();

        const mechGrad = ctx.createLinearGradient(pp.x - pw / 2, pp.y - ph, pp.x + pw / 2, pp.y);
        mechGrad.addColorStop(0, "#334155");
        mechGrad.addColorStop(0.5, "#1e293b");
        mechGrad.addColorStop(1, "#090d16");
        ctx.fillStyle = mechGrad;
        ctx.beginPath();
        ctx.roundRect(pp.x - pw * 0.4, pp.y - ph * 0.9, pw * 0.8, ph * 0.65, [pw * 0.2]);
        ctx.fill();
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.fillStyle = "#00e5ff";
        ctx.beginPath();
        ctx.arc(pp.x, pp.y - ph * 0.6, pw * 0.16, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#090d16";
        ctx.beginPath();
        ctx.arc(pp.x, pp.y - ph * 0.95, pw * 0.26, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#00e5ff";
        ctx.fillRect(pp.x - pw * 0.2, pp.y - ph * 0.98, pw * 0.4, ph * 0.1);

        if (p.mode === 'SIEGE') {
          // Dual Heavy Caterpillar Treads
          ctx.fillStyle = "#1e293b";
          ctx.fillRect(pp.x - pw * 0.7, pp.y - ph * 0.4, pw * 0.35, ph * 0.45);
          ctx.fillRect(pp.x + pw * 0.35, pp.y - ph * 0.4, pw * 0.35, ph * 0.45);
          ctx.strokeStyle = "#ffd600";
          ctx.lineWidth = 1.2;
          ctx.strokeRect(pp.x - pw * 0.7, pp.y - ph * 0.4, pw * 0.35, ph * 0.45);
          ctx.strokeRect(pp.x + pw * 0.35, pp.y - ph * 0.4, pw * 0.35, ph * 0.45);
        }

        const recoilOffset = p.recoil * 10;
        const gunX = pp.x + pw * 0.45;
        const gunY = pp.y - ph * 0.55 + recoilOffset;

        if (p.mode === 'SIEGE') {
          // Twin 120mm Heavy Artillery Cannons
          ctx.fillStyle = "#334155";
          ctx.fillRect(gunX - 6, gunY - 4, 28, 6);
          ctx.fillRect(gunX - 6, gunY + 4, 28, 6);
          ctx.fillStyle = "#ffd600";
          ctx.fillRect(gunX + 20, gunY - 5, 4, 8);
          ctx.fillRect(gunX + 20, gunY + 3, 4, 8);
        } else {
          ctx.fillStyle = "#475569";
          ctx.fillRect(gunX - 4, gunY - 3, 24, 7);
          ctx.fillStyle = "#00e5ff";
          ctx.fillRect(gunX + 16, gunY - 2, 8, 3);
        }

        if (p.hasLaser && !p.isAiming) {
          ctx.strokeStyle = "rgba(0, 229, 255, 0.45)";
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(gunX + 24, gunY);
          ctx.lineTo(640, 360);
          ctx.stroke();
        }
      }

      // 8. 3D Building Ghost
      if (t.isBuilding) {
        const buildX = p.x + Math.sin(p.yaw) * 5.0;
        const buildZ = p.z - Math.cos(p.yaw) * 5.0;
        const bp = this.project3DPoint(buildX, 0, buildZ, camX, camY, camZ, p.yaw, p.pitch);
        if (bp) {
          const bs = 3.0 * bp.scale;
          ctx.strokeStyle = "#00e676";
          ctx.fillStyle = "rgba(0, 230, 118, 0.25)";
          ctx.lineWidth = 2;
          ctx.strokeRect(bp.x - bs / 2, bp.y - bs / 2, bs, bs);
          ctx.fillRect(bp.x - bs / 2, bp.y - bs / 2, bs, bs);
          ctx.fillStyle = "#00e676";
          ctx.font = "bold 12px monospace";
          ctx.textAlign = "center";
          ctx.fillText("TAP [FIRE] TO DEPLOY TURRET", bp.x, bp.y - bs / 2 - 8);
        }
      }

      // 9. Precision Crosshair (Center Screen)
      const cx = 640;
      const cy = 360;
      if (p.isAiming) {
        ctx.strokeStyle = "rgba(0, 229, 255, 0.85)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, cy, 26, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = "#ff1744";
        ctx.beginPath();
        ctx.arc(cx, cy, 3, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 2;
        const gap = 8 + p.recoil * 14;
        const len = 12;
        ctx.beginPath();
        ctx.moveTo(cx - gap - len, cy); ctx.lineTo(cx - gap, cy);
        ctx.moveTo(cx + gap, cy); ctx.lineTo(cx + gap + len, cy);
        ctx.moveTo(cx, cy - gap - len); ctx.lineTo(cx, cy - gap);
        ctx.moveTo(cx, cy + gap); ctx.lineTo(cx, cy + gap + len);
        ctx.stroke();
      }

      // 10. Tactical 3D HUD & Controls
      this.renderMiniButton(20, 18, 175, 38, "← 2D STRATEGIYA", "#00e5ff");

      ctx.fillStyle = "#0c1527";
      ctx.fillRect(160, 18, 960, 40);
      ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
      ctx.lineWidth = 1;
      ctx.strokeRect(160, 18, 960, 40);

      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 15px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`WAVE: ${t.wave}`, 180, 43);
      ctx.fillText(`SCORE: ${t.score}`, 320, 43);

      ctx.fillStyle = "#cfd8dc";
      ctx.fillText(`BASE CORE:`, 480, 43);
      ctx.fillStyle = "#090d16";
      ctx.fillRect(590, 28, 200, 18);
      ctx.fillStyle = t.core.health > 150 ? "#00e676" : "#ff1744";
      ctx.fillRect(590, 28, 200 * (t.core.health / t.core.maxHealth), 18);
      ctx.strokeStyle = "#ffffff";
      ctx.strokeRect(590, 28, 200, 18);

      ctx.fillStyle = "#0c1527";
      ctx.fillRect(30, 640, 240, 60);
      ctx.strokeStyle = "#00e5ff";
      ctx.strokeRect(30, 640, 240, 60);

      ctx.fillStyle = "#ffd600";
      ctx.font = "bold 20px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`AMMO: ${p.ammo} / ${p.reserveAmmo}`, 45, 675);
      if (p.isReloading) {
        ctx.fillStyle = "#ff1744";
        ctx.font = "bold 12px monospace";
        ctx.fillText("RELOADING...", 175, 675);
      }

      // Mobile Touch Action Sci-Fi Circular Buttons (Right side)
      this.render3DCircularButton(1200, 620, 48, "💥 OTISH", "FIRE", "#ff1744", false);
      this.render3DCircularButton(1080, 640, 36, "🎯 DURBIN", "AIM", "#00e5ff", p.isAiming);
      this.render3DCircularButton(1200, 500, 36, "🏗️ QURISH", "BUILD", "#00e676", t.isBuilding);
      this.render3DCircularButton(1080, 540, 30, "🔄 O'Q", "RELOAD", "#ffd600", p.isReloading);

      // Mech Mode & Super Skill Action Buttons
      const modeLabel = (p.mode === 'SIEGE') ? "🚜 TANK" : "🤖 ROBOT";
      const modeCol = (p.mode === 'SIEGE') ? "#ffd600" : "#00e5ff";
      this.renderMiniButton(960, 615, 95, 45, modeLabel, modeCol);
      this.renderMiniButton(960, 555, 95, 45, p.empCd > 0 ? `EMP ${Math.ceil(p.empCd)}s` : "⚡ EMP", "#00e5ff");
      this.renderMiniButton(1070, 555, 95, 45, p.missileCd > 0 ? `MSL ${Math.ceil(p.missileCd)}s` : "🚀 RAKETA", "#ffd600");

      if (t.touch.moveId !== null) {
        ctx.fillStyle = "rgba(0, 229, 255, 0.2)";
        ctx.strokeStyle = "#00e5ff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(t.touch.moveStart.x, t.touch.moveStart.y, 65, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#ffd600";
        ctx.beginPath();
        ctx.arc(t.touch.moveStart.x + t.touch.moveVec.x * 55, t.touch.moveStart.y + t.touch.moveVec.y * 55, 24, 0, Math.PI * 2);
        ctx.fill();
      }
    }

  }

  window.LastGridEngine = LastGridEngine;

  window.addEventListener('DOMContentLoaded', () => {
    window.lastGridEngine = new LastGridEngine();
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  });

})();
